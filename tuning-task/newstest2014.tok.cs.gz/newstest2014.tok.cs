černá skříňka ve vašem autě ?
zatímco američtí silniční projektanti se usilovně snaží najít peníze na opravy rozpadající se dálniční sítě , mnozí začínají vidět řešení v malé černé skříňce , která se snadno vejde do přístrojové desky vašeho auta .
zařízení , která sledují každý kilometr , jenž motorista ujede , a která přenášejí tuto informaci úřadům , jsou jádrem kontroverzní snahy washingtonu a úřadů pro státní plánování renovovat zastaralý systém financování amerických hlavních silnic .
obvykle fádní projektování dálnic najednou podnítilo intenzivní debatu a vznik nejrůznějších spolků .
libertariáni se sešli se skupinami ekologů a lobovali za to , aby vláda mohla používat tyto malé skříňky , které by zaznamenávaly ujeté kilometry a možná i to , kam jedete – a poté by se tyto informace využily k sestavení daňového výměru .
tea party je zděšená .
americká unie pro občanské svobody je také hluboce znepokojená a zmínila řadu problémů s ochranou soukromí .
a zatímco se kongres nemůže shodnout , zda pokračovat , některé státy na nic nečekají .
zjišťují , jak se během následujícího desetiletí mohou přesunout k systému , ve kterém řidič platí za kilometr silnice , po které jede .
tisíce motoristů si již černé skříňky , z nichž některé mají sledování pomocí gps , vzaly na otestování .
toto je pro náš národ opravdová nutnost .
„ nejedná se o záležitost , kdy si můžeme moc vybírat , “ řekl hasan ikhrata , výkonný ředitel sdružení státní správy v jižní kalifornii , který pro tento stát plánuje zahájit sledování ujetých kilometrů u každého kalifornského motoristy v roce 2025 .
změní se způsob , jakým platíme tyto daně .
slouží k tomu tato technologie .
podnětem je fakt , že silniční svěřenecký fond financovaný z daní , které američané platí u čerpacích stanic , je na dně .
američané nekupují tolik benzínu , jako dříve .
automobily ujedou mnohem víc kilometrů na jeden galon .
samotná federální daň , 18,4 centů na galon , se za uplynulých 20 let nezvýšila .
kvůli současné vysoké ceně benzínu se politici zdráhají zvednout daň i jen o jediný cent .
„ daň z benzínu prostě není udržitelná , “ řekl lee munnich , odborník na dopravní politiku z univerzity v minnesotě .
jeho stát nedávno umístil sledovací zařízení do 500 aut , aby otestoval tento systém placení za ujetý kilometr .
„ z dlouhodobého hlediska se to jeví jako nejlogičtější alternativa , “ řekl .
experti ji nazývají uživatelským poplatkem podle počtu ujetých kilometrů .
není žádným překvapením , že se tento nápad líbí urbanistický liberálům , protože daně mohou být využity k tomu , aby se změnily vzorce chování řidičů , což například může pomoci omezit dopravní zácpy a vytváření skleníkových plynů .
kalifornští projektanti vzhlížejí k tomuto systému při plánování strategií , které mají naplnit cíle stanovené v ambiciózních zákonech o globálním oteplování .
ale republikán bill shuster ( zástupce pensylvánie ) , předseda výboru pro dopravu , řekl , že to také vidí jako nejfunkčnější dlouhodobou alternativu .
představitelé volného trhu z organizace reason foundation jsou také nakloněni myšlence , že řidiči budou platit za ujeté kilometry .
„ není to daň , která zmizí v černé díře , “ řekl adrian moore , viceprezident pro strategii v organizaci reason .
lidé platí přímo za to , co dostávají .
iniciativu podporují také dva bývalí američtí ministři dopravy , kteří v roce 2011 kongres vybízeli , aby se vydal směrem placení za kilometr .
americký senát loni schválil pilotní projekt za 90 milionů usd , který měl zahrnovat asi 10 000 automobilů .
vedení sněmovny reprezentantů však návrh zamítlo a učinilo tak kvůli obavám venkovských zákonodárců zastupujících složky obyvatel , jejichž každodenní život často znamená urazit mnoho kilometrů za prací mimo město .
několik států a měst však přesto postupuje kupředu na vlastní pěst .
nejhorlivější je oregon , který do největšího experimentu v zemi zahrnul 5 000 řidičů .
tito řidiči brzy začnou státu platit daň za ujeté kilometry , namísto daně za benzín .
nevada již pilotní projekt dokončila .
new york právě projekt zkoumá .
illinois se o to snaží v omezené míře u nákladních vozů .
a koalice i-95 , která zahrnuje 17 státních ministerstev dopravy , spolu s pobřežními státy na východě ( včetně marylandu , pennsylvánie , virginie a floridy ) studuje , jak mohou tuto změnu implementovat .
tento koncept nemá však jen zastánce .
v nevadě , kde nedávno bylo zařízením vybaveno asi 50 aut dobrovolníků , byli řidiči znepokojení tím , že vláda je schopná sledovat každý jejich pohyb .
„ obavy týkající se sledování typu big brother a podobné záležitosti byly velkým problémem , “ řekl alauddin khan , který vede management strategie a provozu na nevadském ministerstvu dopravy .
nebylo to něco , co lidé chtěli .
jak zkušební projekt pokračoval , americká unie občanských svobod v nevadě na svých webových stránkách varovala : „ bylo by velice snadné proměnit tato zařízení na plnohodnotná sledovací zařízení . “
není třeba vybudovat ohromnou těžkopádnou technologickou infrastrukturu , která se nevyhnutelně rozšíří na evidenci každodenních výjezdů a příjezdů jednotlivců .
nevada patří mezi těch několik států , které se snaží nalézt dostupnou technologii , jež by státu umožnila sledovat , kolik kilometrů vůz najede , ale ne přesně kdy a kde .
pokud to dokážete , řekl khan , veřejnost bude klidnější .
hon na takovou technologii přivedl některé státní agentury k malé společnosti v kalifornii s názvem true mileage ( skutečná ujetá vzdálenost ) .
tato firma původně do akce na pomoc vládě při zdaňování řidičů zapojena nebyla .
chtěla prorazit na vznikajícím trhu s pojištěním zákonné odpovědnosti , kde by řidiči platili na základě toho , kolik ujedou .
ale toto zařízení , které zkouší , přitahuje pozornost projektantů silniční sítě , protože nepoužívá gps a dodává jen omezené množství informací , které jsou pravidelně nahrávány pomocí modemu .
„ lidé budou ochotnější do toho jít , pokud nesledujete jejich rychlost a jejich polohu , “ říká ryan morrison , výkonný ředitel true mileage .
v některých těchto pilotních programech se objevila řada velkých chyb .
jsou mnohem levnější a méně dotěrné způsoby , jak to udělat .
v oregonu projektanti experimentují s tím , že řidičům dávají na výběr .
mohou si vybrat zařízení s gps nebo bez gps .
nebo si nemusí vzít žádné zařízení a místo toho se rozhodnou platit paušální poplatek založený na průměrném počtu ujetých kilometrů všech obyvatel státu .
na jiných místech doufají , že obezřetná veřejnost na tento koncept přistoupí , pokud zařízení bude umět více , ne méně .
ve městě new york se dopravní úředníci snaží vyvinout zdaňovací zařízení , které by bylo vybaveno tak , aby navíc bylo možné platit poplatky u parkovacích hodin , aby poskytovalo pojištění podle ujetých kilometrů a aby sbíralo údaje o rychlosti jiných řidičů , takže se motoristé mohou vyhnout dopravní zácpě .
„ motoristé budou ochotní se do toho zapojit kvůli hodnotě benefitů , které se jim nabízejí , “ uvádí projekční dokument města .
někteří dopravní projektanti by však rádi věděli , zda veškeré diskuse o placení za kilometr nejsou jen obřím zástupným problémem .
úředníci z metropolitního výboru pro dopravu v oblasti zátoky san francisco říkají , že kongres by mohl problém se zbankrotovaným silničním svěřeneckým fondem velice jednoduše vyřešit zvýšením daně z benzínu .
jednorázová nebo roční daň by mohla být uvalena na řidiče hybridních či jiných vozů , které nespotřebují mnoho paliva , takže budou platit spravedlivý podíl .
„ není zapotřebí žádné radikální operace , když bohatě stačí vzít si aspirin , “ řekl randy rentschler , ředitel výboru pro legislativu a veřejné záležitosti .
pokud to tak uděláme , stovky milionů řidičů budou mít obavy o své soukromí a spoustu dalších věcí .
za čssd vyjednává sobotka .
sociální demokracie se drolí , lidovci a babišovci spolu hovoří a chystají společný postup .
pokud se sociální demokraté do několika týdnů zmátoří , zasednou k jednacímu stolu s dokonale sehranými partnery , kteří položí na stůl hotový seznam požadavků včetně ministerských postů .
vyslanci čssd pak buď spolknou kyselé koaliční hrozny , nebo kývnou na vrtkavou menšinovou vládu .
bohuslav sobotka po čtyřech dnech , kdy se nesl na vlně sympatií , poprvé narazil .
včera se mu nepovedlo ovládnout politické grémium a hlavně donutit usvědčené lháře k rezignaci .
potvrzeným vyjednavačem za stranu je zatím pouze on , ostatní členové týmu budou dovoleni až po klíčovém zasedání ústředního výkonného výboru ( úvv ) .
omluvil jsem se členům grémia a teď i občanům .
lhát se nemá , v osobním životě ani na veřejnosti .
&quot; byla to chyba , &quot; řekl po jednání nejužšího vedení sociální demokracie michal hašek .
dodal , že na postu prvního místopředsedy nelpí .
&quot; své rozhodnutí sdělím 10. listopadu na úvv , &quot; pravil hašek .
podobně hovořil i místopředseda čssd zdeněk škromach a šéf poslaneckého klubu jeroným tejc .
ten ovšem upozornil , že byl zvolen před pouhými dvěma dny .
oba poslanci pak prohlásili , že udělají vše pro to , aby padesátičlenný klub čssd zněl jedním hlasem .
absurdnímu divadlu nasadil korunu michal hašek větou : &quot; jsem členem čssd patnáct let , vždy jsem byl loajální k její značce a respektoval jsem rozhodnutí stranických orgánů . &quot;
čili další lež v přímém přenosu .
nebo snad při výzvě k sobotkově rezignaci a jeho vyřazení z vyjednávacího týmu zapomněl , že srpnový úvv se 57 procenty usnesl na tom , že bohuslav sobotka je kandidátem strany na premiéra ?
šéf čssd si ovšem svoláním úvv až na příští neděli vyrobil mocné vojsko nepřátel .
jeho oponenti mají deset dní na to , aby zaplavili e-maily 192 členů tohoto orgánu i média snůškou nejrůznějších drbů a fám , eventuálně připomněli reálné chyby sobotkovy politické kariéry .
bude se mocně prát špinavé prádlo , objeví se náznaky temných spojenectví mezi uhlobaronem zdeňkem bakalou a sobotkovým křídlem .
bude se probírat přátelský vztah bohuslava sobotky a vlivného advokáta radka pokorného .
vybublají spory v jihomoravské či moravskoslezské organizaci čssd .
varovná jsou slova ostravského primátora a sobotkova spojence petra kajnara : &quot; chartu 77 jsem podepsal proto , aby zemi nevládli idioti . &quot;
kdyby se úvv sešel už tento víkend , lháři by asi byli donuceni k rituálnímu obětování svých funkcí .
zrádci si posypou hlavu popelem a zůstanou .
a momentálně vítězící šéf čssd pak skončí s přezdívkou bohuslav pyrrha .
martin doktor o problémech s oh v soči : komunikace s rusy je náročná
koutky jeho úst naznačí nepatrný úsměv a pak jen zhluboka vydechne : &quot; je to náročné . &quot;
spolupráce s organizačním týmem olympiády v soči 2014 je podle martina doktora trochu složitější .
na to , co bylo na minulé olympiádě , můžeme zapomenout .
&quot; nic nefunguje stejně , &quot; tvrdí šéf české olympijské mise .
co konkrétně se děje ?
řada věcí funguje pomaleji a ne tak přesně .
je to takové zmatečné .
z hlediska faktur jsou relativně rychlí , z hlediska dodávání informací ohledně zásadních věcí už tolik ne .
třeba z nich už tři měsíce páčíme , aby nám dodali , jak budou oficiálně označeny jednotlivé vesnice , abychom podle toho mohli udělat celou řadu věcí .
stále čekáme a oni stále říkají , že tu věc komunikují .
v řadě věcí pořád komunikují .
je už alespoň dostavěná olympijská vesnice ?
ale už to není katastrofální stav .
před měsícem jsme chodili po prázdných místnostech .
domy naštěstí stojí .
co znamená , že jsou prázdné ?
jsou třeba hotové podlahy ?
jen základní beton , tedy takový byl stav před měsícem .
ale oni pořád mají čas.
i když existuje nebezpečí , že až tam 26. ledna jako předvoj přijedeme , bude tam pořád cítit lepidlo .
a kdyby nestíhali , tak bude co ?
prezident putin by tam myslíte nahnal armádu ?
přesně tak to asi dopadne .
jen aby to nebylo , že olympijské vesnice = potěmkinovy vesnice .
spíš hrozí , že nestihnou například úpravu cest , nedodělají detaily .
možná budou mít cesty v takovém stavu , že si budeme muset brát s sebou holínky z londýnských her .
ale věřím , že to nějak do kupy dají .
kolik českých sportovců by mohlo do soči jet ?
teď jich je zhruba 78 , i když v závislosti na nominačních kritériích se to číslo mění .
třeba krasobruslaři patrně pojedou v té trojici , co si vyjeli .
o rychlobruslařce martině sáblíkové také nikdo nemusí pochybovat , ale jinak je to ve vývoji .
ještě vás čeká cesta do soči ?
ne , pakliže se nic nestane , měl bych tam letět až 26. ledna .
jak budou vypadat domy v olympijské vesnici , víme .
dokonce jsme si sami některé věci změřili metrem , abychom nevěřili jen náčrtkům .
připravujeme i celou řadu dalších věcí včetně dopravy .
a co dělá šéf mise sto dnů před olympijskými hrami ?
připravuji se na výroční hodnocení jednotlivých olympijských sportů plus dělám běžnou agendu ve smyslu komunikace s organizačním výborem v soči .
putin sliboval ekologickou olympiádu , plán mu hatí obří tajné skládky
fanoušci zimních sportů už stříhají metr do zahájení olympijských her v soči , jiní na jejich přípravu hledí se stále většími obavami .
ruská olympiáda , byť začne až v únoru , se totiž potýká s dalším skandálem .
rusům se podle všeho nedaří splnit slib , že přípravy a konání her ani v nejmenším nenaruší přírodu v krasnodarském kraji při úpatí kavkazu , kam za čtyři měsíce zamíří tisíce sportovců a desítky tisíc návštěvníků .
ostatně po olympiádě ve vancouveru měli rusové laťku postavenou velmi vysoko , kanadské hry se do dějin olympiády zapsaly jako nejšetrnější k životnímu prostředí .
zdá se však , že závazek ruského prezidenta vladimira putina uspořádat hry s &quot; nulovým odpadem &quot; , vzal už dávno za své .
reportéři agentury ap minulý týden objevili obří skládku stavebního materiálu ve vesnici achštyr nedaleko soči .
tedy skládku plnou stavebního materiálu , pneumatik , kanystrů a izolačních pěn našli už v srpnu ekologové , což okamžitě nahlásili .
ruské úřady se kály a skládka zmizela .
jenže jen na chvíli .
minulý týden se reportérům naskytl pohled na skládku o velikosti tří fotbalových hřišť .
není jediná , v oblasti takových míst vzniklo několik , popsal britský list the times .
na místě pracují ruské železnice , státní monopol , který buduje zhruba šedesátikilometrovou cestu mezi letištěm v soči a sportovním resortem .
podnik , který už spolykal 280 miliard rublů , vedl jeden z blízkých putinových spolupracovníků vladimir jakunin .
v srpnu se železnice bránily , že skládku založil někdo ze subdodavatelů .
místní obyvatelé už jsou ale zoufalí .
podle obyvatel achštyru kolem vsi už tři měsíce dnem i nocí jezdí náklaďáky plné odpadního materiálu .
podle expertů hrozí , že odpad kontaminuje místní řeku mzymtu , další potoky a nakonec i černé moře .
&quot; voda odsud kontaminuje sočské vodní prameny na příštích deset až patnáct let , &quot; řekl britskému listu vladimir kimajev z ekologické neziskové organizace ewnc .
nelegální skládky nejsou jediným problémem ruského organizačního výboru a vlády .
nejdražší olympiáda v historii , jsou podle opozice jeden velký tunel .
pro srovnání : hry v soči budou stát 51 miliard dolarů , zatímco letní olympiáda v pekingu 2008 vyšla na 43 miliard .
loňské hry v londýně stály jen 19 miliard a zmíněné vancouverské devět miliard .
kromě korupčních skandálů , projektových zdržení a obav , jestli nakonec bude dost sněhu , se taky objevily zprávy , že při práci na výstavě sportovišť a infrastruktury se nedodržují lidská práva .
minulý měsíc si jeden z dělníků zašil ústa na protest , že nedostal dva měsíce zaplaceno .
mnozí se také obávají , jak se ruští organizátoři během her popasují s novým zákonem , který zakazuje propagaci homosexuality .
někteří návštěvníci se chystají ruské gaye na olympiádě podpořit .
mladý pár vyzrál na bydlení s rodiči , nový dům nabízí soukromí oběma generacím
japonské studio tai and associates dostalo jako zadání navrhnout dům na parcele , která leží na rohu dvou ulic , přičemž samotný pozemek se poněkud svažuje .
v požadavku dále stálo , že v domě budou bydlet dvě generace , které by chtěly žít spolu , ale přitom by každá měla mít svůj vlastní jasně oddělený prostor .
mladší pár potřeboval navíc i malou kancelář .
dům stojí na rohu dvou ulic a na mírně se svažujícím pozemku .
architekti se proto rozhodli umístit každou domácnost do jednoho z pater domu .
&quot; při tvorbě návrhu jsme respektovali rodinné svazky , historii a vzpomínky spjaté s daným místem . &quot;
&quot; tři rozdílné funkce domu jsou několika cestami propojeny skrz exteriér objektu , takže si všichni uvědomují přítomnost druhých , ale přitom mají své soukromí , &quot; vysvětlují designéři .
domácnost rodičů je na úrovni zahrádky se starou borovičkou , k níž se vážou rodinné tradice a vzpomínky .
jednotlivé části domu jsou snadno rozpoznatelné už zvenčí , liší se totiž různou finální úpravou fasád .
zatímco hlavní segment budovy je z betonu , jehož povrch byl vytvarován pomocí panelů z prken , část , kde je kancelář , je omítnuta bíle a zbývající prvky zůstaly v čistém betonovém provedení bez dalších úprav .
mnoho stěn domu je zcela prosklených , díky čemuž je interiér domu velmi provázaný s exteriérem .
domácnost rodičů , přesněji kuchyň , jídelna a obývák , obklopuje malou zahrádku se stromkem , který má pro rodinu velký význam .
propojení interiéru s exteriérem podtrhuje boční zeď , která začíná na zahrádce a pokračuje až do obýváku .
kuchyňský prostor v domácnosti mladého páru .
mladý pár vstupuje do domu hlavním vchodem do haly a odtud pak stoupá po schodech do svých prostor .
právě schody jsou hlavní dominantou interiéru domu .
jejich konstrukce umožňuje , aby skrz ně kaskádovitě propadala spousta přirozeného světla .
právě tím se architekti snažili odlišit dům od jiných a vtisknout mu něco unikátního .
domácnost mladého páru je pojednána jako jeden otevřený prostor s kuchyňskou částí , jídelnou a obývákem dohromady .
od terasy jej dělí pouze prosklená stěna s posuvnými dveřmi .
obývací zóna s jídelní a kuchyňskou částí v domácnosti mladého páru .
druhé patro je komponováno jako jeden velký otevřený prostor , který volně přechází na terasu , odkud je pěkný výhled na tokijskou zátoku .
samotná kancelář v nejvyšším poschodí je pojata v čisté kombinaci bílé a černé barvy .
schodiště je dominantním prvkem interiéru domu .
mladý pár vchází do domu hlavním vchodem , ocitne se ve vstupní hale a odtud pak stoupá po schodišti vzhůru .
braňte akademické svobody , platí to pro zemana i ods .
opakovaně jsem v posledních měsících vyzýval otevřenými dopisy studenty , pedagogy a vedení středních a vysokých škol v několika krajích , aby bránili akademické svobody před volební kampaní , kterou na školách prováděl prezident miloš zeman .
setkával jsem se s větším či menším úspěchem .
rektorovi masarykovy univerzity v brně , který odmítl přednášku čestného předsedy spoz - zemanovci v předvolebním období , se za to dokonce dostalo odvety v podobě nepozvání na oslavu státního svátku české republiky .
zde je seznam představitelů škol , kteří již tak stateční nebyli a návštěvu miloše zemana umožnili : vysoké učení technické v brně , gymnázium hladnov v ostravě , vysoká škola podnikání v ostravě , obchodní akademie v kolíně , univerzita j.e. purkyně v ústí nad labem .
nyní se v pardubicích setkáváme s pokračováním prosazování politiky na vysokých školách .
nově zvolený poslanec za ods , děkan fakulty elektrotechniky a informatiky univerzity pardubice , simeon karamazov , odmítá odstoupit ze své akademické funkce a navíc se mu to zdá normální .
pane profesore , to opravdu není totéž , jako kdybyste zůstal například ve funkci starosty menšího města .
chcete se zařadit k hejtmanům čssd , kteří vykovávají současně funkci poslance a hejtmana a stejně jako oni degradovat obě povolání ?
tím totiž lidem říkáte , že se dají zvládnout obě tyto náročné funkce levou zadní .
vím , máme zde příklad michala haška , který zvládá dokonce několik desítek funkcí najednou .
to ale asi není zrovna příklad osoby , kterou byste se měl řídit .
najdeme i opačný a kladný příklad mudr. štěpánky fraňkové , která raději opustila poslanecký post , aby se mohla plně věnovat vedení města pardubice .
hlavním důvodem mého doporučení opustit funkci děkana však je , že souběhem funkcí porušíte apolitičnost akademické půdy univerzity pardubice .
vedení pardubické ods vidí vaše současné působení na obou postech jako výhodu pro univerzitu .
&quot; své &quot; škole však budete moci pomoct i bez toho , že zůstanete děkanem .
myslím , že podobný názor jako mám já a rektor miroslav ludwig , budou mít i vaši studenti .
zvažte tedy ještě své odstoupení a zachovejte si tvář .
jinak se vám může stát , že vám to voliči v příštích volbách spočítají .
a to nemusí mít dlouhého trvání .
v kunovicích bublá zelí , chemii do něj nepřidávají
více než tisíc tun kysaného zelí chtějí v příštích měsících vyrobit ve slovácké frutě kunovice , která patří do potravinářské skupiny hamé .
sezona tady začala v říjnu a potrvá zhruba půl roku .
zdravou pochoutku tady od roku 1925 vyrábí stále tradičním způsobem , tedy šlapáním přímo ve velkých tancích .
v moderní průmyslové době jde o raritu .
naše pracovnice našlapou za směnu téměř desetikilometrovou trasu .
do každého z deseti tanků se vejde patnáct až třicet tun zelí , naplnění jednoho trvá tři směny , &quot; uvedl ředitel závodu slovácká fruta david kladroba .
hlávky zelí vozí do areálu společnosti přímo ze svých polí zemědělci převážně z ostrožska a břeclavska .
zaměstnanci fruty poté zeleninu očistí , odstraní košťály a házejí do krouhačky .
odtud již nakrájené zelí padá do bazénů o šestimetrové hloubce , v nichž neúnavně pracují šlapačky oděné v bílý oděv a holínky .
tím vytěsňují nežádoucí vzduch .
poslední sešlapaná vrstva zelí se překryje plachtou a zatíží vodou .
&quot; zelná krouhanka pak zraje šest až osm týdnů za spontánního mléčného kvašení bez jakéhokoliv přídavku látek podporujících kvašení , &quot; zdůraznil ředitel kladroba .
přirozený proces odpovídá výrobě v domácích podmínkách , jednotlivé vrstvy pracovníci prosypávají solí a kmínem .
zelí po vykvašení putuje k plnící lince .
balí se ve sladkokyselém nálevu do sáčků nebo sklenic a podrobuje se sterilaci .
hamé dodává kysané zelí především na tuzemský a slovenský trh .
zájem o něj registruje i v některých dalších zemích , například velké británii , irsku a kanadě .
snowden je ochoten „ spolupracovat “ s německem v souvislosti se sledováním ze strany usa
edward snowden , práskač z amerických zpravodajských služeb , oznámil , že je ochoten odjet do berlína , aby německému parlamentu předal důkazy , pokud americká národní bezpečnostní agentura a její ředitelka keith alexanderová nebudou schopni poskytnout odpovědi na otázky o svých aktivitách .
německý poslanec hans-christian sträbele se ve čtvrtek setkal s panem snowdenem v rusku , kde mu byl udělen azyl , a jednal s ním o možnosti svědčit v německu .
v dopise od pana snowdena , který poslanec předal médiím v pátek v berlíně , se uvádí : „ přestože výsledek mých snah byl prokazatelně pozitivní , má vláda se i nadále k opozici chová jako ke zběhům a snaží se kriminalizovat politické projevy těžkými žalobami , které nedávají prostor pro obhajobu . “
mluvit pravdu však není zločin .
v tomto dopise pan snowden řekl , že věří , že podpora mezinárodní komunity by mohla přesvědčit vládu spojených států , aby stáhla obvinění z trestných činů podaná proti němu .
obvinění vznesená ministerstvem spravedlnosti spojených států zahrnují špionáž a krádež státního majetku .
hans-peter friedrich , německý ministr vnitra , řekl pro časopis zeit online : „ pokud je pan snowden připraven mluvit s německými úředníky , najdeme způsob , jak to umožnit . “
napětí ve vztahu mezi usa a německem začalo stoupat , když se objevila tvrzení , že nsa odposlouchávala telefon kancléřky angely merkelové .
thomas oppermann , člen parlamentu , který vede parlamentní panel , jenž dohlíží na zpravodajství , řekl , že pokud by byla jakákoli příležitost vyslechnout pana snowdena jako svědka „ bez toho , že by se vystavil nebezpečí a že by se zcela zničily vztahy s usa “ , mělo by se tak učinit .
pan sträbele , poslanec parlamentu za německou stranu zelených , zveřejnil na svém twitterovém příspěvku fotku , na které je s panem snowdenem .
na své cestě do ruska jej doprovodili dva němečtí novináři .
pan sträbele řekl , že podle bývalého smluvního právníka nsa by pan snowden nebyl schopen se do ruska vrátit , pokud by jednou odjel .
pokud by pan snowden v německu svědčil , potřeboval by ujištění , že tam bude „ v bezpečí “ , řekl člen parlamentu .
pan snowden ve svém dopise řekl , že čelil drsné a vytrvalé kampani spojené s perzekucí , která ho přinutila opustit domov .
řekl však , že reakce celého světa na jeho „ akt politického vyjádření “ mu dodala odvahy .
občané na celém i vysocí úředníci – včetně těch ve spojených státech – zhodnotili odhalení neodůvodnitelného systému všudypřítomného sledování za službu veřejnosti .
dopis zahrnuje nabídku spolupracovat s německými úřady , „ až těžkosti této humanitární situace budou vyřešeny . “
zabíjení nás mrzí , ale jsme nevinní , hájí se představitelé rudých khmérů
nuon chea byl číslo dvě v hierarchii rudých khmerů a khieu samphan je bývalý šéf státu .
za vlády rudých khmerů , která se v letech 1975 až 1979 opírala o směsici maoismu a nacionalismu , přišly o život v důsledku vyčerpání , hladu , nemocí , mučení a poprav více než tři miliony kambodžanů , tedy nejméně čtvrtina tehdejší populace .
tomuto veliteli nechvalně proslulé věznice s-21 udělil mezinárodní trestní tribunál pro kambodžu v roce 2010 doživotní trest vězení .
nuon chea a khieu samphan jsou obvinění z genocidy a zločinů proti lidskosti včetně mučení , zotročování a vražd .
nuon chea a khieu samphan se hájili tím , že věřili , že jednají v nejlepším zájmu národa a netušili , jaký je skutečný rozsah zabíjení .
&quot; je snadné říct , že jsem měl všechno vědět , všechno chápat a tedy zasáhnout a napravit situaci , &quot; prohlásil ve čtvrtek khieu samphan před soudem .
opravdu si myslíte , že jsem chtěl , aby se tohle stalo mému lidu ?
skutečnost je taková , že jsem neměl žádnou pravomoc , &quot; dodal .
nuon chea uvedl , že nikdy nenařídil kádrům rudých khmerů , aby &quot; s lidmi špatně zacházeli nebo je zabíjeli , aby jim odpírali jídlo či páchali genocidu &quot; .
přiznal ale &quot; morální zodpovědnost &quot; za mrtvé .
&quot; chtěl bych se upřímně omluvit veřejnosti , obětem , jejich rodinám , všemu kambodžskému lidu , &quot; řekl .
pětapadesátiletá bin sivla , která za režimu rudých khmerů přišla o jedenáct příbuzných , agentuře afp řekla , že nemůže omluvu nuon chea přijmout . &quot;
&quot; lhal nám . &quot;
&quot; jenom chce být zproštěn viny . &quot;
&quot; nestará se o druhé , &quot; prohlásila .
&quot; kdyby nevydal rozkazy , jeho podřízení by nezabíjeli , &quot; dodala s tím , že vůdci rudých khmerů jsou &quot; horší než monstra &quot; .
před soudem měl stanout také &quot; ministr zahraničí &quot; režimu rudých khmerů ieng sary , který ale zemřel letos v březnu .
jeho manželku ieng thirith , tehdejší ministryni sociálních věcí , v září 2012 soud shledal neschopnou procesu kvůli demenci .
vůdce rudých khmerů pol pot zemřel v roce 1998 .
frontier airlines se chystá zpoplatnit příruční zavazadla
frontier airlines plánuje při svých letech účtovat částku ve výši až 100 usd za uložení příručního zavazadla na palubě .
frontier airlines plánuje zavést poplatek až 100 usd za příruční zavazadlo a 2 usd za kávu nebo sodovku , ačkoli ve svém oznámení ve středu řekli , že cestující si budou moci ponechat celou plechovku .
nový poplatek za příruční zavazadlo se týká zavazadel v horním úložném prostoru , takže malá zavazadla pod sedadlem budou i nadále zdarma .
společnost frontier říká , že bude účtovat 25 usd , pokud bude poplatek zaplacen předem , a 100 usd , pokud budou cestující s placením čekat až do příchodu k bráně .
mluvčí společnosti frontier kate o &apos; malleyová uvedla , že stodolarový poplatek má cestující povzbudit , aby se o zaplacení postarali dopředu .
„ neradi bychom tento poplatek vybírali , “ řekla .
letecké společnosti začaly zpoplatňovat první a druhá podaná zavazadla v roce 2008 .
cestující se snažili vyhnout těmto poplatkům a cpali do příručních zavazadel schovaných v úložném prostoru , jak nejvíce mohli , takže v tomto prostoru často chybělo místo .
poplatky jsou jednou z cest jak cestující naučit , aby si na palubu brali méně věcí .
o &apos; malleyová řekla , že smyslem tohoto nového poplatku skutečně není získat více peněz .
jde o to , že nejvěrnější zákazníci společnosti frontier se zcela jasně vyjádřili , že nalézt místo v horním úložném prostoru je stále obtížnější .
cestující , kteří si letenky zakoupí na webových stránkách společnosti , platit nebudou .
to znamená , že jeden cestující ve frontě u brány společnosti frontier může přinést zavazadlo , za které nezaplatí nic , zatímco druhý cestující ve frontě za stejné zavazadlo zaplatí 100 usd .
o &apos; malleyová řekla , že webové stránky a procedury odbavení budou upraveny tak , aby se zajistilo , že cestující se o poplatku dozvědí před svým příchodem k bráně .
nový poplatek společnosti frontier za příruční zavazadlo nebude zatím v platnosti dříve než v létě , avšak datum ještě stanoveno nebylo .
cestující si často na poplatky za zavazadla a jiné poplatky stěžují , ale letecké společnosti je milují .
tvrdí , že manipulace se zavazadly stojí peníze , a cestující , kteří tuto službu požadují , by za ní měli zaplatit .
mnozí na wall street vnímají další poplatek za zavazadlo jako znamení toho , že letecké společnosti se snaží vybrat dostatek peněz na to , aby pokryly náklady leteckého provozu po letech ztrát .
většina ale na poplatky za příruční zavazadla nesáhla .
společnost spirit airlines jako první zpoplatnila příruční zavazadla před třemi roky a další nízkonákladová společnost allegiant air její příklad později následovala .
jedinou společností , která má také takové poplatky , je maďarský wizz air , říká poradce v oblasti letecké dopravy jay sorensen , který pečlivě sleduje dodatečné poplatky .
ve své zprávě z prosince 2011 odhadl , že poplatek za příruční zavazadla společnosti spirit přinese ročně 50 milionů usd .
sorensen , bývalý vedoucí pracovník společnosti midwest airlines , nedávno letěl se společností spirit a podivoval se nad tím , co u brány viděl , když se cestující setkali s neobvyklým poplatkem společnosti spirit za příruční zavazadlo .
„ nastupování do letadla bylo to nejplynulejší , jaké jsem kdy ve své letecké kariéře viděl , “ řekl .
čekal jsem , že u brány uvidím skřípění zubů a hádky .
letadlo bylo plné , řekl , „ a nástup proběhl v mžiku “ .
frontier také po vzoru společnosti spirit uplatní poplatky za kávu , čaj , sodovku a džus .
frontier uvedl , že cestující , kteří dostanou limonádu nebo džus , si mohou ponechat celou plechovku a káva bude zdarma doplňována .
voda se i nadále bude podávat zdarma .
společnost us airways se v roce 2008 krátce pokusila zavést poplatky za nápoje , ale po stížnostech cestujících od toho o sedm měsíců později ustoupila a žádná jiná významná letecká společnost ji nenapodobila .
poslední tah společnosti frontier zpoplatnit příruční zavazadlo , pokud si cestující nezakoupí let přímo od této letecké společnosti , je její poslední snahou směřovat zákazníky přímo na své webové stránky .
letecké společnosti platí internetovým cestovním prodejcům , jako je orbitz , od 10 do 25 usd za každou prodanou letenku .
to dalo všem leteckým společnostem podnět , aby vedly cestující k nákupu přímo od nich , místo aby to udělali prostřednictvím internetových cestovních agentur .
společnost frontier však v této oblasti zašla nejdále .
v září začala dávat zákazníkům , kteří nakoupili přes internetovou cestovní agenturu , jen polovinu mil v rámci věrnostního programu .
ve středu ořízla odměnu za nalétané míle na 25 procent mil z dané cesty .
takže cesta se společností frontier dlouhá 1000 mil zakoupená přes internetovou cestovní agenturu znamená odměnu 250 mil .
zákazníkům také společnost umožňuje zvolit si předem své sedadlo pouze v případě , že nákup provedou přímo přes webové stránky společnosti frontier .
společnost frontier má ve svém domácím městě denveru věrnou základnu zákazníků , ale její podnikání se začíná smršťovat a ztrácí peníze .
podle finančních výsledků uvedených ve středu firemním partnerem republic airways holdings tržby spadly o 9 procent a dopravní kapacita se v prvním čtvrtletí zmenšila téměř o 13 procent
společnost republic se prodejem této letecké společnosti snaží vyřešit právě i finanční problémy společnosti frontier .
za pád webových stránek nsa neobviňuje hackery , ale „ vnitřní chybu “
tajemná národní bezpečnostní agentura uvedla minulý pátek , že její webové stránky na několik hodin minulý týden spadly kvůli vnitřní chybě , nikoli kvůli útoku hackerů , jak někteří tvrdili na internetu .
„ stránky nsa.gov nebyly dnes večer několik hodin přístupné kvůli interní chybě , která nastala během pravidelné aktualizace , “ uvedla špionážní agentura v e-mailovém prohlášení .
problém bude odstraněn během dnešního večera .
tvrzení , že výpadek byl způsoben útokem ddos ( distribuované odmítnutí služeb ) není pravdivý .
dříve tento večer snímače online serverů zaznamenaly , že webové stránky nsa nefungovaly alespoň šest hodin , a stránky jsou pro některé uživatele nadále nedostupné .
dříve mluvčí nsa stanici abc news sdělil , že interní citlivé sítě agentury nebyly „ vůbec “ ohroženy .
mluvčí řekl , že žádné utajované informace nejsou ohroženy .
minimálně jedna skupina hackerských aktivistů na internetu tvrdila , že je zodpovědná za vyřazení stránek nsa prostřednictvím útoku ddos .
útoky ddos jsou navrženy tak , aby zaplavily cílové webové stránky informacemi , dokud se servery nepřetíží a stránka nespadne .
tato kybernetická taktika je relativně prostá a smyslem útoků není proniknout do vnitřní sítě cílového systému .
bývalá supertajná agentura nsa , jež kdysi získala přezdívku žádná taková agentura , se v minulých měsících stala po šňůře odhalení zahraničních a domácích sledovacích programů středem pozornosti veřejnosti a terčem kousavé kritiky ­ souhrnně produkt odcizení tajných souborů nsa z agentury a jejich vyzrazení rozčarovaným bývalým zaměstnancem edwardem snowdenem .
tato rostoucí kontroverze obklopující agenturu podnítila dřívější spekulace , že dnešní nehoda byla výsledkem cílené kybernetické operace .
zisk společnosti bombardier se propadl v důsledku poklesu dodávek a objednávek
kanadský výrobce letadel a vlaků bombardier ohlásil ve čtvrtek patnáctiprocentní pokles čistého zisku , který je způsoben menším počtem objednávek a dodávek letadel ve třetím čtvrtletí a smluvními problémy ve vlakové jednotce .
společnost bombardier se sídlem v montrealu také nezveřejnila žádná data o letecké zkoušce pro své nové letadlo typu cseries , ani nenabídla aktuální informace , pokud jde o to , zda toto letadlo dodrží ambiciózní plán zahájit komerční provoz od příštího září .
po zahajovacím zkušebním letu asi před měsícem a půl letadlo letělo pouze třikrát a vyvstala tak otázka , zda testovací fáze postupuje dobře .
výsledky nenaplnily odhady a akcie na burze v torontu poklesly o 8 procent .
analytik státní banky cameron doerksen snížil ve čtvrtek rating z „ vyšší výnosnosti “ na „ výkon sektoru “ s očekáváním , že burza bude během příštího čtvrtletí či dvou zažívat omezený růst .
„ zatímco menší dodávky letadel jsme povětšinou očekávali , ziskové rozpětí v oblasti dopravy nás výrazně zklamalo , “ uvedl doerksen ve zprávě klientům .
s tím , jak bude zkušební program pokračovat , věříme , že společnost bombardier získá nové objednávky letadel cseries .
pokud však nebudou v nadcházejících měsících oznámeny žádné nové objednávky , předpokládáme , že vzroste skepse trhu vůči tomuto programu .
společnost bombardier doufá , že se letadla typu cseries probojují do spodní oblasti trhu , které nyní dominují boeing a airbus .
první zkušební letadlo bylo odhaleno v březnu a po několikaměsíčním zpoždění se v září konal první let .
počet závazných objednávek letadel cseries však dosahuje skromných 177 , protože potenciální kupci čekají na výsledky zkušebního letu , aby mohli ověřit tvrzení společnosti týkající se nízké spotřeby a úspor na nákladech tohoto dopravního letadla .
v současné době je celkem 403 objednávek a závazků od 15 zákazníků a provozovatelů .
výkonný ředitel pierre beaudoin očekával , že při uvedení prvního letadla do komerčního použití dosáhne společnost bombardier svého cíle 300 závazných objednávek .
vedoucí pracovníci také ve čtvrtek ujišťovali analytiky a média , že program postupuje podle plánu .
„ zkušební letadlo nezůstalo na zemi déle , než se očekávalo , “ řekl v konferenčním hovoru beaudoin a poznamenal , že přezkoušení na zemi a softwarové aktualizace byly naplánovány během odstávky letadla .
každý výrobce je plánuje jinak .
my jsme se rozhodli absolvovat první let a pak se zaměřit na aktualizace a to jsme udělali .
to se bude dít během celého letového programu .
podle společnosti bombardier by druhé z pěti testovacích letadel mělo vzlétnout v nadcházejících týdnech a ostatní nedlouho poté .
analytici jsou přesto skeptičtí vůči tomu , že by první zákazník mohl začít provozovat letadlo cseries 12 měsíců po jeho prvním letu .
společnost bombardier tvrdí , že vyhodnocovala svůj plán uvedení letadla do provozu a v následujících měsících poskytne aktualizované informace .
„ toto pomalé tempo letových zkoušek – přestože je v souladu s vnitřním plánem společnosti bombardier – zřejmě posílí náš názor , že uvedení do provozu bude posunuto na první čtvrtletí roku 2015 , “ řekl doerksen .
ze 172 milionů usd neboli 9 centů na jednu akcii v předchozím roce se ve třetím čtvrtletí končícím 30. září propadl čistý zisk společnosti bombardier na 147 milionů usd , neboli 8 centů na jednu akcii .
upravené výnosy na jednu akcii zůstaly nezměněny na 9 centech .
obrat marginálně poklesl z 4,2 miliard usd na 4,1 miliard usd .
podle systému ibes společnosti thomson reuters analytici očekávali výnos 10 centů na jednu akcii a obrat 4,56 miliard .
čtvrtý největší výrobce letadel uvedl , že oproti 57 letadlům o rok předtím dodal během daného čtvrtletí jen 45 letadel .
čisté objednávky spadly z 83 letadel na 26 .
nesplněné zakázky v letecké divizi tvořily k 30. září 32,9 miliard , což se nemění ani k 31. prosinci .
„ výsledky v letectví byly v souladu s našimi výhledy , ale nízký příjem objednávek a celkový stav trhu nás zklamal , “ řekl beaudoin .
výnos v leteckém průmyslu klesl o 13 procent na 2 miliardy usd .
bombardier , největší výrobce vlaků na světě , uvedl , že výnos v této divizi vzrostl téměř o 11 procent na 2,1 miliardy usd .
nesplněné zakázky v dopravě tvořily k 30. září 32,6 miliard , což je oproti 31. prosinci marginální růst .
ziskové rozpětí v dopravní divizi bylo ovlivněno problémy s realizací několika velkých kontraktů .
vedoucí pracovníci uvedli , že ve čtvrtém čtvrtletí budou poskytnuty nové výhledy .
akcie společnosti bombardier , která také oznámila příchod finančního ředitele společnosti google patricka pichettea , poklesly během obchodování ve čtvrtek odpoledne o 8,5 procenta na hodnotu 4,83 usd .
brazilská společnost embraer sa , třetí největší výrobce komerčních letadel a nejbližší konkurent společnosti bombardier , oznámila ve čtvrtek desetiprocentní propad ve čtvrtletním zisku .
právník závislý na kokainu , který varoval mafiána před policejním vyšetřováním , je ve vězení
basharat ditta ( 42 ) měl předávat informace králi podsvětí neilu scarbroughovi .
advokát se obával , že jeho drogová závislost vyjde najevo .
liverpoolský korunní soud ho odsoudil na tři roky vězení .
špičkový obhájce , který informoval drogového mafiána o velkém policejním vyšetřování , protože se bál , že jeho drogová závislost vyjde najevo , byl odsouzen na tři roky vězení .
basharat ditta ( 42 ) měl poté , co se stal podezřelým z užívání kokainu , šéfovi podsvětí neilu scarbroughovi předávat citlivé informace o vyšetřování jeho aktivit týkajících se pašování drog .
advokát , jehož přezdívka byla „ bash “ ( party ) a který byl kriminálníky oslavován jako nejlepší právní zástupce , byl po policejním sledování scarborougha , kterého v předešlých řízeních týkajících se narkotik zastupoval , v roce 2011 zatčen u sebe doma .
policisté spatřili sarborougha ( 32 ) , jak nechal v právníkově domě v blackburnu v lancashire , který byl právě na večeři se svými kolegy z právnické společnosti , tři sáčky s kokainem .
na základě zkoušek , při kterých se našly stopy kokainu v jeho vlasech , na jeho peněžence a jeho kreditních kartách , vyšetřování ukázala , že ditta byla pravidelným uživatelem drog třídy a .
během období osmi měsíců , od ledna do srpna 2011 , se snažil pokoutně získat informace o zatčení dvou mužů ve prospěch scarborougha a jeho společníka .
všichni čtyři podezřelí byli v té době sledováni v rámci velkého vyšetřování obchodování s heroinem a kokainem v oblastech lancashire , cumbria , merseyside , berkshire a west yorkshire .
poté , co během série zátahů policie zadržela heroin a kokain v hodnotě asi 1,5 milionů gbp spolu s 200 000 gbp v hotovosti , ve vězení spolu s nimi skončilo dalších 32 osob .
ditta ( 42 ) předával informace kriminálníkům ze strachu , že se přijde na jeho závislost na kokainu .
dnes ditta , který pracuje u právnické společnosti forbes solicitors se sídlem v blackburnu , zažil před liverpoolským korunním soudem ostudné chvíle , když byl po třítýdenním líčení shledán vinným z toho , že ve dvou případech bránil výkonu spravedlnosti .
během dřívějšího slyšení se přiznal k držení kokainu .
právníkův pád nastal poté , co se při policejním vyšetřování scarborougha zjistilo , že byl v únoru 2011 v pravidelném telefonickém kontaktu s dittou .
dva detektivové podezřelého sledovali , zaznamenali jeho příjezd do dittova domu a spatřili ho , jak umístil drogy o čistotě 60 procent pod právníkův koš v černé golfové rukavici .
následně byl scarborough s dittou , který byl na večeři na fotbalovém stadionu blackburn rovers v ewood park , v pravidelném telefonickém rozhovoru .
právník se vrátil domů , kde drogy našel , a mezi oběma osobami proběhlo devět rozhovorů .
u soudu zaznělo , že se nalezly stopy drogy třídy a v jeho vlasech , peněžence a na jeho kreditních kartách a že ditta byl „ pravidelným uživatelem “ kokainu .
ditta byl později zatčen , ale užívání kokainu popřel , a řekl , že s podezřelým dealerem mluvil proto , že byl jeho klientem , a argumentoval tím , že jejich rozhovor spadá do „ důvěrné komunikace “ .
během svého zatčení ditta vzal svou peněženku a snažil se z ní vyndat několik kreditních karet , ale všechny byly zadrženy a byly mu odebrány vzorky vlasů .
při policejním výslechu řekl , že provozoval kancelář jak na své domácí adrese , tak na pracovišti , a že ho klienti kvůli pracovním záležitostem navštěvovali i doma .
soud si však vyslechl , že po klíčových zatčeních kontaktoval významné hráče v drogovém dodavatelském řetězci , z nichž některé předtím zastupoval , aby jim sdělil , co o nich detektivové vědí .
prokurátorka anne whyte řekla : „ kdo jiný si je více vědom toho , že nesmí porušovat právo , než právní zástupce v trestněprávní oblasti . “
pan ditta je obviněn ze zneužití své pozice právního zástupce a z toho , že se dostal do příliš úzkého kontaktu s konkrétním klientem .
vztah , o kterém zde mluvíme , se netýká jen drogového dealera , ale drogového dealera , který svého vlastního právníka zásobuje drogami .
některé z jeho rozhovorů byly bezpochyby legitimní , protože byl jeho právníkem .
ale zašlo to daleko za hranice běžného vztahu právník-klient .
policejní vyšetřování mařil , jak nejvíce mohl , aby jim umožnil pokračovat v jejich trestné činnosti .
pan ditta své profesi dobrou pověst nepřinesl , naopak ji zneuctil .
s určitými svými klienty se příliš sblížil , obzvláště se scarboroughem , a dovolil , aby byla narušena jeho nezávislost .
ditta přestupek odmítl a prohlásil : „ pokud bych byl zkorumpovaným právníkem , kterým já nejsem , a chtěl bych panu scarboroughovi předat informace , nečekal bych 15 hodin , ale udělal bych to okamžitě . “
po slyšení však policejní inspektor lee halstead z lancashire řekl : „ pan ditta se z právního zástupce v trestněprávní oblasti sám stal kriminálníkem ve chvíli , kdy začal získávat drogy od organizovaných zločinců . “
jeho závislost na kokainu ho učinila beznadějně oslabeným a zranitelným vůči záměrům předních představitelů skupin organizovaného zločinu , které mu dávaly za úkol shromažďovat cenné informace o policejním vyšetřování .
právní zástupci se musí držet nejvyšších zásad bezúhonnosti a mají ve veřejnosti vzbuzovat důvěru a pocit , že se na ně mohou spolehnout .
pan ditta tuto důvěru zradil a snažil se skrýt za pláštíkem své profese .
jednotka pro závažné a organizované trestné činy v lancashire vedla proti panu dittovi vyšetřování , na základě kterého byl odsouzen také za tři případy držení kokainu a nyní za bránění výkonu spravedlnosti , což demonstruje náš závazek přivést zločince před soud .
tento případ by měl sloužit pro všechny zločince jako varování , že nikdo není mimo dosah ruky zákona .
najdeme vás a postavíme před naše soudy .
sám scarborough byl odsouzen na 14 let vězení poté , co byl prohlášen vinným ze spolčování za účelem dodávání heroinu , kokainu a konopí .
dalších třicet pět osob zapojených do obchodování bylo uvězněno celkem na 153 let za drogové přestupky .
na své webové stránce ditta o sobě uspořádal online rozhovor , ve kterém řekl , že jeho vysněnou prací by bylo právně zastupovat klienty z bloku cel smrti v americe , jako hosta na večeři by si přál mohammeda aliho a jako motivaci pro práci uvedl nerovnoprávnost .
vyjednával o vládě s klausem i špidlou .
teď lidovci jana kasala vyslali proti babišovi .
lidovci získali ve volbách čtrnáct poslanců , tedy jen třetinu počtu sociálních demokratů nebo zástupců ano .
do vyjednávání o vládě ale vstupují přinejmenším s jednou výhodou .
v týmu , který už začal dohadovat obrysy možné koalice , mají jana kasala - muže , který za lidovce ladil podmínky vládní účasti v letech 1992 , 1996 , 2002 i 2006 .
sociální demokraté ani andrej babiš takového matadora na své straně nemají .
asi to bude tentokrát připomínat první vyjednávání v roce 1992 , kdy ods byla také úplně nová strana .
&quot; zkušenosti byly tehdy minimální , &quot; odhaduje kasal , jak se budou letošní rozhovory vyvíjet .
keňský tisk pobouřen kontroverzním zákonem o médiích
„ je to děsivá zpráva a je na místě se ptát , co parlamentu zabrání v tom , aby zítra jednoduše nesmetl nezávislost soudnictví , “ uvedly noviny považující návrh zákona za protiústavní .
„ tento zákon je přísný a velmi represivní a my ho odmítáme , “ řekl cyrus kamau , generální ředitel skupiny capital group , do které patří i capitalfm , jedna z nejuznávanějších nezávislých rozhlasových stanic a zpravodajských webů .
řekl , že nový mediální tribunál „ bude vždy předpojatý , protože je prodlouženou rukou vlády “ a že omezení týkající se obsahu a reklamy poškodí pozici keni v celosvětové ekonomice .
„ doufám , že nás prezident vyslyší , a budeme ho žádat , aby odmítl tento návrh zákona a vrátil ho poslancům , “ řekl .
podle deníku star návrh zákona fakticky vládě předává „ úplnou kontrolu nad médii “ a noviny standard uvádějí , že demokracie a svoboda projevu v keni „ utržila tvrdou ránu “ , a kritizují návrh zákona jako „ přísný “ .
schválení návrhu zákona přichází uprostřed řady opatření směřujících k posílení národní bezpečnosti bezprostředně po zářijovém útoku islámského střelce v nákupním centru westgate .
hněv úřadů na sebe keňská média obrátila , když odvysílala záznam bezpečnostní kamery , na kterém vojáci poslaní na místo útoku údajně rabovali obchod s luxusním zbožím .
policejní ředitel reagoval tak , že nechal předvolat dva novináře a vedoucího mediálního pracovníka k výslechu , avšak předvolání bylo po nátlaku médií později staženo .
podle nového návrhu zákona mohou být mediální společnosti pokutovány až 20 miliony keňskými šilinky a jednotliví novináři až jedním milionem spolu s rizikem „ vyřazení ze seznamu “ nebo jim může být odepřena oficiální novinářská akreditace .
tribunál má také právo zabavit majetek pachatele , pokud není pokuta zaplacena .
podle listu daily nation „ je i jedna pokuta dost na to , aby zlikvidovala většinu rozhlasových stanic “ .
uvádí se také , že tato opatření mohou mít likvidační dopad na to , čemu se říká keňská „ živá blogosféra “ .
politici vědí , že když umlčí média , mohou si beztrestně dělat , co chtějí .
„ nikdy nevíte , co se může stát , “ napsal novinář listu nation mutuma mathiu a popsal keňská média jako klíčový zdroj systému vzájemné kontroly a vyvážení ve veřejném životě .
„ když to necháme na politicích , přivedou zemi k bankrotu a vrhnou nás zpět k lovu a sběru , “ napsal .
zákonodárci v keni byly v minulosti terčem kritiky veřejnosti .
v květnu hlasovali pro zrušení škrtů nařízených národní mzdovou agenturou a pro obnovení svých tučných platů kolem 532 000 nezdaněných šilinků měsíčně , které se tak řadí k nejvyšším na světě .
spořit se musí , vědí mladí češi .
většina z nich ale ani netuší s jakými úroky
stále víc čechů si dává peníze stranou .
přesto ale nedosahují na šampiony ve spoření v regionu .
nejvíc peněz si stranou totiž ukládají rakušané , kteří spoří měsíčně v průměru 181 eur .
o něco víc než češi spoří i lidé na slovensku .
vyplývá to z průzkumu skupiny erste savings barometr v zemích střední a východní evropy .
ukázalo se v něm také , že nálada střadatelů se zlepšuje a dvě třetiny dotázaných plánují , že si budou dávat stranou víc peněz .
zatímco češi jsou zhruba uprostřed žebříčku střadatelů , v rumunsku a srbsku lidé spořící produkty stále využívají velmi málo .
například téměř každý druhý srb si podle průzkumu spoří doma &quot; pod polštářem &quot; .
v tuzemsku letos stouplo množství těch , kteří si měsíčně spoří vyšší částky .
ještě loni si každý měsíc na nejrůznější druh spoření odkládalo tisíc až 2,5 tisíce korun 26 procent respondentů , letos je to o pět procent víc .
průměrná měsíční úložka v meziročním srovnání ale mírně klesla na 2078 korun .
největším hitem mezi spořicími produkty je penzijní připojištění .
to upřednostňuje 54 procent čechů , zatímco před třemi lety se jednalo o nejoblíbenější způsob pro zhodnocení úspor jen pro 36 procent lidí .
naopak klesá obliba stavebního spoření , oproti minulému roku se také výrazně propadl zájem o investiční fondy .
ty už využívá jen 16 procent respondentů , zatímco loni to byla téměř čtvrtina lidí .
v průzkumu se také ukázalo , že ačkoli lidé považují za důležité spořit , většina z nich neví , jakých výnosů na jednotlivých produktech dosahují .
především mladí lidé do 30 let nevědí , jak jsou jejich peníze úročené .
naopak nejlepší povědomí o výnosnosti svých uložených peněz má nejstarší skupina dotázaných , mezi lidmi nad padesát let to ví 73 procent dotázaných .
v mezinárodním srovnání skupiny erste češi vedou ve využívání on-line bankovnictví , které pravidelně používá 44 procent lidí .
následují je slováci a rakušané s 12procentním odstupem .
osn oslavuje nové cíle boje s chudobou
organizace spojených národů začíná bezodkladně pracovat na novém souboru cílů , které nahradí rozvojové cíle tisíciletí ( mdg ) , které byly zavedeny před 12 lety za účelem vypořádání se s celosvětovou chudobou .
před summitem osn o udržitelném rozvoji , který přes noc začal v riu de janeiru , hráli australští diplomaté klíčovou úlohu v prosazení „ udržitelných rozvojových cílů “ , které mají nahradit mdg , jejichž platnost vyprší v roce 2015 .
byly zahrnuty do finálního konceptu dokumentu , který bude schválený světovými vůdci , včetně paní gillardové , během summitu .
generální tajemník osn pan ki-mun přes noc na summitu řekl , že nyní je čas „ povznést se nad národní zájmy “ .
„ těší mě , že se členské státy dohodly na spuštění a převzetí procesu , který má zavést všeobecné cíle udržitelného rozvoje – sdg , “ řekl .
sdg budou stavět na pokroku , kterého bylo dosaženo v rámci rozvojových cílů tisíciletí a budou nedílnou součástí rozvojového programu po roce 2015 .
vynaložím veškeré úsilí , abych naplnil mandát udělený mi členskými státy a zrealizoval naši vizi o cílech udržitelného rozvoje , které staví na úspěchu mdg .
obavy o bezpečnost mosambiku se stupňují kvůli konfliktu silných osobností
pod sochou samory machely , mosambického prezidenta zakladatele , se v centru maputa sešli tisíce lidí , aby na vzácné veřejné demonstraci provolávali mírová hesla .
„ chceme zpátky mír ; chceme stabilitu , “ řekla vanessa de sousa , výkonná ředitelka investiční společnosti .
ze strachu o budoucnost své země vyměnila podnikový oděv za tričko ozdobené nápisem „ požadujeme bezpečí “ v portugalštině a připojila se ve čtvrtek k davu na náměstí nezávislosti v hlavním městě .
po dva týdny přicházely téměř denně zprávy o konfliktech mezi vládními silami a stranou renamo , o jedněch z nejhorších potyček od mírové dohody před více než 20 lety .
renamo bylo kdysi nechvalně známým povstaleckým hnutím , původně podporovaným bělošskou vládou v rhodesii a poté vládou apartheidu v jižní africe v rámci snah o destabilizaci nezávislé vlády této země .
po mírové dohodě v roce 1992 se stalo opoziční stranou .
analytici jsou přesvědčeni , že je nepravděpodobné , aby v zemi znovu vypukl otevřený konflikt , ale nedávné události polekaly zahraniční investory a místní .
v sázce je rychle rostoucí ekonomika , protože objevy rozsáhlých pobřežních rezerv ropy a ložisek uhlí na severozápadě mohou během několika následujících let přinést ze strany společností , jako jsou brazilské rio tinto a vale , italská eni a americká anadarko , investice v hodnotě více než 50 miliard dolarů .
vládnoucí strana frelimo , dominantní politická síla od roku 1975 , a renamo se navzájem obviňují ze vzniklého napětí .
strana renamo tvrdí , že vláda vyvolala poslední konflikty tím , že 17. září zahájila útok na jejich členy v provincii sofala , tradiční baště strany renamo .
násilné napadání bývalých rebelů následně vyvrcholilo , když vládní síly zaútočily na základnu strany renamo a pokusily se zabít afonsa dhlakamu , vůdce skupiny , řekl pro financial times mluvčí strany renamo fernando mazanga .
vláda obviňuje za spuštění konfliktů renamo , protože prý útočilo na vojáky .
prezident armando guebuza se snažil obavy z nestability zmírnit .
pan guebuza pro francouzskou tiskovou kancelář afp ve středu řekl , že pan dhlakama viděl sám sebe jako „ ztroskotance “ , který chtěl použít „ cokoli , co z jeho sil zůstalo , aby se pokusil dokázat , že může vládě nařídit svá vlastní rozhodnutí “ .
jak frelimo , tak renamo tvrdí , že se chtějí vyhnout válce .
obavy ale vzrostly , když byla citována slova pana mazangy , že strana renamo odstupuje od mírové dohody z roku 1992 .
listu ft řekl , že tím myslel , že strana frelimo již dohodu nerespektuje .
„ naším cílem je vrátit se k jednáním , ale s vážností , “ řekl pan mazanga .
předchozí rozhovory mezi těmito stranami udělaly pro zmírnění napětí mezi těmito stranami , rozdmýchané řadou potyček v tomto roce , jen málo .
je to šarvátka mezi dvěma velkými osobnostmi ( guebuza a dhlakama ) , řekl lektor na otevřené univerzitě a odborník na mozambik joseph hanlon .
ani jeden z nich není dobrým vyjednávačem a ani jeden z nich není připraven učinit potřebné ústupky .
strana renamo , která usilovala o volební změny , se již vyjádřila , že by bojkotovala komunální volby plánované na listopad .
prezidentské a parlamentní volby jsou naplánovány na příští rok .
někteří komentátoři interpretovali použití síly jako snahu skomírajícího hnutí získat od vlády výhody a finanční výtěžek .
volební podíl strany renamo se od roku 1992 snižuje , zatímco novější strana , demokratické hnutí mosambiku ( dhm ) , která byla založena bývalým členem strany renamo , podle očekávání svou pozici ve volbách zlepší .
pan mazanga říká , že pan guebuza – kterému příští rok končí druhé funkční období – chce zničit demokracii této země .
„ nechce demokratický systém více stran , nechce transparentní volby , nechce mír , protože nechce pustit prezidentský úřad , “ řekl mazanga .
je nejasné , jaké možnosti strana renamo má , ale provedl rozvratné teroristické útoky na policejní stanice a na vozidla na klíčové silnici mezi severem a jihem .
k většině potyček došlo v provincii sofala , která je sice několik set kilometrů vzdálená od hlavního města maputo , ale kde je město beira , přístav , na které spoléhají důlní společnosti , včetně společností rio tinto a vale , při svém vývozu uhlí .
v červnu společnost rio pozastavila asi na týden používání železnice , když strana renamo vyhrožovala , že na tuto linku zaútočí .
pan mazanga se nechtěl vyjadřovat k otázce , zda renamo svou hrozbu zopakuje .
renamo chtěl „ varovat mezinárodní komunitu , že situace v mosambiku není dobrá “ , řekl mazanga .
nestabilita zvýšila frustraci z vlády , říká fernando lima , hlava nezávislé mediální společnosti mediacoop , a mnoho lidí má také obavy kvůli korupci , pomalému tempu rozvoje a nedávné záplavě únosů .
„ lidé si myslí , že zodpovědnost za budoucnost země nese výhradně vláda a prezident a že on má být tím , kdo najde řešení problémů , “ říká .
demonstrant omar sultuane říká , že lidé jen chtějí stabilitu .
„ nikoho nezajímá ani renamo , ani frelimo , lidé jen zase chtějí mír , chtějí mít volný přístup na silnice , “ říká .
děti by se měly učit mýty a legendy jako „ modely pro způsob života “ , říká autor .
příběhy o thórovi mohou ukázat , že „ hrubá síla se nemůže rovnat chytré lstivosti “ , zatímco artušovské legendy odhalují , jak důležité je mít sen .
velká část mýtů by „ pro výuku ve škole byla až příliš divoká , až příliš skandální a v některých případech až příliš obscénní “ , řekl crossley-holland , který se přimlouvá za pečlivý výběr děl odpovídajícím věku .
„ myslím , že je skvělé , že mýty a lidová tvorba jsou již součástí vzdělání , “ řekl .
hájil jsem tento plán po dvacet let .
dodal , že „ otevřeně poučující “ autoři a učitelé jsou u poutavých příběhu s „ podprahovým “ poselstvím pro děti jako „ vypínač “ .
crossley-holland , který z anglosaštiny přeložil epos beowulf a který také píše norské mýty ( penguin book ) a britské národní báchorky , říká : „ můžete mít dobré úmysly , ale uděláte lépe , když si je necháte pro sebe . “
asi tím největším rozdílem mezi dospělým autorem píšícím pro dospělé a dospělým autorem píšícím pro děti je potřeba nějaké pocitu naděje .
ne snad , že vše musí být zjednodušeno nebo skončit happyendem , ale musí tam být přirozený smysl pro dobro a zlo .
a ten musí být podvědomý ; odhalený prostřednictvím příběhu , nikoli otevřeně stanovený .
stará pravda o tom , že je lepší ukázat než popisovat .
brněnská hvězdárna vezme návštěvníky do vesmíru v novém digitáriu
na první pohled je zřejmé , že sál velkého planetária se za posledního půl roku změnil .
je zde nové jeviště , návštěvníci se mohou zabořit do nových pohodlných sedaček a nad jejich hlavami přibyla projekční plocha o průměru 17 metrů ve tvaru kopule od americké firmy spitz .
uprostřed sálu je jeho nejdůležitější část , nový projektor z japonska .
aby byl obraz dokonalý , jsou po sále rozesety další menší projektory .
další důležitá část celého zařízení je ukrytá za zdmi sálu .
&quot; jde o dvacet jedna počítačů , které generují obraz , &quot; řekl ředitel brněnské hvězdárny jiří dušek .
počítače zajistí , aby se obraz z několika projektorů nepřekrýval , ale dával ucelený dojem .
&quot; výkon počítačů je třicetkrát až čtyřicetkrát vyšší než u klasických osobních počítačů , &quot; podotkl technik z hvězdárny tomáš hladík .
digitárium dokáže vykouzlit mimořádně realisticky a plasticky model noční oblohy , lidského těla či dna oceánu .
diváci se tak octnou přímo uprostřed vesmíru nebo mozku člověka .
další podobné zařízení je nejblíže ve varšavě či hamburku .
vedení hvězdárny plánuje v sále promítat nakoupené pořady i vlastní tvorbu .
od soboty jsou na programu dva pořady .
první se jmenuje astronaut a je určený pro dospělé .
lidé se v něm dozví o tréninku kosmonautů , vyletí do vesmíru , zatočí se na centrifuze , a pak na názorných příkladech uvidí , jak náročným podmínkám astronauti v kosmu čelí .
druhý pořad je pro děti a má název kouzelný útes - kaluoka &apos; hina .
vypráví příběh útesu , jehož pestrobarevní obyvatelé žili poklidným životem až do okamžiku , kdy došlo k výbuchu nedaleké sopky .
celé digitárium stálo zhruba padesát milionů korun , které zaplatilo převážně ministerstvo školství .
menšími částkami přispělo i město brno a hvězdárna ze svého rozpočtu .
projekční plocha stála deset milionů korun , projektor dvanáct milionů .
&quot; zbytek spolkla audiovizuální technika a počítače , &quot; vysvětlil dušek .
instalace digitária následovala po rekonstrukci celé budovy , kterou hvězdárna prošla před dvěma lety .
podle ředitele duška by ještě do konce roku mohlo přijít 25 až 30 tisíc návštěvníků .
prostudovali jsme 11 tisíc inzerátů !
víme , kde vás chtějí do práce !
v listopadu loňského roku analýza zachytila přes 11 tisíc inzerátů nabízejících pracovní místo , z toho 4300 jich bylo uveřejněno v denním tisku a 6800 inzerátů ( 62 procent ) na internetu .
internet se tedy stává nejvýznamnějším médiem pro zveřejňování nabídek zaměstnání .
ještě v roce 2005 , kdy se průzkum uskutečnil poprvé , činil jeho podíl 26 procent .
v posledních dvou šetřeních ( 2007 , 2010 ) se ustálil na zhruba 60 procentech .
inzerce pracovních možností v sobě podle analýzy značnou měrou odráží aktuální situaci na trhu práce .
příkladem může být prosté srovnání počtu uveřejněných inzerátů v období ekonomické prosperity a v době ekonomické krize .
například v roce 2007 bylo ve stejném sledovaném období uveřejněno téměř 25 900 inzerátů , v roce 2012 to byla méně než polovina .
nabídka pracovních pozic na internetu je orientována na užší , zejména více kvalifikovanou skupinu profesí .
naproti tomu nabídka zaměstnání v denním tisku pokrývá širší spektrum profesí včetně těch dělnických , uvedla autorka analýzy pavlína šťastnová .
míra zastoupení vybraných profesních skupin je u obou médií různá .
na internetu zaujaly přední místa inzeráty hledající manažery a vedoucí pracovníky , obchodní zástupce , programátory a finanční experty .
pozice programátorů či vedoucích malých podniků figurovala pouze na internetu .
v denním tisku je podíl těchto odborných profesí výrazně nižší , naopak velké zastoupení patří zejména obslužným a dělnickým profesím .
mezi nejčastěji uváděné požadavky , které zaměstnavatelé vyjadřují prostřednictvím inzertní nabídky , patří samozřejmě vzdělání .
k dalším sledovaným oblastem patřila znalost cizích jazyků , zejména angličtiny .
v denním tisku byl požadavek na znalost cizího jazyka uveden ve třech procentech inzerátů , na internetu v 37 procentech .
pouze ve dvou procentech inzerátů zaměstnavatelé požadovali aktivní znalost dvou cizích jazyků .
nároky na &apos; počítačovou gramotnost &apos; se objevily ve 40 procentech inzerátů ( v denním tisku v 11 procentech , na internetu v 57 procentech ) .
praxe v oboru byla požadována v 54 procentech inzerátů .
požadavky na praxi jsou vesměs spojovány s kvalifikovanými profesemi .
jde zejména o vedoucí výroby a další vedoucí pracovníky .
u dělnických profesí jde zejména o mechaniky a opraváře nebo výrobce a zpracovatele potravinářských výrobků či o opraváře elektrických přístrojů , doplnil autor studie jiří tillner .
zaměstnavatelé také v polovině svých inzerátů uvádějí požadavky na vlastnosti a dovednosti případných uchazečů .
jako nejčastěji požadované dovednosti se v inzerci na prvním místě již dlouhodobě objevují komunikační dovednosti .
dále zaměstnavatelé požadují flexibilitu , adaptabilitu a dynamiku , samostatnost , zodpovědnost , organizační schopnosti a spolehlivost .
ben greenman : desáté výročí newyorského festivalu komedie : new yorker
mohlo by se tvrdit , že město new york je místem , kde se v americe zrodila sólové komické vystoupení : téměř před sto lety varietní umělec frank fray , který pracoval jako předseda obřadů v divadle palace theatre na broadwayi , začal shromážděným lidem vyprávět vtipy metodou rozhovoru .
fayova inovace se během let rozšířila , nejnověji prostřednictvím newyorského festivalu komedie .
festival založený a řízený caroline hirschovou , zakladatelkou instituce sólové komedie carolines , slaví letos své desáté výročí – spolu s více než šedesáti představeními v malých klubech i velkých divadlech .
„ většina z těchto titulů se objevila v carolines a stala se úspěšnou do té míry , že jsou příliš velká , než aby se hrála v klubu , “ řekla hirschová .
tento festival jsme vytvořili jako možnost , jak s nimi nadále pracovat .
letošní událost zahrnuje vystoupení wandy sykesové , kathy griffinové a billa mahera , stejně jako „ stand up for heroes “ ( postavit se za hrdiny ) , každoroční muzikálně komediální benefiční představení v madison square garden , na kterém kromě jiných vystoupí bruce springsteen , jon stewart , roger waters a bill cosby .
stejně jako se rozšířil tento festival , rozšířil se i svět komedie .
několik komiků účastnících se letošního festivalu vzešlo z netradičních kanálů , jako jsou show v menších rozhlasových či televizních společnostech , například comedy central , fx a spike .
nick kroll se vyšvihl se svým sitkomem ( vesele pikantní „ league “ na fantasticko-fotbalové téma na fxx ) a nyní má vlastní komediální show na stanici comedy central .
jenny slateová byla členkou jak programu „ saturday night live “ , tak „ parks and recreation “ , ale nejvíce se proslavila rychle se šířící sérií videí „ marcel the shell with shoes on “ ( mušle marcel v botách ) .
jak kroll , tak slateová , stejně jako jiní mladí komici s jasně rozpoznatelnými hlasy ( surreálně pesimistický anthony jeselnik , jízlivý , rasově zaměřený w . kamau bell ) , jsou produktem decentralizovaného světa americké komedie .
jedním z největších taháků festivalu bude rozhovor : david steinberg bude hovořit s larry davidem .
steinberg začal jako sólový komik , ale stal se úspěšným televizním a filmovým režisérem , stejně jako neoficiálním historikem komedie .
od roku 2005 do roku 2007 pořádal na stanici tv land show nazvanou „ sit down comedy with david steinberg “ .
setkání se koná v town hall v centru manhattanu .
„ toto město je rozhodně v komediální dna celé larryho práce , “ řekl steinberg .
řekl mi , že když je tady , prochází se občas uličkou mezi dvěma budovami a říká si : člověče , jestli přijdu o všechny peníze , možná budu žít tady .
cena ropy se dále propadla na 96 dolarů za barel
cena ropy v pátek nadále klesala , jak obavy o vysoké zásoby vyvážila zpráva , která ukázala posilování čínského výrobního sektoru lačnícího po energiích .
americký ropný ukazatel pro prosincové dodávky během pozdního rána klesl v evropském elektronickém obchodování na newyorské obchodní burze o 14 centů na 96,24 dolarů za barel .
ve čtvrtek byl pokles 39 centů a pro měsíc říjen zaostal o 5,8 procent .
bohaté zásoby ropy v minulých týdnech zatěžovaly cenu .
ministerstvo pro energetiku ve středu prohlásilo , že americké zásoby se poslední týden zvýšily o 4,1 milionů barelů .
za pět týdnů se zásoby zvýšily o více než 25 milionů barelů .
v pátek však ze dvou zpráv o čínské výrobě přišel podnět k větší poptávce , který ukázal růst v činnosti .
to naznačuje , že ekonomické zotavení číny by po růstu , který se po předchozích dvou slabých dekádách vzchopil ve třetím čtvrtletí na 7,8 procent , mohlo nadále posilovat .
ropa brent , ukazatel pro mezinárodní ropu používaný také americkými rafineriemi , spadla na mezinárodní obchodní burze v londýně o 26 centů na 108,58 dolarů za barel .
tak to ne , pane hašku .
máme jedinečnou možnost , jak vzkázat politikům , že takto ne .
je třeba vyvinout takový tlak , aby martin hašek byl zbaven všech politických funkcí a opustil poslanecký mandát .
jakékoliv jiné řešení sníží úroveň politické kultury , která je již tak mizivá .
martin hašek se zaštíťuje slibem , který dal , ale každý a politik obzvlášť si musí být vědom důsledků daného slibu a velice zvažovat , co lze slíbit .
důvěra je jediný kapitál , který politik má ( pan babiš má i ten hmotný , ovšem je otázkou , zdali je politik ) .
sebelepší program prosazovaný lhářem je nedůvěryhodný .
v politice se neomlouvá , v politice se odstupuje .
pane hašku , jestli to myslíte dobře s touto zemí ( a vaše častá prohlášení mě v tom utvrzují , pokud jste tedy zrovna nelhal - tady vidíte , jak je to se lhaním složité ) , opustíte politiku sám , jako chlap .
lidé pak vaši omluvu přijmou jako vyjádření muže , který udělal chybu a nese za ni svou odpovědnost .
v opačném případě budete vnímán jako bezpáteřní slaboch , jehož slovům ani činům nelze věřit .
buď chcete být hrdým , byť chybujícím člověkem nebo doživotní sketou .
možná se vám zdá , že je nespravedlivé , když oslovuji jen vás , ale vy jste přeci vůdce a oni jen pomýlené ovce .
a vůdce jste a vždycky jste chtěl být .
chápu , že se teď pokoušíte na chvilku sklopit uši , přeskupit síly , vysedět tu ostudu a pak zaútočit znova , ale tak se chovají partyzáni nebo podrazáci .
vy jste , opakuji , ve svých očích vůdce , alfa samec , tak se tak chovejte .
přijměte odpovědnost a odejděte z politiky .
soud zablokoval nařízení týkající se postupu zastavování a prohledávání osob policejním oddělením v ny
federální odvolací soud ve čtvrtek zablokoval soudní nařízení požadující změny v programu zastavení a prohledání osob na policejním oddělení v new yorku a soudkyni z případu odvolal .
druhý americký odvolací federální soud řekl , že rozhodnutí soudkyně shiry scheindlinové bude odložené až do rozhodnutí o odvolání , které město podalo .
soudkyně v srpnu rozhodla , že město porušilo ústavu tak , že realizovalo svůj program zastavování a dotazování lidí .
město její závěry a její opravná nařízení napadlo , včetně rozhodnutí přidělit dozor , který by policejnímu oddělení pomohl změnit své postupy a svůj školící program s nimi spojený .
odvolací soud vyslechl v úterý argumenty pro požadované odložení .
odvolací soud řekl , že soudkyně musí být z případu odvolána , protože se dostala do konfliktu s pravidly chování pro soudce , a to tím , že jako soudkyně nejednala podle požadavku vyhnout se zdání podjatosti , částečně kvůli sérii rozhovorů s médii a veřejným prohlášením , kterým otevřeně reagovala na kritiku soudu .
soudkyně rozhodla , že policejní úředníci porušili občanská práva desetitisíců lidí , když se neprávem zaměřili na černochy a hispánce v rámci svého programu zastavení a prohledání osob .
ustanovila nezávislý dozor , aby dohlížel na hlavní změny včetně reformy v postupech , školení a dozoru , a nařídila spuštění pilotního programu za účelem testování kamer nošených na těle v některých oblastech , kde dochází k nejčastějšímu zastavování osob .
v srpnu město new york odsouhlasilo ukončení metody uchovávání jmen a adres lidí , jejichž případy byly po policejním prohledání zamítnuty .
ústní zdůvodnění odvolání města je naplánováno někdy po 14. březnu 2014 .
taktika zastavování a prohledání osob kritizovaly řady ochránců občanských práv.
v určité formě existuje zastavování a prohledání osob už asi řadu desetiletí , ale zaznamenané prohlídky pod správou nezávislého starosty michaela bloomberga dramaticky narostly na rekordní počet 684 330 v roce 2011 , ve většině případů šlo o černochy a hispánce .
v roce 2004 sepsali čtyři muži , kteří všichni patří mezi menšiny , žalobu , jež se stala případem skupinové žaloby .
zastánci změn programu zastavování a prohledání osob prováděném policejním oddělením v ny tvrdí , že změny ukončí nespravedlivé praktiky , zvýší důvěryhodnost a efektivitu policejního sboru a mohou ovlivnit to , jak tyto postupy používají jiná policejní oddělení .
oponenti tvrdí , že změny sníží policejní morálku , ale ne zločinnost , a že se tím promrhají peníze , ale nevyřeší se širší problém , kdy je policejní sbor pod tlakem poté , co se za poslední dekádu snížily jeho počty o několik tisíc osob .
soudkyně poznamenala , že neukončila praktiku zastavování a prohledávání osob , která je ústavní , ale reformovala způsob , jakým prohlídky policejní oddělení v ny zavedlo .
pětina nákupních center se potýká s nízkou návštěvností
vyplývá to z údajů realitních poradenských společností cushman &amp; wakefield a jones lang lasalle .
v pražských bohnicích se otevírá veřejnosti obchodní centrum krakov , bude 19. pražským nákupním centrem .
v čr je nyní celkem 90 velkých obchodních center .
neuspokojivý výkon se týká asi 20 procent středně velkých a velkých center .
hlavní problémy jsou neadekvátně velké centrum vůči lokalitě a špatné layouty , tedy příliš moc pater nebo komplikované a nepřehledné uspořádání pasáží , případně mrtvá místa center , &quot; uvedl michal soták ze společnosti cushman &amp; wakefield .
také podle vedoucí oddělení maloobchodních nemovitostí jones lang lasalle sylvie samadi se asi pětina obchodních center potýká s nízkou návštěvností .
mezi hlavní důvody patří mj. špatná dopravní dostupnost , nízká příjmová kategorie lokálních obyvatel nebo přesycenost trhu v daném místě .
některé projekty otvíraly téměř plně obsazené , ale jejich výsledky byly hlavně zpočátku neuspokojivé .
v dnešní době jsou zákazníci poněkud konzervativní a neradi mění svoje nákupní zvyklosti .
nová obchodní centra se musí více snažit &apos; lákat &apos; své zákazníky na nové značky na trhu , zábavu , služby a marketingové akce , &quot; dodala samadi .
obsazenost nákupních center je podle sotáka obecně stabilní , dokonce u některých center stoupá , protože pronajímatelé byli ochotní v krizi slevit z nájemného a dopronajmout některé jednotky .
&quot; je ale pravda , že se v poslední době otevřely některé projekty , které nejsou plně obsazené a průměrnou obsazenost tak snižují ( například breda &amp; weinstein v opavě , šantovka v olomouci ) , &quot; dodal soták .
obchodní centra otevřená v minulých dvou letech se na trhu prosazují podle sylvie samadi velmi pomalu .
místo na trhu pro nové projekty ale existuje .
počet míst vhodných pro výstavbu úspěšného projektu je velice limitován .
například v praze vidíme prostor pro výstavbu projektu , který by sloužil obyvatelům prahy 6 .
na trhu určitě je prostor pro výstavbu menších lokálních projektů , takzvaných &apos; convinience centres &apos; , zaměřených na nákupy a služby denní potřeby pro obyvatelstvo žijící v bezprostředním okolí , &quot; uvedla samadi .
také podle sotáka existuje na tuzemském trhu místo pro další nákupní centra .
a to jak pro malá &apos; obslužná &apos; centra , tak pro velké projekty v praze , nebo středně velké projekty , nebo rozšíření v regionálních městech .
&quot; města jako kladno , české budějovice , brno nebo plzeň mají prostor pro další růst , &quot; dodal soták .
v praze vidí prostor pro připravované obchodní centrum na vítězném náměstí , dále mají podle něj jasný potenciál ulice na příkopě a václavské náměstí .
&quot; intenzivně se rozvíjí expanze retail parků , které umožňují obchodníkům pokrytí a expanzi do stále menších měst za příznivé nájemné a provozní náklady , prostor je také ještě v některých lokalitách pro menší lokální či sídlištní nákupní centra , respektive jejich rekonstrukce jako je například rekonstrukce obchodních domů prior , které těží z dobré lokality , &quot; dodala dita kubánková ze společnosti dtz .
v česku je v současné době umístěno 90 moderních nákupních center s celkem více než 2,2 milionu metrů čtverečních hrubých pronajímatelných ploch .
čtvrtina všech těchto nákupních center je umístěna v praze .
mezi 20 největšími nákupními centry , dle počtu nájemců , jich devět je v praze , vyplývá z údajů společnosti incoma gfk .
v počtu nákupních parků je čr pod průměrem eu , v porovnání s hodnotami z británie a francie zaostává česko asi o 50 metrů čtverečních na tisíc obyvatel .
coulson se naboural do telefonu , aby si ověřil tip
bývalý editor novin news of the world ( notw ) andy coulson údajně použil metody „ nabourání se do telefonu , sledování a konfrontace “ , aby si potvrdil podvodný tip na milostný vztah , do kterého měl být zapojen tehdejší ministr vnitra charles clarke .
státní zástupce andrew edis u soudu old bailey řekl , že noviny news of the world zachytily v květnu 2005 falešné zprávy , že clarke byl viděn se svou „ atraktivní zvláštní poradkyní “ hannah pawlbyovou .
noviny pověřily soukromého vyšetřovatele glenna mulcairea , aby se naboural do hlasové schránky pawlbyové a pronikl do jejího soukromí , ale u soudu zaznělo , že i coulson jí volal a nechával jí hlasové zprávy .
„ státní zástupce naznačuje , že pan coulson , který je nyní editorem notw , není člověkem , který stojí před domem a doufá , že lidi chytne venku , ale člověkem , který rád lidem podsouvá příběhy , aby viděl , co na to řeknou , “ uvedl pan edis .
řekl , že noviny notw používaly tři způsoby zkoumání příběhů : nabourávání se do telefonu , sledování a konfrontaci .
editor je osobně zapojen do třetí metody .
evidentně ví o té druhé , sledování , musí o ní vědět .
a co ta první ?
ví o nabourávání se do telefonu ?
on říká , že ne , my říkáme : „ ale jistě , že ví . “
fámy o milostném vztahu , do kterého je zapojen clarke , byly poprvé zachyceny oddělením pro reportáž novin notw , když zdroji , který se sexuálně zajímal o paní pawlbyovou , bylo řečeno : „ jen ztrácíte čas , ta je s charlesem . “
záznam s hlasovými zprávami vzatými z jejího telefonu při minimálně třech příležitostech , byl získán v mulcairově domě v srpnu 2006 .
vyšetřovatelé také našli záznamy v počítači soukromého vyšetřovatele , kde byly paní pawlbyová a její sestra označovány jako „ projekty “ .
během doby , kdy byla paní pawlbyová vyšetřovaná , dostávali její prarodiče anonymní telefonáty , ve kterých byli žádáni o informace o pawlbyové , řekl pan edis .
mezitím bývalý hlavní zpravodaj neville thurlbeck a bývalý zpravodaj james weatherup dohlíželi na sledování pohybu paní pawlbyové .
coulson jí 18. června 2005 zanechal hlasovou zprávu , v které jí sdělil : „ dostal jsem příběh , který se chystáme zítra vydat a o kterém bych si s charlesem moc rád popovídal . “
pan edis říká , že zapojení coulsona v příběhu bylo podle stejného modelu jako u dalších významných osobností , mezi něž patří bývalý ministr vnitra david blunkett .
u soudu ve čtvrtek zaznělo , že coulson konfrontoval pana blunketta kvůli milostnému vztahu s vdanou ženou , zatímco on sám se vídal se spoluobžalovanou rebekou brooksovou , která tehdy byla vdaná .
coulson a brooksová popřeli spolčení s jinými osobami za účelem nabourání se do telefonů v období od 3. října 2000 do 9. srpna 2006 .
mulcaire , thurlbeck a weatherup se přiznali k nabourání se do telefonu .
odhalení nsa zvyšuje společenskou paranoiu sledování ze strany státu
jednoho pokojného dne ke konci srpna německý policejní vrtulník bzučel nad americkým konzulárním úřadem ve frankfurtu , hlavním městě německé ekonomiky .
na pokyn spolkového úřadu na ochranu ústavy ( bfv ) , německé domácí zpravodajské agentury , bylo účelem mise pořídit fotografie střechy americké předsunuté hlídky , která je umístěna méně než 5 km od evropské centrální banky a bundesbanky .
německá média tvrdí , že úřad bfv doufal , že bude moct identifikovat přítomnost odposlouchávacích antén , a tato akce spustila v berlíně výměnu názorů mezi americkým a německým ministrem zahraničí .
james clapper , americký ředitel národního zpravodajství , v září znovu trval na tom , že spojené státy nepoužívají své zahraniční zpravodajské možnosti , „ aby kradly obchodní tajemství zahraničních společností ve prospěch amerických společností a posílily tak jejich mezinárodní konkurenceschopnost nebo zvýšily jejich zisk “ .
ale od té doby , co edward snowden , který se ze spolupracovníka stal informátorem , začal odhalovat svou cennou sbírku z tajného sledování spojenými státy , evropské vlády a přední podnikatelé už nevědí , jestli mají slovům ředitele věřit .
po zprávách , že americká národní bezpečnostní agentura prováděla špionáž v brazilské ropné společnosti a získala přístup k datům , s nimiž disponují američtí cloudoví poskytovatelé včetně společností google a yahoo , dosáhla všeobecná paranoia o státním sledování nových rozměrů .
poslední kapka přišla s odhalením , že telefon kancléřky angely merkelové byl možná deset let odposloucháván .
pokud může být terčem nejmocnější osoba v evropě , pak jsou jistě potenciálním terči i přední podnikatelé .
snowden zprůhlednil intenzivní spolupráci mezi americkými zpravodajskými službami a společnostmi .
řekl bych , že je možné , že jsou tato data používána k vzájemnému prospěchu .
„ německo se musí probudit , “ řekl oliver grün , prezident společnosti bitmi , která zastupuje malé a střední it společnosti v německu .
podle průzkumu vydaného v červenci poradenskou službou ey jsou německé společnosti přesvědčeny , že pokud jde o průmyslovou špionáž a krádeže dat , usa nyní představuje stejně velké riziko jako čína .
v celé dokumentaci odhalené panem snowdenem však doposud není žádný důkaz , že spojené státy předávaly obchodní tajemství zahraničních firem svým vlastním společnostem .
politici vyjádřili obavy , že eu chybí určité schopnosti v oblasti it a internetu , a uvedli , že by se měla snažit omezit svou závislost na usa :
přední podnikatelé jsou vůči tomu skeptičtí .
z německého parlamentu se ozývají hlasy , že bychom měli vyrobit německý google .
já jen mohu zavřít oči a zase je pomalu otevřít ...
to není cesta , říká hasso plattner , předseda německé softwarové společnosti sap .
pokud někdo chtěl silný evropský it průmysl , neměl ho před 20 lety nechat zemřít .
všechno v německu se dotuje , od uhlí po auta a zemědělce .
všechno kromě it průmyslu .
rozsah a technická propracovanost amerických špionážních agentur odhalených snowdenem je pro některé společnosti , kteří se doposud domnívaly , že největší hrozbu ze sledování představuje čína , přesto šokující .
nastává velký obrat v cloudové výpočetní technice , kde si evropští představitelé v širším rozsahu uvědomili , že data uložená v usa spadají pod tamní jurisdikci , a proto jsou potenciálně napadnutelná .
podle průzkumu provedeného obchodním společenstvím cloud security alliance cca 10 procent neamerických členů po odhalení programu usa prism na dolování dat zrušilo plány použít cloudového poskytovatele se sídlem v usa .
jim snabe , jeden z generálních ředitelů sap , říká : „ máme tu novou otázku pro zákazníky , která tu před rokem nebyla - kde jsou moje data uložena a můžete garantovat , že v této jurisdikci fyzicky zůstanou ? “
mnozí němečtí vysocí činitelé argumentují , že poslední zprávy jsou jenom potvrzením toho , co už věděli : že mocné státy chtějí odcizit jejich nejcennější tajemství a tato data musí být za každou cenu chráněna .
že se provádí ekonomická špionáž , není překvapením .
vždy se to dělo .
„ je to zásadní téma již mnoho let a významně se to nezměnilo ani během současné diskuse , “ říká kurt bock , generální ředitel agrochemické společnosti basf .
američané na nás provádějí špionáž na obchodní a průmyslové úrovni , stejně jako my provádíme špionáž na nich , protože je v našem národním zájmu bránit naše podniky .
podnikoví vedoucí se obecně moc nechtějí chlubit protiopatřeními , která učinili , aby tím případně neposkytli útočníkovi výhodu .
v případě velkých společností se již dlouho připomíná , že vzít si na veletrhu zdarma paměťový usb disk nebo nechat nechráněný notebook v hotelovém pokoji je minimálně nerozumné .
ulrich hackenberg , člen představenstva automobilky audi , říká , že již mnoho let je běžnou praxí sbírat před schůzkou představenstva mobilní telefony , aby je nebylo možné použít jako odposlouchávací zařízení .
německý úřad bfv vedoucím pracovníkům radí , aby zvážili , zda nepoužívat na zahraničních cestách jednoduché předplacené mobilní telefony kvůli riziku , že chytré telefony lze zpronevěřit .
předplacené mobilní telefony se poté vyhodí .
je zde však obava , že malé a střední podniky budou nadále vůči hackerství a sledování zranitelné .
v německu jsou mnohé z těchto společností ve svých specifických oblastech čelními představiteli globálního trhu .
„ malým a středním podnikům často chybí zkušenosti , personál a finanční zdroje , aby efektivně ochránily podniková tajemství vůči neautorizovanému přístupu , “ varuje ve své zprávě bfv .
usa své vlastní společnosti varuje před ekonomickou špionáží ze strany jiných zemí .
podle listu washington post americké dokumenty national intelligence estimate uvedly v únoru francii vedle ruska a izraele v druhé řadě pachatelů , kteří se zapojují do hackerské činnosti pro ekonomické zpravodaje , a to hned za čínou .
člen rady v německé bezrizikové společnosti učinil závěr , že pokud jde o ekonomickou špionáž , „ jsou francouzi nejhorší “ .
bernard squarcini , bývalá hlava francouzské vnitřní zpravodajské agentury dcri , tento měsíc v jednom z rozhovorů prohlásil : „ služby zcela dobře vědí , že všechny země , i když spolupracují v boji proti terorismu , provádějí špionáž na svých spojencích . “
rodiče nezletilého chlapce z georgie , který zemřel při podivné nehodě , věří , že byl zavražděn
rodiče nezletilého chlapce z georgie , jehož tělo se našlo uvnitř smotané zápasnické duchny v tělocvičně jeho střední školy , věří , že jejich syn byl zavražděn , řekl právník rodiny ve čtvrtek .
kendrick johnson z města valdosta v georgii byl 11. ledna nalezen zakleslý v narovnané duchně za tribunami v tělocvičně střední školy , kam chodil .
šerifovi vyšetřovatelé z okrsku lowndes county učinili závěr , že johnson zemřel nešťastnou náhodou , ale rodina sedmnáctiletého mladíka to odmítá .
„ jsou jednoznačně přesvědčeni , že jejich syn byl zavražděn , “ řekl pro foxnews.com právník benjamin crump , který zastupuje kennetha a jacquelyn johnsonovy .
nikdy nevěřili tomu , že zemřel tak , jak prohlásil šerif .
„ jsou přesvědčeni , že to odporuje logice , fyzikálním zákonům a také zdravému rozumu , “ řekl crump .
domnívají se , že se tím má ututlat , co se opravdu stalo , aby se ochránila osoba odpovědná za smrt jejich syna .
„ jako obvykle svého syna poslali do školy a ten se jim vrátil v pytli na mrtvoly , “ řekl .
státní zástupce michael moore ve čtvrtek řekl , že vede běžné vyšetřování johnsonovy smrti , a poznamenal , že několik klíčových otázek zůstalo nezodpovězeno .
co bylo příčinou smrti ?
byla jeho smrt důsledkem trestného činu ?
prohlásil moore na tiskové konferenci ve čtvrtek odpoledne .
fakta budu sledovat , ať už mě povedou kamkoli .
mým cílem je zjistit pravdu .
„ jsem toho názoru , že existuje dostatečný základ pro běžné vyšetřování , “ řekl .
moore novinářům sdělil , že původní pitva naznačila , že johnson zemřel v důsledku „ polohového zadušení “ .
druhá pitva však podle moore uvedla jinou příčinu smrti .
„ je zde několik otazníků , které musí být zodpovězeny nebo potvrzeny , “ řekl .
moore dodal , že pokud v případu smrti johnsona odhalí dostatek důkazů pro příkaz k vyšetřování trestného činu nebo porušení občanských práv , požádá fbi a jeho provedení .
zástupce kanceláře šerifa z okrsku lowndes nebyl ve čtvrtek ihned k dispozici pro případný komentář .
soudce z jižní georgie ve středu úřadům nařídil , aby daly k dispozici všechna videa ze sledovacích kamer , která vyšetřovatelé prohlédli .
rodiče mladistvého doufají , že videozáznamy budou obsahovat stopu vedoucí k odhalení toho , jak jejich syn zemřel .
centrum cdc vydalo pro školy směrnice ohledně alergie u dětí
ve středu centrum pro prevenci a kontrolu chorob ( cdc ) vydalo soubor směrnic , které mají pomoci v případě dětských alergií na potraviny ve škole .
jedná se o první soubor takových směrnic , které vláda usa vydala , a to kvůli tomu , že počet dětí školního věku , které trpí alergiemi na potraviny , stoupá .
jedno z 20 dětí ve spojených státech má alergii na potraviny .
centrum cdc zjistilo , že výskyt alergií na potraviny u dětí stoupl mezi lety 1997 a 2007 o 18 procent .
směrnice obsahují pro školy informace o tom , jak učitelský sbor a personál uvědomit o dětských alergiích na potraviny a jak na alergickou reakci , pokud nastane , reagovat .
také školám doporučuje mít k dispozici adrenalin – nejčastěji se používá automatický injektor značky epipen – , aby byly schopné reagovat na potenciálně životu nebezpečnou přecitlivělost .
státní zákonodárné orgány nedávno aktualizovaly pravidla , která školám umožňují skladovat adrenalin jednodušeji .
zpráva také obsahuje seznam typických symptomů objevujících se v rozhovorech s dětmi , které mají alergickou reakci .
dítě může říct : „ je to , jakoby mi někdo píchal do jazyku “ , „ mám pocit , že mám na jazyku chlupy “ nebo „ svědí mně jazyk “ .
rodiče intersexuálních dětí mohou zvolit „ neurčité pohlaví “
německo se stalo prvním evropským národem , který uznává třetí pohlaví u dětí narozených s nejednoznačným pohlavním ústrojím .
novorozené děti už nebudou řazeny pouze buď k mužskému , nebo ženskému pohlaví .
nový zákon od rodičů nepožaduje , aby pro takové děti uvedli kterékoli pohlaví , a umožňuje jim na jejich rodných listech uvést pohlaví jako „ neurčité “ nebo „ nespecifikované “ .
cílem zákona je přestat tlačit na rodiče , aby se u svého dítěte ukvapeně rozhodli pro operaci za účelem určení pohlaví , a bojovat proti diskriminaci těch , kdo jsou intersexuální .
jedna intersexuální osoba podle bbc po mnoha letech řekla : „ nejsem ani muž , ani žena . “
zůstanu slátaninou vytvořenou lékaři , pohmožděná a zjizvená .
odhaduje se , že každý rok se z 2000 dětí narodí jedno , které není ani chlapec , ani dívka .
jsou intersexuální , součástí skupiny asi 60 skutečností , které spadají do diagnózy poruch pohlavního vývoje , zastřešující termín pro ty , kdo mají atypické chromozómy , pohlavní žlázy ( vaječníky nebo varlata ) nebo neobvykle vyvinuté genitálie .
intersexuální mohla být wallis simpsonová .
určování pohlaví ještě není zcela pochopeno , ale většina odborníků ve spojených státech říká , že když nelze určit pohlaví , je lepší použít nejlepší dostupné informace a určit je , místo aby se čekalo a sledoval se psychologický a fyzický vývoj dítěte do té doby , než se provede operace , pokud vůbec .
newyorský psychiatr doktor jack drescher , který se specializuje na problémy s určením pohlaví , řekl , že nový německý zákon „ vypadá jako dobrá věc “ .
intersexuální děti představují etické dilema .
„ některé osoby jsou v život ohrožujícím stavu , který vyžaduje operaci , ale u většiny dětí to tak není , “ řekl .
určení pohlaví lze provést bez operace a pak se může počkat , jak se identita vyvíjí .
znalost toho , jak se u dítěte vyvine pohlavní příslušnost , není příliš přesná .
nikdo neumí odpovědět na otázku , proč se to děje .
je to jako záhada , proč jsou někteří lidé homosexuálové .
zpráva předaná evropskému výboru v roce 2011 popsala intersexuální osoby jako odlišné od transsexuálních nebo transgenderových lidí , protože jejich status není vázán na pohlaví , ale na jejich biologickou stavbu , která není výhradně ani mužská , ani ženská , ale typicky se skládá s obou a nelze ji jasně definovat jako ani jednu z nich .
tyto rysy se mohou projevit v sekundární pohlavní charakteristice , jako je svalový objem , vlasový porost , poprsí a postava , v primární sexuální charakteristice , jako jsou rozmnožovací orgány a pohlavní ústrojí , nebo v struktuře chromozómů a hormonech .
tato zpráva také poskytuje přehled o diskriminaci , kterou zažívají intersexuální a transsexuální lidé v pracovní oblasti , a také úrovně obtěžování , násilností a předsudků .
chlapci neodpovídající žádnému pohlaví nyní mají zvláštní tábor .
austrálie a nepál již dospělým dovolují označit v oficiálních dokumentech mužské , ženské nebo „ třetí pohlaví “ .
norrie may-welby , 52letá australanka , se v červnu stala celosvětově první uznanou „ bezpohlavní “ osobou , když vyhrála soudní odvolání , aby si mohla do konce života ponechat status „ neurčitého “ pohlaví .
podle ministerstva vnitra budou mít německé pasy kromě m ( muž ) a f ( žena ) i třetí označení , x , a to pro intersexuální osoby .
v sousední francii je podle zpravodajské reportáže na france 24 problematika pohlaví stále ještě kontroverzní .
v roce 2011 desítky francouzských zákonodárců z této silně katolické země podepsaly petici za to , aby ze školních učebnic byla odstraněna „ teorie o pohlaví “ .
americké webové stránky catholic online se vůči německému zákonu také vymezily a napsaly : „ s tím , jak je svět vláčen k novému stavu , kdy pohlaví je otázkou volby , ale sexuální aktivita nikoliv , převracíme naruby dva další pilíře civilizace . “
jedna matka novorozeněte z marylandu také řekla pro baby zone , že by raději viděla , aby se dětem přidělilo pohlaví při narození .
„ rodičovství samotné je stresující i bez dalších omezení , zvláště pak pokud neznáte pohlaví svého dítěte , “ vyjádřila se pro webové stránky týkající se rodičovské péče .
děti potřebují stabilitu a jistotu .
historicky se děti s jak mužským tak ženským pohlavím nazývaly hermafrodité , a to podle pohledného řeka , který měl dvojí pohlaví .
a asi deset let nazpátek se lékařská komunita domnívala , že pohlaví je něco jako tabule , která se může smazat a zase překreslit .
ale nyní mnozí zpochybňují etický základ operace s tím , že pohlavní příslušnost je komplexní záležitostí a lékaři se někdy mohou rozhodnout nesprávně , protože nevědí , jak se vzhledem ke svému pohlaví budou děti cítit , až vyrostou .
„ v polovině 20. století se tomu říkalo psychiatrická pohotovost , “ řekl drescher .
když se tyto děti narodily , nevolali jste psychiatra , ale chirurga .
přetrvávající teorie o tom , jak zacházet s dětmi s nejednoznačným pohlavím , byla předložena doktorem johnem moneyem na univerzitě johnse hopkinse , který zastával názor , že pohlaví je poddajné .
vytvořil nový pojem „ pohlavní příslušnosti “ a argumentoval , že sociální příčiny a vlivy prostředí – jak rodiče své dítě vychovali – působily na dětské geny a hormony a utvářely dítě bez ohledu na to , zda byl identifikována jako muž , nebo žena .
ale v jednom případu z roku 1966 , známým jako „ john / joan “ , se jeho teorie stala spornou .
rodičům chlapce , jehož penis byl poškozený kvůli špatně provedené obřízce , doporučil , aby své dítě nechali zcela vykastrovat , odstranili i jeho varlata a vychovali jej jako dívku .
„ média prezentovala tento případ jako úspěšný případ přeměny , ale skutečnost byla jiná , “ řekl drescher .
když bylo chlapci 15 let , nechal se přeoperovat zpět na chlapce a oženil se se ženou .
ve 38 letech však spáchal sebevraždu .
drescher řekl , že někteří lékaři „ tento model používají “ dodnes .
ale v 90. letech , s příchodem internetu , se přeživší těchto operací objevili „ nespokojení s výsledkem “ .
byl to případ i jima bruce , 36letého spisovatele z montany , který se narodil s mužskými chromozomy , ale nejednoznačným pohlavním ústrojím .
lékaři si nebyli jistí tím , zda má velký klitoris , nebo malý penis , a byli přesvědčeni , že jako muž by nikdy nemohl žít „ uspokojivým životem “ .
a tak krátce po jeho narození v roce 1976 byly bruceovi chirurgicky odstraněny vnější orgány a varlata a byl vychován jako dívka .
ve 12 letech dostal ženské hormony .
„ věděl jsem , že nejsem dívka , “ řekl pro abcnews.com.
byl jsem nešťastný , ale bylo velmi těžké se na to ptát .
v 18 byl poslán na plastiku pochvy .
ale protože byl deprimovaný a věděl , že něco není v pořádku , požádal o lékařské záznamy .
to , co našel , bylo děsivé .
po narození jsem byl sterilizován a nikdo mi nikdy nic neřekl .
bruce se narodil s poruchou vývoje pohlaví ( dsd ) , která tělu bránila produkovat dostatečné množství testosteronu , aby se mohlo správně vyvinout jeho pohlavní ústrojí .
poté , co se dozvěděl pravdu , se změnil zpět na muže , bral dávky testosteronu a nechal si odstranit poprsí ,
operace způsobily jeho neplodnost .
dnes zastupuje jiné v organizaci nazvané interface project a snaží se normalizovat vnímání těch , kdo jsou intersexuální .
avšak anne tamar-mattisová , ředitelka právní skupiny advocates for informed choice ( zastánci informované volby ) se sídlem v kalifornii , se obává , že německý zákon „ vyzývá k cejchování a stigmatům “ .
„ mnoho aktivistů se obává toho , že německý zákon dosáhne toho , že povzbudí rodiče , aby udělali rychlé rozhodnutí a vyberou pro dítě ‚ neurčité ‘ , “ uvedla .
bojíme se , že to vybídne k intervenci .
domníváme se , že lepší je přidělit mužské nebo ženské pohlaví a pak čekat .
ale nevíme , jak zákon nakonec vyzní , takže vše , co můžeme dělat , je spekulovat .
tamar-mattisová řekla , že její organizace podporuje australský zákon , protože „ dovoluje dospělým vybrat si být zařazen do třetího pohlaví “ .
„ dospělý by měli být schopni učinit o právně platném pohlaví vlastní rozhodnutí , “ řekla .
německý zákon se chystá přidělit jej při narození .
to je bitva , kterou by v tomto okamžiku malé dítě svést nemělo .
až vyrostou , mohou o svém vlastním těle učinit vlastní rozhodnutí .
ale doktorka arlene baratzová , radioložka hrudníku z pittsburghu , která má dceru s poruchou pohlavního vývoje a pomáhá stovkám jiných v podpůrné skupině , řekla , že německý zákon „ udělí pravomoci “ jak rodičům , tak dětem .
dcera baratzové , katie , se narodila s mužskými chromozomy , ale má dsd zvanou syndrom necitlivosti na androgeny .
protože její androgenní receptory jsou vadné , vyvinuly se u katie ženské rysy .
má vagínu , ale nemá dělohu a vaječníky .
nyní je 29letá katie vdaná a v rámci studií na univerzitě v pennsylvánii pracuje jako stážistka na dětské psychiatrii .
přestože je neplodná , doufá , že se stane rodičem prostřednictvím adopce nebo náhradního mateřství .
„ zákon dá rodičům určitý prostor , aby se svým rozhodnutím nespěchali , “ řekla baratzová .
dává jim to čas provést určité testy a rozmyslet si to a dává jim to čas , než napíšou „ muž “ nebo „ žena “ .
v tomto ohledu je vše v pořádku – své dítě vychováváte a milujete jej .
máte úžasné dítě a radujete se z toho .
nemusíte spěchat s operací , která je nezvratná .
„ přináší to možnost zapojit do rozhodování i dítě a odnímá úzkost , která rodiče svazuje , protože nemají jistotu , že dělají správnou věc , “ řekla .
nakonec se dítě rozhodne , s jakým pohlavím se více ztotožňuje – a to je skvělá věc .
dává to dětem pravomoc učinit své vlastní rozhodnutí .
opilec polil celý dům benzinem : hrozil , že ho podpálí i s vlastní rodinou !
napětí se zvyšovalo , strach se stupňoval .
muž začal hrozit , že celý dům podpálí .
na místo proto vyjely všechny dostupné policejní hlídky v okolí , stejně jako jednotka hasičů z mladé boleslavi a jednotka sboru dobrovolných hasičů .
na místo dorazil i policejní vyjednavač , který se muži snažil jeho iracionální chování vymluvit .
muž nadále hrozil , že dům podpálí .
do domu tak musela vniknout zásahová jednotka , která muže zneškodnila a spoutala .
agresor pak skončil na vyšetření v mladoboleslavské nemocnici , odkud byl převezen na protialkoholní záchytnou stanici .
hasiči nakonec dům politý benzinem zasypali sorbentem , který později uklidili .
z domu byla kromě osob zachráněna navíc také všechna domácí zvířata .
na policejního vyjednavače muž nedal , vydalo se tak za ním komando .
zpráva : obamova kampaň zvažovala vyměnit bidena za hillary clintonovou
nejbližší poradce prezidenta baracka obamy podle listu new york times tajně zvažoval nahradit na kandidátce z roku 2012 viceprezidenta joe bidena za hillary clintonovou .
toto odhalení je nejvýznamnější senzací netrpělivě očekávané knihy o kampani 2012 od marka halperina a johna heilemanna „ double down : game change 2012 . “
časopis times získal kopii přicházející knihy a oznámil ve čtvrtek večer , že prezidentovi vrcholní spolupracovníci pořádali koncem roku 2011 intenzivní skupinová setkání a průzkumy , aby odhadli , zda zbavení se bidena by pomohlo oživit obamovy blednoucí naděje na znovuzvolení .
podle národně-politického dopisovatele pro časopis times , jonathana martina , kniha nabízí důkladný záznam snah vedoucích úředníků uvnitř kampaně a v bílém domě , jmenovitě bývalého vedoucího kanceláře bílého domu billa daleyho , změřit , jaký účinek na volby by měl přesun bývalé ministryně zahraničí clintonové na post viceprezidentky .
potenciální změna byla přísně střeženým tajemstvím v rámci chicagské infrastruktury kampaně a uvnitř oválné pracovny .
jen několik prezidentových nejbližších poradců – včetně daleyho , bývalého šéfa obamovy kampaně jima messiny a bývalých hlavních poradců v bílém domě davida axelroda a davida plouffeho – vědělo , že se zvažuje tato změna .
kniha „ double down “ tvrdí , že daley byl představitelem snah nahradit bidena , navzdory jejich blízkému osobnímu vztahu , a to do té doby , než se nakonec rozhodli neprovést tento tah , když data ukázala , že přidání clintonové na kandidátku by „ obamovy šance podstatně nezvýšilo “ .
v rozhovoru s martinem daley potvrdil , že administrativa opravdu zvažovala nahrazení bidena clintonovou .
„ intenzivně jsem zkoumal celou řadu věcí a tohle byla jedna z nich , “ vyjádřil se pro list daley .
nesmíte zapomenout , že v té době měl prezident příšerné vyhlídky , takže jsme si říkali : „ kristepane , co máme dělat ? “
zatímco daley charakterizoval výzkum jako „ náležitou péči “ , martin řekl andersonu cooperovi ze cnn , že kampaň za znovuzvolení vynaložila nemalé investice , aby se zjistilo , zda se tento tah ve volbách vyplatí .
„ při kampaních se nevykládají takové peníze na volby a kvalitativní výzkum , pokud se něco opravdu vážně nezvažuje , “ řekl martin na ac360 .
není však jasné , zda obama věděl o tom , že jeho tým zvažuje tuto výměnu .
martin řekl pro cnn , že se daleyho zeptal , zda jeho tehdejší šéf věděl o tomto potenciálním zamíchání karet .
zatímco daley řekl , že si nemyslí , že prezident si potenciální změny „ byl vědom “ , bývalý vedoucí kanceláře přiznal , že je „ možné “ , že o tom obama věděl .
martin dodal , že kniha „ double down “ definitivně neodpovídá na otázku , zda se politická sonda dostala až k obamovi na stůl .
cooper se zeptal martina , zda si vážně myslel , že obama nevěděl o výzkumu týkajícího se vyškrtnutí bidena z kandidátky .
„ možná , “ odpověděl martin .
fantastická zmrzlina , která svítí ve tmě ?
britský podnikatel vyrobil první zmrzlinu , která svítí ve tmě – za použití medúzy .
charlie francis využil fluorescenční vlastnosti tohoto mořského živočicha a vyvinul světélkující pamlsek .
na nápad přišel , když si přečetl odborné pojednání o medúze , a přesvědčil vědce v číně , aby chemicky vyrobili bílkovinu , která způsobuje světélkování .
tato zmrzlina reaguje s jazykem konzumenta – zvyšuje hladinu ph v bílkovině a následně způsobuje její záření .
chris říká , že zmrzlina svítí , když reaguje s teplem vašich úst , a proto čím více lížete , tím jasněji září .
charlie , zakladatel zmrzlinářské společnosti „ lick me i &apos; m delicious “ ( olízni mě , chutnám skvěle ) , říká : „ je to úžasná látka , ale pokud jde o výrobu , jsme na začátku , takže za 200 gbp dostanete asi 2 g této látky . “
bílkovina , kterou ve zmrzlině používáme , reaguje s vaším jazykem při neutrálním ph .
takže jak vaše ústa bílkovinu zahřívají , zvyšuje se hladina ph a zmrzlina začíná zářit .
testovali jsme ji během několika posledních měsíců a zdá se být skvělým nápadem pro oslavu halloweenu , protože způsobuje tento fantastický zářivý efekt .
je pravděpodobně tou nejdražší zmrzlinou , kterou jsem kdy vyrobil , protože světélkování medúzy je čtyřikrát dražší než zlato .
a tak mě každý kopeček stojí asi 140 gbp .
ale chutná výborně .
charlieho experimentální společnost se sídlem v bristolu je známá pro své netradiční příchutě piva , sýrů , hovězího a lístků zlata .
jeho další výrobek má být ale ještě ambicióznější .
říká : „ opravdu bych si přál vyrobit neviditelnou zmrzlinu . “
ve své podstatě to je nemožné kvůli lomu světla způsobeného krystalky ledu , které zmrzlinu tvoří , ale já počítám s tím , že nějakou cestu , jak to udělat , najdeme .
zmrzlina využívá fluorescenční vlastnosti medúzy , uměle vyrobené čínskými vědci .
halloween 2013 : podle čísel
když jsem byl malý , halloween byl magický .
se sestrou jsme mohli jíst sladkosti , zůstat dlouho vzhůru a předvést se sousedům v převleku .
dnes mám pocit , že jsem se stal skrblíkem .
po dva roky se v mém bytě neobjevilo cukroví a tento rok to pravděpodobně nebude jiné .
avšak statistiky ukazují , že jsem , pokud jde o halloween , černá ovce .
podle státní maloobchodní federace ( nrf ) bude tento rok slavit halloween většina američanů – ve skutečnosti 158 milionů z nich – a utratí celkem 6,9 miliard dolarů za sladkosti , kostýmy a ozdoby .
na co se ale pokaždé o halloweenu těším , jsou trendy .
podle nrf se očekává , že z 6,9 miliard utracených dolarů půjde 1,2 miliard na kostýmy .
tento rok jsou posledním výstřelkem módy sexy neživé objekty .
sexy už nemusí být jen ženy ; sexy mohou být i jídla jako pizza , hamburger a mrkev .
pokud jde o muže , očekávám , že díky průvodu mrtvých uvidíme hodně zombie , a vsadím se , že vesmírní muži z daft punk to letos dotáhnou do našich kanálů v instagramu .
podle společnosti google jsou nejhledanějšími kostýmy zombie , batman , piráti a čarodějnice .
předpokládám , že není nic špatného na tom , jít podle tradice .
minulý rok jsme do kostýmů oblékli naše psy a k mému údivu jsme nebyli jediní .
ve skutečnosti američané podle nrf utratí tento rok 330 milionů dolarů na kostýmy pro zvířecí miláčky .
takže bude vidět hodně legračních psíků .
pokud jde o sladkosti , neztrácíme čas.
podle společnosti nielsen američané utratí 1,9 miliard dolarů .
to je zhruba 300 milionů kg tabulek hershey , lízátek , sladkostí milk duds a twizzlers a tyčinek clark .
to je úžasná zpráva pro 41 milionů koledníků , kteří se podle ministerstva obchodu usa chystají přepadnout naše čtvrtě .
ve skutečnosti během halloweenu koupíme , a věřte nevěřte i zkonzumujeme , 45 milionů kg čokolády .
jediná věc , kterou nechceme , jsou kukuřičné bonbóny , a přesto se jich podle národní asociace cukráren kolem halloweenu prodá téměř 16 tisíc tun .
to je asi 9 miliard jednotlivých kukuřičných bonbónků .
to je tajemství , které jsem nikdy nerozluštil .
nic není pro halloween typičtější než strašidelné domy .
mají ty nejlepší názvy , jako „ terror behind the walls “ ( hrůza za zdmi , což je mimochodem skutečné vězení ) „ howl-o-scream “ ( jekot , řev ) a „ the house of shock “ ( dům šoku ) .
ve skutečnosti existuje ve spojených státech oficiálně zasvěcených 1200 strašidelných domů , které mají podle společnosti americké strašidelné domy zisk 500 milionů dolarů , a k tomu patří ty úžasné fotky , na kterých jste počůraní strachy a které dá váš kamarád na facebook , a vy je nemůžete odstranit a ta osoba , která se vám líbí , si fotku prohlédne a připíše komentář jako „ hezky se tváříš “ .
a nakonec něco málo o dýních .
už když jsme byli malí , charlie brown nám představil velkou dýni ( great pumpkin ) a vyřezávání dýňové lucerny je něco jako zdobení vánočního stromku – děláme to od malička .
naštěstí pro nás trend „ dítě v dýni “ začal díky aplikaci pinterest teprve loni , takže většina z nás vyrostla na tom , že tykev jsme vyřezávali , místo abychom v ní seděli .
tento rok podle úřadu pro sčítání lidu v usa američané utratí za dýně asi 106 milionů dolarů .
dýňová lucerna s mihotavým plamínkem na vaší přední verandě pravděpodobně pochází z illinois , kde tento rok vyrostlo 245 tisíc tun dýní .
pokud sháníte něco extra , zavolejte timovi a susan mathisdonovým z města napa v kalifornii a zkuste rozřezat jejich dýni vážící téměř jednu tunu .
oznámena série závodních land roverů
interiér má závodní sedadla a šestibodové bezpečnostní pásy a také interkomunikační zařízení .
na výběr jsou zdokonalené brzdy , servisní balíček zajišťující přístup k mechanikům bowler works , logistická podpora a uskladnění vozidla mezi jednotlivými závody .
drew bowler , technický ředitel bowler motorsport , řekl : „ účastníci závodů , kteří přicházejí na bowler , se změnili . “
ne všichni jsou zkušenými závodníky , ale jsou to lidé , kteří chtějí vzrušení a dobrodružství a také dosažitelnou cestu k závodům světové třídy .
jsme rádi , že jim tuto cestu ve spolupráci s land rover a msa můžeme nabídnout , a věříme , že tento formát nabízí nový způsob , jak zažít různé závodní disciplíny v británii a zámoří , a že připraví soutěžící na tvrdost a realitu závodů rally raid .
vývoj vozu defender challenge jsme si opravdu užili – bude to opravdu vzrušující soutěž .
defender challenge navíc v únoru nabídne školící a testovací den a také možnost soutěžit v pouštních závodech na severu afriky a středním východě .
schwarzenberg : do dvou let tu máme předčasné volby
předseda top 09 karel schwarzenberg očekává vbrzku další předčasné volby .
týden po těch posledních v rozhovoru pro aktuálně.cz řekl , že jiné východisko není a každá vláda vzešlá z hlasování minulý pátek a sobotu je nemožný slepenec .
&quot; to dlouho vydržet nemůže , &quot; řekl karel schwarzenberg s tím , že dobu životnosti začínajícího volebního období odhaduje do dvou let .
s námitkou , že voliči příště stěží vyberou úplně jinak , nesouhlasí : &quot; myslím si , že to bude trochu vyváženější rozhodování . &quot;
zároveň si předseda top 09 nepřipouští , že by jeho strana mohla v dalších volbách ještě ztrácet voliče jako letos ( oproti roku 2010 přišla zhruba o 300 tisíc hlasů ) .
schwarzenberg odhaduje , že pokud by bylo do dvou měsíců jasné , že předčasné volby budou , posílí to hnutí ano 2011 andreje babiše .
v opačném případě podle schwarzenberga bude babiš ztrácet .
turbulentní situaci v čssd , kde předseda bohuslav sobotka po utajované lánské schůzce části vedení strany prohlásil , že ve vedení sociální demokracie zůstane buď on , nebo michal hašek , komentuje schwarzenberg po svém :
&quot; vedoucí funkcionáři demokratické strany jak malí kluci jdou za hlavou státu , aby jim umožnila převrat ve straně . &quot;
&quot; myslel jsem , že pan hašek je šikovnější a inteligentnější . &quot;
&quot; protože něco tak nedočkavě blbě provedeného jsem v životě neviděl , &quot; dodal předseda top 09 .
a směrem k prezidentu zemanovi ( se kterým se střetl v boji o prezidentskou funkci ) utrousil : &quot; role hlavy státu je jasná : on se chce té strany zmocnit . &quot;
první zákony už top 09 předložila .
co bylo pro vás osobně největším překvapením voleb ?
top 09 už ve sněmovně formálně předložila své první návrhy zákonů , mimo jiné farského registr smluv , který před volbami probíraly sněmovní výbory , ale s předčasnými volbami spadl pod stůl .
předseda top 09 v rozhovoru pro aktuálně.cz tvrdí , že taková rychlost je dána tím , že &quot; tyto zákony jsou potřeba &quot; .
zároveň ale chce top 09 zjevně předhonit obdobné pokusy z jiných stran .
například volební lídr hnutí ano martin komárek obvinil top 09 v předvolebním boji z toho , že nápadem zavést registr smluv &quot; vykrádá &quot; program hnutí ano .
top 09 teď využila náskok - prostě jen oprášila návrh , který měl nakročeno už do druhého sněmovního čtení .
hasičské jednotky přijely zachránit ztracené štěně , které uvízlo 15 metrů nad zemí na nebezpečném výčnělku v kamenolomu
kokršpaněl ruby utekl po malé autonehodě .
o tři dny později jej uvězněného v kamenolomu zahlédl člověk , který venčil psa .
hasiči se slanili po skalní stěně , aby psa zachránili od jisté smrti .
štěně bylo vysvobozeno požárními jednotkami , které jej přijely vysvobodit poté , co se nějakým způsobem samo uvěznilo na nebezpečném výčnělku v kamenolomu 15 metrů nad zemí .
devítiměsíční kokršpaněl ruby utekl po malé autonehodě v neděli odpoledne , a tři dny sám přežíval , dokud nebyl ve středu vyproštěn z kamenolomu .
jeho majitelé scott alderson ( 25 ) s svou přítelkyní becky hall ( 20 ) byli v kamenolomu flappit v denholme , west yorkshire , aby se znovu setkali s rubym a aby poděkovali požární a záchranné službě z west yorkshire .
poté , co utekl , když se dostal do malé nehody , horečnatě po svém ztraceném psovi pátrali a umístili výzvy na sociálních sítích .
ve středu asi ve 14.15 spatřil bystrozraký pejskař uvízlého rubyho na výčnělku v kamenolomu 15 metrů nad zemí .
na místo pospíchal technický záchranný tým z požární stanice cleckheaton a slanil se dolů , aby rubyho osvobodil , přičemž použil k jeho vyzvednutí po skále přepravní tašku pro zvířata .
odborný velitel technického záchranného týmu andy clayton řekl : pes byl v nebezpečné situaci .
byl přímo uprostřed skalní stěny – 15 metrů od vrcholu i odspodu .
při záchranně nehnul brvou – byl totálně zmrzlý .
teď je ale v pořádku .
dostal pak sušenky .
byl to velmi neobvyklý výjezd .
to , že psa někdo zahlédl , je neuvěřitelné .
odborný velitel technického záchranného týmu peter lau řekl : „ ruby měl během svého útěku velké štěstí . “
byla zde možnost , že bude velmi vážně zraněn nebo ještě hůře .
ruby byl odvezen k veterináři na prohlídku , a kromě vyčerpání a dehydratace byl v pořádku .
slečna hallová z halifaxu ve west yorkshire řekla : „ při pohledu na záchrannou akci jsem měla strach . “
především jsem vůbec nemohla uvěřit tomu , jak se tam dostal .
bylo úžasné ho zase držet v náručí .
veterinář řekl , že kdyby se příliš vyčerpal a zkolaboval , pravděpodobně by spadl .
hasiči odvedli skvělou práci .
to , co udělali , bylo velmi odvážné .
jsme jim moc vděční , všichni byli prostě ohromní .
pan alderson z keighley dodal : „ báli jsme se , že může spadnout , ale zůstal tam . “
hasiči byli skvělí .
jenom pořád nechápeme , jak se tam dostal .
mick jagger tvrdí , že po tehdy 18leté katy perry rozhodně nevyjel .
během interview pro australský rozhlasový pořad tato popová hvězda tento týden řekla , že pro jaggerovu píseň „ old habits die hard “ z roku 2004 zpívala doprovodné vokály .
perry řekla , že když jí bylo 18 , měla s tímto rockovým veteránem večeři a on po ní vyjel .
a dodala : „ to už bylo dávno a teď je ke mně velmi milý . “
v prohlášení ze čtvrtka jaggerův ( 70 ) zástupce řekl , že kategoricky odmítá , že by kdy dělal katy perry návrhy .
zástupce řekl : „ možná si ho plete s někým jiným . “
perry byla jedním z hostujících zpěváků ( zpěvaček ) , kteří se letos objevili na koncertní šňůře rolling stones .
její nové album „ prism “ debutovalo tento týden na prvním místě .
george kerevan : rozdělená evropa dává skotům na výběr
další den , další strašidelný příběh o nezávislosti .
tentokrát se objevuje varování , že podmínkou pro členství nezávislého skotska v eu by byl jeho vstup do schengenu .
to zavdalo příčinu k příběhům o pasových kontrolách v berwicku a ostnatém drátu podél hadriánova valu .
pravda je , že noviny strathclyde zmínily možné ekonomické výhody volného pohybu se zbytkem evropy , ale – jak se dalo očekávat – to se do titulků novin nepromítlo .
nikdo také nezmínil , že členské státy eu tráví množství času tím , že přizpůsobují své úřední zákony , pokud jim to vyhovuje .
vzhledem k tomu , že skotsko nyní v schengenu není , nabídka pokračujícího nesouladu by byla pro brusel levným ústupkem oplátkou za cokoliv , co od skotů opravdu chtějí .
takže je to dost slabý příběh .
a navíc tak starý , že se z něj stala vykopávka . novinářskou kachnu , že „ nezávislost znamená pasové kontroly “ , jsem slyšel před alespoň 40 lety .
přesto se v této vousaté povídačce skrývá jedna zajímavá myšlenka .
proč by se vůbec mělo očekávat , že nezávislé skotsko bude evropu poslouchat ?
proč vyměnit londýnský chomout za ten bruselský , obzvláště nyní ?
tohle je skutečný evropský příběh : velký poválečný plán sjednotit evropu konečně ztroskotal .
vlivem krize eura je takzvaný projekt evropa oficiálně mrtev .
napříč evropou získávají vliv strany zasvěcené odporu vůči eu či zrušení eura jako společné měny .
dokonce i v německu euroskeptická strana alternativa pro německo – založená v tomto roce – přišla jakoby odnikud a už v zářijových federálních volbách ukořistila téměř pět milionů hlasů , čímž z bundestagu v podstatě „ vymetla “ svobodné demokraty ( ekvivalent britských liberálních demokratů ) .
na domácí půdě byl vždy odpor k plánu vytvořit federální evropu .
současná ekonomická krize se však stala rozhodujícím momentem .
úspornost diktovaná německem a evropskou centrální bankou spolu se svěrací kazajkou navléknutou na národní ekonomiky prostřednictvím lpění na společné měně přivedly mnoho lidí k názoru , že projekt evropa zašel příliš daleko .
krize eura má jen málo společného s tím , že národní vlády hospodaří s vysokým rozpočtovým schodkem – to byla pravda jen v případě řecka .
spíše jde o systém eura , který blokuje své členy na směnných kurzech výhodných pro německé vývozce – a to si němečtí politici chtějí ponechat .
bez možnosti devalvace domácí měny má jižní evropa v oblasti domácí výroby oproti německu nevýhodu .
jedinou pomocí je seškrtat příjmy a veřejné výdaje – k čemuž vybízí německo .
za současnými problémy s rozpočtem a měnou je hlubší příčina evropské malátné výkonnosti .
v důsledku „ zelené “ energetické politiky podporované bruselem – kód pro podporu francouzských a německých firem na náklady spotřebitele – platí evropský průmysl dvakrát více za elektřinu a čtyřikrát více za benzín , než tomu je ve spojených státech .
toto je paralyzující nevýhoda v oblasti nákladů , jak jsme již viděli v případě grangemouth .
ani veškerá zmrazení platů na světě by neodvrátila zadupání evropského petrochemického průmyslu levnou břidlicovou ropou z usa .
výsledkem je doutnající vzpoura , obzvláště ve francii , kdysi nadšeném stoupenci eu .
po válce politická elita ve francii viděla eu jako nástroj , který bude německo držet na uzdě a umožní paříži postavit se ve světě na úroveň washingtonu .
berlín ale už paříž jako průkazku politické legitimity nepotřebuje a prosadil v evropě svou vlastní ekonomickou politiku a opotřebovanou francouzskou ekonomiku ponechal svému osudu .
výsledek : pravé křídlo marine le penové , protievropská národní fronta , právě vyhrálo zásadní dodatečné volby a odsunulo vládnoucí socialisty na třetí místo .
fronta je nyní s 24 % hlasů nejpopulárnější stranou ve francii – včasné varování pro britské labouristy , že nemohou usuzovat , že štěpení pravice se automaticky kladně projeví na levici .
jak le penová nakládá se svou nově nabytou popularitou mezi bělošskou pracující třídou ?
evropské volby v příštím roce by ráda využila k tomu , aby napříč evropským parlamentem vytvořila antievropský blok působící proti společné měně .
pokud si antievropské strany povedou v těchto volbách dobře , což je pravděpodobné , může takový blok poprvé v historii evropskému parlamentu dominovat .
mě při tom napadá , že v dohledné době se rostoucí protievropský pocit a postoj proti společné měně spojí a euro zahubí .
eu nezmizí , ale přemění se spíše na něco volnějšího ve smyslu „ evropy ( suverénních ) národů “ , již upřednostňoval generál de gaulle .
německo a několik jeho satelitních ekonomik si možná euro ponechá , ale francie a jižní evropa obnoví své vlastní měny .
očekávám , že velká británie se od tohoto projektu bude distancovat a přimkne se ke spojeným státům .
avšak zvýšený zájem washingtonu o tichomoří naznačuje , že británie bude ponechána atlantickému chladu .
a kde bude skotsko ?
můžeme si vybrat být oblastí ( v zásadě ) malé anglie .
nebo můžeme bránit své vlastní ekonomické zájmy – do toho spadá i možnost oznámit berlínu a bruselu , kdy nás mají nechat být .
předpokládám , že skotsko by si v uvolněném uspořádaní evropy vedlo dobře za předpokladu , že by si uchovalo svou vlastní měnu .
spolupráce s dalšími podobně smýšlejícími zeměmi by byla jednodušší v nefederální evropě národů .
v opačném případě bychom si měli vzít příklad z norska a ponechat si svou ekonomickou nezávislost .
vláda snp ve skotsku je – kupodivu – nejúspěšnější politické hnutí neprosazující úsporná opatření v evropě , které vyhrálo velkou většinou v roce 2011 díky opozičnímu postoji vůči škrtům , které plánoval ( a implementoval ) labouristický kancléř alistair darling a následující koalice konzervativců a liberálních demokratů .
bylo by směšné , kdyby nyní skotsko volilo nezávislost jen proto , aby přijalo úsporná opatření diktovaná berlínem a bruselem .
časná puberta : vyspělé dříve
výzkum ukázal , že afroameričanky a hispánky dosahují puberty dříve než jejich bělošské vrstevnice .
fyzické změny neznamenají , že se blíží puberta
není prokázáno , že za tím jsou hormony nebo jiné chemické látky
odborníci tvrdí , že jedním ze spouštěčů dřívější puberty může být epidemie obezity .
trend dřívější puberty není tak patrný u chlapců .
bývalý zpravodaj cnn pat etheridge je novinářem , který se specializuje na zdraví dětí a rodinné problémy .
měla by se matka zděsit , když její dceři začnou růst prsa a ochlupení na ohanbí v 7 nebo 8 letech ?
na výroční konferenci americké akademie dětských lékařů tento týden v orlandu na floridě vysvětlil pediatrický endokrinolog doktor paul kaplowitz , že tyto fyzické změny jsou mezi americkými dívkami poměrně časté a představují nový standard .
„ mnoho času jsem strávil tím , že jsem rodiče ujišťoval , že to obvykle není znamení rychlého vývoje směrem k plné pubertě , “ řekl kaplowitz
viditelné znaky vývoje , jako je růst prsou , ochlupení na ohanbí a v podpaží a tělesný pach , se u dívek objevují dříve .
za posledních čtyřicet let byl však jen malý posun ve věku , kdy dochází k první menstruaci .
ve spojených státech je nyní průměrným věkem 12,5 let oproti věku 12,75 let v roce 1970 .
„ když se začnou vyvíjet prsa , uplynou minimálně dva až tři roky , než dojde k první menstruaci , “ řekl kaplowitz , který je také autorem knihy „ early puberty in girls : the essential guide to coping with this common problem “ ( časná puberta u dívek : nezbytná příručka pro zvládnutí tohoto častého problému )
nejspolehlivějším testem toho , jak bude puberta pokračovat , je čas.
diskutuje se o tom , co aktivuje skutečný začátek puberty , ale pokud je růst prsou doprovázen růstovým spurtem před 8. rokem věku , je dívka považována za „ předčasně vyspělou “ .
ve většině případů se proces zpomalí nebo zastaví – což mohou dětští lékaři pečlivě monitorovat .
rychlejší růst může být důvodem pro to , aby endokrinolog provedl testy za účelem vyloučení vážných problémů , jako je nádor nebo cysta .
existují léčebné postupy , které zpožďují časnou menstruaci a zabraňují dalším následkům : předčasnému stárnutí kostí , které nakonec může vést k zastavení růstu a zakrslosti v dospělosti .
doporučení ohledně léků a hormonální léčbě jsou závislá na věku dítěte , rychlosti vývoje , rychlosti růstu a emocionální zralosti .
důležité jsou také psychosociologické aspekty .
pokud jde o nasazení léků , je kaplowitz opatrný , ale uznává , že „ potlačení puberty může zmírnit problémy s chováním dívky a jejími pocity , že se liší od svých vrstevníků “ .
pochopitelný je další velký problém : rodiče jednoduše nechtějí , aby jejich velmi mladé dcery měly menstruaci .
„ dělají si obavy , že může otěhotnět , nebo jak bude zvládat hygienu , “ řekl kaplowitz .
„ byl to šok , “ vzpomíná jedna žena , jejíchž dcera začala mít menstruaci v 10 letech .
přestože existovaly náznaky a o menstruaci jsme spolu mluvily , nebyla připravena emocionálně .
přišla ze školy domů vystrašená a naštvaná , že je ze svých kamarádek první .
existuje mnoho dobře známých teorií o příčinách předčasné puberty .
ještě však neexistuje souvislý soubor důkazů , že jsou na vině hormony v mléce nebo jiných potravinách , chemické látky v prostředí nebo sexuální poselství v médiích .
chlapci – podobně jako dívky – dosahují puberty dříve .
kaplowitz prosazuje předpoklad , že nejvážnějším důvodem je epidemie obezity .
v roce 2001 pomáhal s provedením studie na dívkách ve věku od 6 do 9 let , která spojuje tělesný tuk s načasováním puberty .
další zjištění tento závěr podporují , ale existuje mnoho jiných přispívajících faktorů .
v této zemi mají afroameričanky a hispánky sklon dosáhnout puberty dříve než jejich bělošské protějšky .
vysvětlení jsou různá .
z globálního hlediska se zdá , že vzory časné puberty jsou ovlivněny vším možným od ekonomických podmínek přes podnebí až po geny .
další hádanka : ačkoli u chlapců se už v nízkém věku objevuje ochlupení v obličeji a na ohanbí , trend směrem k plnému rozkvětu časné puberty není tak zřetelný , jako je tomu u dívek .
další lékaři účastnící se konference americké asociace dětských lékařů ( aap ) přidali k tomuto tématu další složitosti .
akné a ochlupení ohanbí je běžné dokonce i u kojenců a batolat .
„ musíme být opatrní , pokud jde o to , jak identifikujeme skutečný nástup puberty , “ řekl lawrence silverman , pediatrický endokrinolog z goryebské dětské nemocnice v morristownu v new jersey .
rodiče by neměli váhat získat od svého dětského lékaře pokyny , jak se svým dítětem mluvit .
„ může to znamenat nutnost popovídat si s dítětem dříve , než byste předpokládali , “ poradil kaplowitz .
pokud zůstanete klidní , vaše dítě pravděpodobně bude reagovat dobře .
dívky , které se vyvíjejí dříve , potřebují ujištění , že i když se tak děje předčasně , je tento proces běžnou součástí života .
naďa konvalinková v roli hospodské .
má novou práci ?
herečka naďa konvalinková ( 62 ) se objevila za výčepem v roli hospodské a moc jí to šlo .
že by snad oblíbená česká herečka plánovala změnu profese a dala se na podnikání v hospodě ?
naďa konvalinková se objevila v james joyce irish pubu a točila tam pivo .
dělala jsem to poprvé v životě a hned mi to šlo .
dokonce mi šéf nabídl , že by mne zaměstnal a mohla bych se točením piva živit .
ale odmítla jsem , raději zůstanu u toho , co dělám dodnes , u herectví , &quot; prozradila s úsměvem konvalinková , která byla hostem na dvacátém výročí fungování irské hospody .
&quot; mám ráda irské pivo a sem tam si dám i irskou whiskey , &quot; prozradila své chutě herečka .
na akci se objevil i nadi dloholetý kamarád a kolega pavel nový .
já jsem po smrti a v současném novém životě nesmím chlastat .
mám povoleno jedno pivo nebo jednoho panáka denně , a to se snažím dodržovat , &quot; dodal herec .
výrobci letadel se přou o šířku sedadel , v sázce jsou velké zakázky
mezi vedoucími výrobci letadel se rozhořel spor o šířku sedadel v druhé třídě u letů na dlouhé vzdálenosti , což tento měsíc zavdalo příčinu hořké výměně názorů na letecké show v dubaji .
předmětem sporu je šířka sedadel poskytovaných u dálkových letů pro ekonomickou třídu – ne zrovna ta , kterou by si obvykle letecké společnosti předcházely , ale jejíž přidělený prostor je klíčem k nárokům na efektivitu u posledních letadel nabídnutých společnostmi airbus sas a boeing .
společnost airbus tento týden vyzvala k průmyslovým normám , které by nabídly alespoň 46 cm široká sedadla v ekonomické třídě , ale hlavní americký rival boeing říká , že o tom mají rozhodnout letecké společnosti .
spor vyvstal v době , kdy výrobci letadel soutěží v prodeji největší verze svého dvoumotorového dálkového letadla s potenciálním rekordním počtem objednávek očekávaným během akce od 17. do 21. listopadu .
to , jakým způsobem je zadní část letadla rozložena – obzvláště zda je vedle sebe 9 nebo 10 sedadel – , je základem ekonomických výkonnostních nároků na návrhy nových letadel „ mini-jumbo “ .
společnost boeing říká , že vylepšený model „ 777x “ dopraví 406 lidí v ekonomických sedadlech se šířkou více než 43 cm rozložených po 10 v každé řadě .
společnost airbus říká , že konkurenční verze jejího modelu a350 dopraví 350 lidí ve 46 cm širokých ekonomických sedadlech rozložených po 9 .
obří letouny se často navzájem napadají v technických otázkách prostřednictvím reklam v odborných médiích .
airbus nyní před leteckou show v dubaji , kde se očekává , že 777x získá převahu s více než 100 objednávek , apeluje přímo na veřejnost .
nedávno předběžně ukázal , co může být zahájením nové reklamní války , když finančníkům ukázal snímek zobrazující tři osoby natěsnané v restauraci s titulkem „ nechali byste si to líbit ? “
„ boeing propaguje dálkové lety v sedadlech užších , než jsou v regionálních turbovrtulových letadlech , “ řekl vedoucí prodeje společnosti airbus john leahy .
jak se mění stravovací návky , lidé jsou větší , ale sedadla v letadlech se radikálně nezměnila .
od počátku 70. let , kdy boeing 747 jumbo definoval moderní dálkovou leteckou dopravu , do přelomu století se podle údajů ministerstva zdravotnictví usa hmotnost průměrného američana ve věku 40 až 49 let zvýšila o 10 procent .
podle amerických zdravotnických statistik má průměrný američan ve 21. století v pase 100 cm .
airbus tvrdí , že jeho rival se drží konceptu sedadel z 50. let , kdy průměrná šířka sedadel nově pokřtěného letadla byla nižší .
společnost airbus tvrdí , že provedla výzkum , který naznačuje , že rozšíření sedadla o 2,5 cm zlepší kvalitu spánku o 53 procent .
boeing rozměry sedadel společnosti airbus odmítá a říká , že není v pravomoci výrobců letadel rozhodovat o tom , jak letecké společnosti vyváží poplatky a vybavení .
společnost také říká , že výzkum ukazuje , že zážitek v kabině závisí na více záležitostech než jen na šířce sedadla .
„ opravdu jde o to , poskytnout leteckým společnostem flexibilitu a umožnit jim provádět věci , o kterých jsou přesvědčeni , že je musí udělat , aby byly úspěšné , “ řekl odborník na kabinový prostor kent craver .
nechtějí , abychom jim diktovali , co jim přináší zisk .
znají své podnikání lépe než kdokoliv jiný .
pro cestující je zásadní větší prostor pro lokty , ale pro dodavatele je to rostoucí problém , který může ovlivnit výnosy .
za tímto sporem je závod v objednávkách letadel s odhadovaným obchodem v příštích desetiletích v hodnotě minimálně 700 miliard dolarů v katalogových cenách , dost na to , aby se vychýlil jazýček vah amerického a evropského exportu .
jak uvedla v červenci agentura reuters , rozložení sedadel je přesně to , co pohání bitvu mezi posledními letadly .
jak airbus , tak boeing tvrdí , že dosahují u svých posledních návrhů dvoumotorových dálkových letadel o 20 procent lepší účinnosti než vedoucí představitel trhu v tomto segmentu , model boeing 777-300er s 365 sedadly .
výkonnostní nároky boeingu závisí zčásti na srovnání designu modelu 777x s 10 sedadly v řadě a konceptu 777 s 9 sedadly v řadě .
zisk v jednotkových nákladech je oproti 10sedadlovému konceptu oslabený .
„ důvod , proč to boeing dělá , je , aby napěchoval více sedadel , a učinil svá letadla konkurenceschopnější oproti našim produktům , “ řekl kevin keniston , vedoucí pro pohodlí cestujících ve společnosti airbus pro evropu .
na druhé straně analytici říkají , že kabiny s 10 sedadly v řadě pro existující modely 777 jsou v souladu s tím , že mnoho cestujících je pro hustší rozložení , které může jít ruku v ruce s nižšími poplatky .
„ čtyřicet pět centimetrů široké sedadlo by pro cestující bylo skvělé , ale realitou je , že z podnikatelského hlediska společnosti airbus je návrh motivován hrozbou modelu 777 , “ řekl odborník na interiér kabiny mary kirby , zakladatel a editor portálu runway girl network .
airbus a boeing nedodávají sedadla , ale nabízejí leteckým společnostem katalog dodavatelů , aby si mohly vybrat .
scestovalí prodejci letadel dokonce s sebou nosí měřící pásmo , aby zkontrolovali konkurenční uspořádání .
zatímco se honosí pohodlím , všichni výrobci také nabízí letadla s vysoce hustým uspořádáním pro nízkonákladové společnosti a regionální cestovatele .
airbus nabízí model a350 s 10 sedadly v řadě , ale říká , že jej ještě neprodal .
donedávna airbus zdůrazňoval potřebu větší úpravy kabiny tak , že nabízel u některých ze svých letadel širší sedadla v uličkách .
odborníci říkají , že bez podpory jediného dalšího výrobce velkých moderních letadel výzva k novým průmyslovým normám zůstane nevyslyšena , ale může odradit od vlny prodeje 777x .
počet nakažených virem hiv překročil v praze tisícovku
v české republice počet nakažených každoročně roste .
například v roce 2002 testy potvrdily infekci u 50 lidí , o pět let později už jich bylo 121 a v roce 2010 už jich bylo 180 .
loni bylo nakažených 212 a jednalo se o rekordní číslo .
&quot; o tom , že celkový počet nově diagnostikovaných případů letos přesáhne 200 , již podle mne není pochyb , &quot; konstatoval expert na problematiku aids miroslav hlavatý , který léta vedl pražský dům světla pro pacienty .
podle něj loni od ledna do září přibylo v zemi 165 pacientů s hiv , letos za stejné období jich bylo 176 .
od počátku sledování do konce letošního září testy potvrdily hiv u 1710 mužů a 353 žen , přičemž nejvíce infikovaných bylo v praze .
jejich počet v září dosáhl 1005 .
ve středočeském kraji mělo bydliště 206 infikovaných .
diagnózu si vyslechlo i 156 lidí z jihomoravského kraje , 130 z moravskoslezského či 116 z ústeckého .
nejméně nakažených pochází z vysočiny , bylo jich 19 .
celkem 88 procent pacientů se infikovalo při sexu .
čtrnáct osob se v minulosti nakazilo při transfuzi krve .
takový případ se ale od počátku testování , tedy za více než čtvrt století , v čr neobjevil .
s virem hiv se narodilo také šest dětí , přenesl se na ně z matky .
nesmysly ve filmu gravitace jsou , ale podívaná je to krásná , tvrdí experti
fantastický film z vesmíru gravitace nějaký čas po premiéře vyprodával v česku kina .
za říjen ho vidělo podle unie filmových distributorů téměř 150 tisíc diváků a vydělal přes 26 milionů korun .
většina recenzí hodnotí snímek pozitivně .
jiné v něm však nachází určité nesrovnalosti .
server lidovky.cz se zeptal odborníků z řad astronomů a astrofyziků na to , jak se jim film líbil a zda si všimli nějakých nesmyslů , které se ve filmu objevily .
jiří dušek ( ředitel hvězdárny a planetária brno ) : mám rád vědecko-fantastické filmy , které považuji za moderní , snové pohádky .
film gravitace nevyjímaje , i když se tváří jako &quot; fyzikálně reálné &quot; představení .
není , ale to neznamená , že by byl špatný .
užil jsem si ho moc .
všimnout si můžete třeba vlasů sandry bullock , které se jaksi nevznáší ve stavu beztíže .
hubbův kosmický dalekohled a mezinárodní kosmická stanice se pohybují po výrazně rozdílných oběžných dráhách , tudíž nemohou být vidět v jednom záběru .
někteří diváci filmu vyčítají nereálně působící efekt a vůbec celé chování ohně ve stavu beztíže .
skafandry by podle nich také nevydržely takové rány .
hrdinové ve filmu gravitace se často dostávají do kolize s různými předměty a obleky bez větších potíží vše vydrží .
kritice nebyla ušetřena ani dějová zápletka .
tak rozsáhlá tragédie na oběžné dráze země je podle některých diskutujících nereálná .
navíc se diví , proč doktorka byla poslána do vesmíru , aby opravovala techniku .
lidé se na fórech hádají i o &quot; nereálném &quot; chování lan .
ta prý působí , jako by byla určena pro bungee jumping .
marcel grün ( ředitel hvězdárny a planetária hl. m. prahy ) : viděl jsem ho zatím jen na širokém plátně , ale jednoznačně mohu říci , byl jsem okouzlen .
jsem rád , že to nebyl film dokumentární , ale science- fiction .
a u takového příběhu má autor právo ( téměř povinnost ) nedržet se důsledně reality .
&quot; víc než vámi zmiňované nesrovnalosti se mne dotýkalo to , jak je třikrát ukazována kosmická stanice s degradující úrovní techniky ( naposledy čínská ) . &quot;
&quot; čínská ostatně bude až koncem desetiletí a asi bude vypadat lépe než je ve filmu . &quot;
vladimír karas ( ředitel astronomického ústavu akademie věd čr ) : v počítačově generovaných scénách se autoři velmi úspěšně snaží neporušovat fyzikální zákony , a tak přírodovědně orientovaný divák ocení , že se při různých kosmických kolizích a srážkách docela správně zachovává moment hybnosti , řečeno slovníkem fyzika , rovněž pohled na zemi z vesmíru je velmi realistický včetně tenké slupky atmosféry a polární záře poblikávající na polárními oblastmi .
nesrovnalosti se při podrobnějším zkoumání určitě najdou .
dodatečně jsem například při čtení komentářů zjistil , že preferovaný směr oběhu různého kosmického smetí na oběžné dráze se v některých scénách jeví obrácený , než by tomu mělo ve skutečnosti být ( od západu k východu ) .
jiří štěpán ( zaměstnanec astronomického ústavu akademie věd čr ) : některé věci si tvůrci přizpůsobili svým potřebám , ale žádný zásadní a do nebe volající prohřešek proti logice nebo přírodním zákonům jsem ve filmu nezaznamenal a ve srovnání s jinými filmy podobného zaměření je vidět , že si tvůrci dali záležet na věrohodnosti zobrazených událostí .
z momentů , které nedávají smysl stojí za to jmenovat fakt , že hubblův vesmírný dalekohled obíhá po jinak skloněné orbitě než iss .
důsledkem je značně rozdílná vzájemná rychlost a záchranná operace by tudíž ve skutečnosti nemohla proběhnout tak , jak byla zobrazena ve filmu .
dále pak v momentě oddělení kowalského ( clooney ) a stoneové ( bullock ) jsem si nevšiml , že by celá iss rotovala , tudíž není ani jasný původ síly působící na kowalskiho , který nutí oba aktéry se pustit v momentě , kdy se již vůči sobě nepohybují .
nová vakcína proti nikotinu může odejmout potěšení z kouření
vědci vyvinuli vakcínu proti nikotinu , která může odejmout potěšení z kouření cigarety .
jediná dávka vakcíny dokázala na celý život ochránit myš před závislostí na nikotinu .
před zkouškami na lidech je potřeba provést další testy , které zaberou několik let , ale profesor ronald crystal ze zdravotnické fakulty weill cornell v new yorku říká , že první náznaky jsou dobré .
„ pevně doufáme , že tento druh vakcinační strategie může konečně pomoct milionům kuřáků , kteří se pokusili přestat a vyčerpali všechny metody dnes dostupné na trhu , ale zjistili , že jejich závislost na nikotinu je tak silná na to , aby všechny současné přístupy překonala , “ řekl profesor cornell .
nová vakcína obsahuje neškodný virus , který byl sestaven tak , aby nesl genetickou informaci pro vytvoření antinikotinových protilátek .
virus selektivně infikuje buňky jater , které poté začnou vytvářet plynulý proud těchto protilátek .
protilátky pronásledují veškeré molekuly nikotinu v krevním řečišti a neutralizují je předtím , než se dostanou do mozku , čímž zabrání tomu , aby kuřák dostal nikotinový zásah .
při testech vakcinované myši , kterým byl dodatečně dodán nikotin , pokračovaly ve své běžné činnosti .
ale myši , které nebyly vakcinovány , „ se uklidnily “ , řekli výzkumníci , což je znamení toho , že nikotin se jim dostal do mozku .
experimenty jsou popsány v časopise science translational medicine .
předešlé tabákové vakcíny selhaly , protože obsahovaly protilátky .
injekce musely být podávány tak často , aby se udržela dostatečná hladina protilátek , takže se ukázaly jako drahé a nepraktické .
náklady na novou vakcíny by měly být mnohem nižší , protože přeměňují buňky jater na továrny na výrobu protilátek .
profesor crystal řekl , že pokud budoucí vakcíny pro lidi budou zcela bezpečné , mohly by se podat dětem předtím , než budou mít chuť cigaretu zkusit , a předešlo by se tak závislosti na nikotinu .
mnohem pravděpodobněji by ji však používali kuřáci k tomu , aby přestali .
„ budou vědět , že když začnou znovu kouřit , kvůli nikotinové vakcíně z toho žádný požitek mít nebudou , a to jim pomůže se tohoto zlozvyku zbavit , “ řekl .
britští vědci řekli , že výsledky byly zajímavé , ale upozorňují , že je zapotřebí dalšího výzkumu .
tripodi popírá , že by jej ovlivňoval obeid
bývalý labouristický ministr nového jižního walesu ( austrálie ) bude vyšetřován státním výborem pro dohled na korupci .
bývalý ministr nového jižního walesu joe tripodi popřel , že by měnil politiku pobřežního pronájmu na žádost svého politického rádce eddieho obeida , který měl skryté zájmy ve třech nemovitostech na vládou kontrolovaném pozemku .
nezávislý výbor proti korupci ( icac ) v pátek rozšířil své pátrání na to , zda pan obeid loboval u několika státních ministrů , aby mu byl pronájem na circular quay , kde obeidovi vlastnili dvě restaurace a kavárnu , obnoven bez toho , že by se musel po jeho vypršení v srpnu 2005 zúčastnit výběrového řízení .
výbor nyní prošetřuje tvrzení , že pan tripodi věděl o utajených zájmech pana obeida na těchto nemovitostech , a to na základě důkazu předloženého ve čtvrtek bývalou zástupkyní vedoucího kanceláře pana tripodiho , lynne ashpoleovou .
během let rozhovorů zahájených v roce 2005 vláda tlačila na to , aby šly pronájmy do veřejných soutěží .
nájemci byli proti tomu a také chtěli dlouhodobější smluvní podmínky .
v roce 2009 byly pronájmy pro podniky v circular quay , které obeidovým přinášely 2,5 milionů dolarů ročně , obnoveny bez nutnosti účastnit se veřejné soutěže .
pan tripodi , který byl ministrem přístavů od února 2006 do listopadu 2009 , byl původně příznivcem veřejných soutěží .
popřel ale , že změny byly provedeny na žádost pana obeida , který , jak pan tripodi přiznal , naléhal na posun ve vládní nájemní politice .
přepis hovorů předložený v icac ukázal hovory ze srpna až září 2007 mezi pány obeidem a tripodim a stevem dunnem , vedoucím úředníkem , který na rezort přístavů přišel poté , co pracoval pod panem obeidem v oddělení pro rybolov .
„ byl námětem rozhovorů v průběhu těchto telefonických hovorů vývoj politiky komerčních pronájmů ? “ zeptal se pomocný komisař anthony whealy pana tripodiho .
„ ne , “ odpověděl pan tripodi .
nemůžu si vzpomenout , o čem jsme mluvili , ale rozhodně ne o tomhle .
rozhodně ne mezi mnou a panem obeidem .
izraelské vojenské letouny zaútočily na cíl v sýrii , řekl odpovědný činitel
izraelské vojenské letouny zasáhly ve čtvrtek v noci cíl v syrském přístavu lázikíja , potvrdil odpovědný činitel administrativy stanici fox news .
tento odpovědný činitel konkrétně neřekl , o jaký cíl se jednalo , ale řekl , že byl minimálně jeden .
tisková agentura associated press uvádí , že cílem byly rakety sa-125 ruské výroby .
minimálně dvakrát předtím letos izrael provedl letecký útok na dodávky raket v sýrii .
mnoho věcí se pohnulo , a je jinak .
třeba komentátor pečinka mluvil tak , že se s tím dalo souhlasit , kdežto předseda štěch rozdmýchával nesvár .
hejtman chovanec mi byl podezřelý hned , jak ho zvolili do předsednictva , a potvrdil to .
předseda sobotka vždy byl , a je symbolem té bídy čssd i nadále .
ostatní pánové předvedli hlavně své slabiny .
senátor dienstbier je zásadový a čitelný a nepoužitelný , místopředseda zaorálek se znemožnil nejvíce rozhovorem v televizi .
na základě toho nevidím lepší možnost , než aby čssd navrhla za premiérku místopředsedkyni senátu gajdůškovou , ta jediná by neměla počáteční hendikep a myslím , že by odvedla standardní výkon .
to je tak dobré řešení , že ho sotva někdo z vedení podpoří .
dodávám , že toto řešení je jediná možnost , jak zapomenout , co se dělalo , a pokračovat bez roztržení strany .
alena gajdůšková by mohla bez obav sestavit menšinovou vládu s pouhým požehnáním od předsedy babiše a bez lidovců , ale s lidoveckým ministrem zdravotnictví hovorkou , který je vlastně věřícím sociálním demokratem .
tato minimenšinová vláda by měla velkou stabilitu , protože by prosazovala řádný zákon o referendu a takovou se zavázal podporovat i předseda úsvitu okamura .
předseda babiš by se nakonec s progresí daní smířil , neboť je bystrý a uvidí , že to bez ní nejde .
lidovci by nepřinášeli problémy , protože hovorka je nositelem toho nejlepšího , co mají , a ve vládě by jinak nebyli .
totéž platí o ano , i zde by se našel cenný ministr , ale když rozumně nechtějí vstoupit do riskantní vládní účasti , ale poskytnou podporu , také dobře .
dodejme odvahu aleně gajdůškové !
zahraniční pracovníci s vízovým oprávněním možná podstoupí test „ oprávněnosti “
s tím , jak vláda zamýšlí rozšíření policejních zákroků , zvažuje test „ oprávněnosti “ pro zahraniční pracovníky s vízovým oprávněním 457 .
test , pokud bude přijat , bude uplatněn prostřednictví kritérií s cílem zabránit tomu , aby byl program 457 použit k naplnění nekvalifikovaných pracovních pozic , nebo jako zadní vrátka pro přestěhování rodiny a přátel do austrálie .
když byl dnes vydán vládní diskusní článek , bývalá labouristická poslankyně maxine mckewová odsoudila vládní rétoriku o zahraničních pracovnících se slovy , že to může urazit australské sousedy .
„ hlasitá prohlášení ‚ cizinci na konec fronty ‘ a ‚ práce nejdříve pro australany ‘ jsou velmi nepříjemným pozůstatkem z doby , kdy svazy požadovaly chráněný pracovní trh , “ řekla dnes pro australsko-indický institut .
historicky to znamenalo , že měla být chráněna bělošská pracovní síla – a já bych se nedivila , jestli někdo v tomto regionu zaznamenal ozvěnu tohoto historického artefaktu .
diskusní článek rozebírá 12 opatření , které předtím zvažoval bývalý ministr přistěhovalectví chris bowen .
ministr přistěhovalectví brendan o &apos; connor , který byl včera na srí lance , kde jedná s úředníky kvůli pašování lidí , implementoval pět z doporučených změn a ostatní zbývají ke zvážení .
pokud budou kritéria „ oprávněnosti “ přijata , žadatelé o víza mohou být podrobně zkoumáni , zda „ je nominace oprávněná za situace , kdy je kandidát ve vztahu nebo osobním spojení s majitelem nebo relevantní osobou sponzorujícího podniku . “
po předchozích zkušenostech s podniky , které zamýšlely sponzorovat malý počet pracovníků , ale pak jich zaměstnaly stovky , se od podniků také může vyžadovat zdůvodnit počet držitelů víza 457 .
mezitím 35letý muž ze srí lanky , který usiloval o azyl , zemřel s podezřením na infarkt poté , co tento týden dorazil na azylové lodi na vánoční ostrovy .
mužův devítiletý vystrašený syn cestoval do austrálie spolu s ním a po smrti svého otce ve středu ho utěšoval dospělý bratranec , který byl také na lodi .
australské úřady s mužem spěchaly do nemocnice na vánočních ostrovech , kde zemřel .
britská vláda oznámila studii , která má za cíl zvýšit výhody železničního projektu hs2 pro skotsko .
práce společnosti hs2 naznačuje , že vysokorychlostní služby pro skotsko a severní anglii začnou , jakmile se v roce 2026 spustí první fáze .
ministryně dopravy baronka kramerová řekla , že projekt „ spojí velkou británii dohromady “ .
skotský ministr dopravy keith brown řekl , že byl spoluprací s britskou vládou na tomto plánu „ nadšený “ .
první fáze se bude skládat z nové vysokorychlostní vlakové linky mezi londýnem a west midlands .
po dokončení fáze dvě povede linka z manchesteru do leedsu .
v červnu vláda přehodnotila odhadované náklady na vybudování vysokorychlostní linky mezi londýnem a severní anglií z 32,7 miliard gbp na 42,6 miliard gbp .
britská vláda , která vedla rozhovory s národní dopravní kanceláří transport scotland , pověřila společnost hs2 , aby zjistila další železniční kapacitu a možnost zlepšení cestovních časů pro severní anglii a skotsko .
to zahrnuje možnost eventuálních cestovních časů z glasgow a edinburghu do londýna odpovídajících třem a méně hodinám .
baronka kramerová řekla : „ naším cílem pro hs2 je opravdu národní síť , která lépe propojí velkou británii a její města . “
dali jsme sh2 zelenou , protože užitek , který to přinese , je obrovský .
bez toho čelíme krizi v kapacitě naší železniční sítě .
jde však také o propojení – napříč velkou británií bude díky hs2 lépe propojeno 18 měst včetně glasgow a edinburghu .
skotský ministr alistair carmichael dodal : „ dnešní oznámení je pro skotsko dobrou zprávou . “
za skotskou vládu keith brown pana carmichaela vyzval k tomu , aby „ jednoznačně “ podpořil skotské začlenění do sítě hs2 .
pan brown řekl : „ vysokorychlostní trať má potenciál přinést skotsku nezměrné ekonomické výhody , ale také dodává ekonomickou váhu skotska v celkovému případu vysokorychlostní železnice napříč británií . “
s nadšením tedy spolupracujeme s britskou vládou na zkoumání možností přivést do skotska vysokorychlostní železnici a tak přinést všem užitek a doplnit linku glasgow-edinburgh , což skotská vláda tak jako tak plánuje .
těším se na přezkoumání zprávy o této studii spolu s britskými ministry během příštího roku a na společné rozhodování o dalších krocích .
společně s bártou zatkla inspekce i analytika protikorupční policie
informace o zatčení víta bárty se začaly šířit ve čtvrtek večer , kdy zprávu přinesl server prvnízpravy.cz.
mf dnes záhy zjistila , že si případ vzala na starost generální inspekce bezpečnostních sborů ( gibs ) , její lidé měli bártu zatknout v centru prahy .
odehrálo se to před hotelem four seasons .
inspekce řeší případy , kdy jsou mezi obviněnými policisté , její pravomoc se však vztahuje i na civilní osoby .
podle mf dnes je mezi zatčenými i jeden z důstojníků protikorupční policie - vedoucí analytiky a informatiky jan petržílek .
ten v minulosti pracoval pro bezpečnostní informační službu .
mluvčí protikorupční policie jaroslav ibehej ale odmítl informace komentovat s dovětkem , že se média musí v této věci obracet právě na gibs .
i její mluvčí inspekce radka sandorová ale nechtěla k případu cokoli říci , obratem odkázala na městské státní zastupitelství v praze .
&quot; tento dotaz nebudeme s ohledem na ochranu utajovaných skutečností nijak komentovat , &quot; řekla mluvčí zastupitelství štěpánka zenklová .
také z této nekonkrétní reakce lze odvodit , že událost se odehrála , ale je v režimu utajení , který mluvčím nedovoluje říci cokoli konkrétního .
v podobné situaci je i bártův advokát oldřich chudoba .
ten mediím řekl , že bártu zastupuje &quot; i v této věci &quot; , ale vzhledem k tomu , že jde o utajované informace , nemůže bártovo zatčení potvrdit ani vyvrátit .
některá média nejdříve spekulovala , že by bártovo zatčení mohlo souviset s někdejším policejním prezidentem petrem lessym .
toho prosazovali do funkce právě bárta společně s bývalým předsedou vv radkem johnem , který seděl v čele ministerstva vnitra .
spor , který se kvůli tomu rozhořel mezi expremiérem petrem nečasem a vv musel dokonce řešit i tehdejší prezident václav klaus .
netuším , kde se tato souvislost na moji osobu vzala .
nikdo mne nekontaktoval , nebyl jsem vyslýchán .
&quot; o věci opravdu nic nevím , &quot; řekl idnes.cz lessy .
v lednu 2011 se lessy stal šéfem policie .
oficiálně ho tak sice prosadil radek john , opravdovým šéfem strany ale byl tehdy právě bárta .
bárta nyní kandidoval do voleb za hnutí úsvit , poslanecký mandát mu unikl jen těsně - o 175 hlasů .
lídr úsvitu tomio okamura prohlásil , že vůbec netuší , o co se jedná .
&quot; vít bárta byl jedním z mnoha kandidátů mnoha stran na naší kandidátce a jak jsem opakovaně říkal již před volbami , nebyl ani není člen úsvitu přímé demokracie tomia okamury , &quot; distancoval se od bárty okamura , který před volbami říkal , že dal bártovi prostor kandidovat za úsvit , protože mu pomohl řešit problém exekutorů .
vít bárta se ocitl u soudu v roce 2012 se svým bývalým spolustraníkem z vv jaroslavem škárkou .
pravidla o použití elektronických zařízeních v letadle zůstanou v austrálii prozatím v platnosti
cestující australských leteckých společností budou muset i nadále vypínat své tablety a chytré telefony během startování a přistávání i bez ohledu na změny v usa za účelem zmírnění předpisů ohledně těchto zařízení .
americká federální letecká správa ( faa ) dala americkým společnostem prostor , aby změnily své postupy , takže cestující budou schopni na svých zařízeních číst elektronické knihy , sledovat videa nebo hrát hry během kritických fází letu , pokud zařízení zůstanou v „ leteckém “ režimu .
cestující již toto mohou dělat během převážné části letu , ale mnohé lidi otravuje , že nemohou mít přístup ke svým elektronickým knihám během startu a přistání .
australští dopravci zkoumají toto rozhodnutí , které od amerických dopravců vyžaduje velký kus práce , aby byly splněny dané požadavky , ale naznačili , že nemají v brzké době v plánu změnit své postupy .
úřad pro bezpečnost civilního letectví ( casa ) také řekl , že toto oznámení prozkoumal , ale zdůraznil , že omezení týkající se použití elektronických zařízení v kritických fázích letu jsou v austrálii stále ještě v platnosti .
„ casa v současné době nemá žádné konkrétní předpisy regulující použití elektronických zařízení v letadle , “ uvedl .
tato otázka je pokryta předpisy , které od provozovatelů letadel vyžadují zajistit , že po celou dobu bude zachována bezpečnost a že pasažéři jednají v souladu s bezpečnostními pokyny , které získají od členů posádky .
společnost virgin , která již s casa mluvila o rozšíření použití svého palubního zábavního systému wi-fi , byla změně nakloněna , ale oznámila , že se podrobí rozhodnutí regulačního úřadu .
„ uvítali bychom , kdyby úřad casa provedl analýzu svolení používat elektronická zařízení , protože si opravdu myslíme , že by to nyní , kdy máme ( bezdrátovou palubní zábavu ) , zlepšilo zážitky zákazníků , “ řekl mluvčí .
společnost qantas oznámila , že se prozatím bude držet současných předpisů .
„ naše současná politika je taková , že elektronická zařízení se nesmí používat během vzletu a přistání , a nemáme v úmyslu to v brzké době změnit , “ řekl .
předpisy faa se vztahují na americké letecké společnosti .
neustále se ale zajímáme o vývoj v regulační oblasti , který může být pro naše cestující užitečný , a určitě si důkladně prostudujeme rozhodnutí faa a důvody , které za ním jsou .
v případě leteckých dopravců z usa se dopad předpisů bude společnost od společnosti lišit a bude záviset na stáří jejich leteckého parku .
dopravci budou muset doložit , že jejich letadla mohou tolerovat rádiové rušení mobilních telefonů , a také revidovat příručky , školicí materiál , programy pro příruční zavazadla a informace pro cestující .
„ jakmile letecká společnost potvrdí toleranci své flotily , může cestujícím dovolit použít přenosná a lehká elektronická zařízení , jako jsou tablety , elektronické čtečky a chytré telefony , v jakékoli nadmořské výšce , “ uvedla faa .
ve vzácných případech nízké viditelnosti posádka nařídí cestujícím , aby si během přistání zařízení vypnuli .
skupina také doporučila , aby byla těžší zařízení během vzletu a sestupu bezpečně uložena pod sedadly nebo v úložném prostoru nad hlavou .
s rostoucí bídou střední třídy zažívají zastavárny v singapuru rozkvět
v zastavárně v nákupním centu bendemeer v singapuru zastavuje janani amirthalingaová zlatý náramek , prsten a náušnice , aby mohla své dceři zaplatit školné .
„ se svým manželem jsme právě koupili dům a dala jsem na to všechny své peníze , “ říká paní amirthalingaová .
přestože každý měsíc jako administrátorka dostává 2400 dolarů ( 3000 sgd ) a její manžel také pracuje , rodinný měsíční příjem je nedostačující , říká .
poptávka napříč oblastmi v jihovýchodní asii – kde se zvyšuje dluh domácností – je vskutku taková , že společnost valuemax , kde žena provádí svou transakci , se tento týden stala na burze v singapuru třetí zastavárnou na žebříčku .
zastavení šperků není jen rychlou cestou k půjčení hotovosti – 1300 sgd v případě paní amirthalingaové – , ale je také téměř tak levné , jako nezabezpečené bankovní půjčky .
zastavárny v singapuru běžně uplatňují roční procentuální sazbu 17 procent , těsně nad 15,4procentní sazbu nabízenou bankou united overseas bank , místní bankou s pobočkou ve stejném nákupním centru .
zastavárny však mají tu výhodu , že nevyžadují ověření osoby ( platební historie ) nebo doklad o příjmu , a mohou poskytnout půjčku rychleji než banky .
a proto s tím , jak rodiny pociťují tlak kvůli zvyšujícím se životním nákladům a rostoucímu dluhu domácností a spotřebitelského dluhu , miliony lidí napříč regionem se obrací na zastavárny .
po pěti letech mohutného růstu od globální finanční krize a levných úvěrech podporovaných uvolněnou peněžní politikou v pokročilých ekonomikách se rodiny s nízkým a středním příjmem obracejí na zastavárny , aby se vypořádaly se zhoršující se finanční situací .
tento týden ratingový agentura standard &amp; poor &apos; s citovala zvyšující se využívání úvěru v domácnostech především kvůli zvyšujícím se nájmům jako rizikový faktor pro úvěruschopnost asijských bank .
řekla , že malajsie , thajsko a singapur mají vhledem k hrubému domácímu produktu nejvyšší dluh domácností v asii .
malajsie je na čele žebříčku s poměrem 80 procent hdp , což je nárůst oproti 60 procentům v roce 2008 .
ekonomové se také obávali vysoké úrovně spotřebního dluhu v thajsku , které se tento týden jen tak tak dostalo z technické recese .
ve čtvrtek data ukázala pokračující slabý vývoz a zeslabení spotřebitelské poptávky .
„ podstatné je , že se zvyšujícími se náklady se lidé od střední do nízké &#91; příjmové škály &#93; budou snažit doplnit svůj příjem , kdekoli budou moci , “ řekl song seng wun , ekonom v malajsijské bance cimb .
historicky vysoké ceny zlata v minulých dvou letech přispěly k tomu , že lidé chvatně zastavují svůj osobní majetek a využívají příležitost směnit za hotovost své rodinné šperky .
asi 70 procent z položek zastavených ve 200 městských zastavárnách tvoří zlato .
lidé říkají : cena zlata vypadá dobře , zastavíme babiččin zlatý náhrdelník a dostaneme ho zpátky příští měsíc .
největší provozovatel zastaváren v thajsku , easymoney , zaznamenal v nedávných měsících až 20procentní navýšení v počtu zákazníků využívajících jeho zastavárny .
růst v zastavárenském odvětví je tak velký , že valuemax , provozovatel pobočky v centru bendemeer a 15 podobných v singapuru , plánuje expandovat nejen do sousední malajsie – kde má čtyři pobočky – , ale i mimo asii , říká výkonná ředitelka valuemax yeah lee chingová .
společnost to bude financovat použitím 60 procent z 66 milionů sgd , které tento týden získala na singapurské burze .
zatímco někteří diskontní věřitelé se ocitli pod palbou kritiky kvůli vysokým úrokům , paní yeah říká , že zástava nabízí nejen nižší sazby než ostatní věřitelé , ale také to přímo nezvyšuje dluh .
„ zákazníci zastavují předměty , které již vlastní , a zpeněžování osobního majetku nezvyšuje dluh domácnosti , “ říká .
ve společnosti je zástava majetku stále více přijímána jako prostředek k zajištění krátkodobého , zabezpečeného financování .
mezi těmi , kdo využívají zastavárny , navíc nejsou jen lidé ve finanční tísni .
bohatí lidé ze singapuru také využívají pobočky valuemax , když zastavují zlaté pruty nebo hodinky rolex , a mohou se tak dostat až k 60 procentům nákupní ceny v hotovosti .
naši zákazníci jsou ze všech možných poměrů .
„ patří k nim bohatí jednotlivci , kteří si potřebují krátkodobě půjčit kvůli svým odvážným obchodům nebo investicím , nebo malé podniky , které potřebují pomoc s vyřešením problémů v jejich peněžním toku , “ říká paní yeahová .
někdy prostě potřebují peníze co nejrychleji .
záchranný balíček v hodnotě 325 milionů dolarů pro tasmánské zdravotnictví
federální vláda trvá na tom , aby záchranný balíček v hodnotě 325 milionů dolarů pro skomírající zdravotnictví v tasmánii obsahoval tvrdé podmínky , které zajistí , že státní vláda nepromrhá finanční prostředky .
federální ministryně zdravotnictví tanya pliberseková oznámila , že australský svaz činí „ urychlená opatření “ k odvrácení krize způsobené stárnoucí populací ostrova , vyšším počtem chronických chorob a systémovými poruchami .
financování po dobu čtyř let bylo rozhodnuto po vládních konzultacích s nezávislým tasmánským poslancem andrewem wilkiem .
„ vláda přišla s nouzovým záchranným balíčkem , který , jak věříme , vyřeší specifické problémy , kterým stát čelí , “ řekla dnes paní pliberseková .
balíček 325 milionů dolarů obsahuje 31 milionů dolarů na operace na žádost pacienta .
dalších 2600 operací včetně ortopedických operací a operací šedého zákalu pomohou odstranit zadluženost .
peníze jsou i na volně přístupné kliniky v hobartu a launcestonu , lepší pooperační péči , školení zdravotních specialistů , služby duševního zdraví a uvedení osobních elektronických systémů zdravotnických záznamů v místních nemocnicích .
„ tyto investice reagují na myšlenky , o kterých mi přední kliničtí lékaři řekli , že nejlepším způsobem pomohou tasmánskému zdravotnickému systému , “ řekla paní pliberseková .
ministryně zdůraznila , že tasmánská vláda musí vyžadovat přísný režim výkaznictví a evidenční povinnosti .
stát bude muset zachovat současnou úroveň financování , aby obdržel peníze australského svazu , a měsíčně informovat o tom , kde byly vynaloženy dodatečné finanční prostředky .
bude ustanoven tříčlenný výbor , který zajistí , že stát dodává služby tak efektivně , jak je to možné .
pan wilkie dnes řekl , že 325 milionů dolarů nebude k ničemu , „ dokud nebude následovat opravdová reforma za účelem položení udržitelnějšího základu tasmánského veřejného zdravotního systému “ .
přesto chválil vládu za reakci na jeho žádost o urychlenou pomoc , kterou poprvé vznesl při jednání s předsedou vlády začátkem května .
„ věřím , že federální pomocný balíček dokáže vyprostit státní veřejné zdravotnictví z kritického stavu , “ řekl pan wilkie .
podle státní vlády tyto dodatečné zvolené procedury výrazně zvrátí nedávné škrty .
mluvčí federální opozice v oblasti zdravotnictví peter dutton věří , že dnešní prohlášení je jen „ náplastí “ .
„ důvodem , proč jsem zde , je , že labouristická vláda vyjmula z našeho zdravotnického systému 430 milionů dolarů , “ řekl pro abc tv .
nemůžete mít státní vládu , která odebere téměř půl miliardy dolarů , a australský svaz , který věnuje 300 milionů dolarů , a tvářit se , že je to dobrá zpráva .
pan dutton vyzval paní plibersekovou , aby zaručila , že ani jeden dolar ze záchranného balíčku nebude vydán na vyšší byrokracii .
guillaume nicloux adaptoval novelu denise diderota , jež přináší výjimečnou filmovou výpravu a ztvárnění doby , ale je také nudnější , než by měla být .
odvíjí se v 60. letech 18. století ve francii a vypráví pochmurný příběh o suzanne , mladé šlechtičně , která je svou rodinou poslána do kláštera .
když se vzbouří , zažívá extrémně kruté zacházení od trestuhodně zvrhlé matky představené a pro jinou se stává objektem sexuální vášně .
film nikdy nesklouzne k chlípnosti nebo senzačnosti a to je jeho problém .
obřadní ráz tohoto příběhu vede k tomu , že i diváci budou zažívat muka podobná nošení žíněné košile .
skiareály chtějí zlevnit rodinám s dětmi
sýrie zničila své prostředky pro výrobu chemických zbraní , říká dohlížecí orgán
sýrie zničila zásadní vybavení pro výrobu chemických zbraní a munice s jedovatým plynem , řekl ve čtvrtek výbor pro globální dohled nad chemickými zbraněmi , zatímco vypukly prudké konflikty na severu země , a to nedaleko jednoho z míst , kde jsou podle předpokladů uloženy jedovaté látky .
ve čtvrtek také syrská aktivistická skupina prohlásila , že od začátku občanské války před téměř třemi lety bylo zabito více než 120 000 obyvatel .
oznámení organizace pro zákaz chemických zbraní přišlo den před 1. listopadem ,
termínem , který tato organizace se sídlem v haagu stanovila damašku pro zničení nebo znemožnění provozu všech zařízení pro výrobu chemických zbraní a strojního vybavení pro míchání chemických látek za účelem vytvoření jedovatého plynu a plnění munice .
dokončení této v zásadě počáteční fáze zničení je významným milníkem v ambiciózním časovém rozvrhu , který si klade za cíl zničit do poloviny roku 2014 všechny chemické zbraně damašku .
zničení vybavení znamená , že sýrie už nebude schopna vyrábět nové chemické zbraně .
damašek však ještě musí zahájit zničení existujících zbraní a zásob .
předpokládá se , že tato země má asi 1 000 tun chemických látek a zbraní včetně yperitu a nervového plynu sarinu .
oznámení přišlo ve chvíli , kdy ve čtvrtek zuřily boje ve městě safira , o kterém experti mluví jako o sídle továrny na výrobu chemických zbraní i úložišť , uvedla syrská pozorovatelna pro lidská práva se sídlem v británii .
skupina aktivistů , která prostřednictvím sítě aktivistů v sýrii monitorovala celkový počet obětí , ve čtvrtek oznámila , že zemřelo 120 296 lidí .
z toho má být 61 067 civilistů , včetně 6 365 dětí .
na vládní straně má jít o 29 954 členů ozbrojených sil bašára asada , 18 678 provládních bojovníků a 187 ozbrojenců z libanonského hizballáhu .
mezi zabitými má být také 2 202 vládních přeběhlíků a přibližně 5 375 opozičních bojovníků , z nichž mnozí jsou cizinci .
dne 25. července organizace osn odhadla , že od března 2011 v konfliktu zemřelo 100 000 lidí .
od té doby toto číslo nebylo aktualizováno .
konflikt přinutil asi 2 miliony obyvatel , aby zemi opustily .
asadovy jednotky bojovaly v safiře proti povstalcům , z nichž mnozí jsou spojováni s al-káidou , celé týdny .
pozorovatelna ve čtvrtek uvedla , že ztráty byly na obou stranách , ale neměla konkrétní čísla .
boje podtrhly nebezpečí , jemuž čelí inspektoři pro chemické zbraně , kteří se při své misi , kdy mají uprostřed pokračující občanské války sýrii zbavit chemického arzenálu , musejí vypořádat s těsnými termíny .
v prohlášení od úřadu opcw , které blízce spolupracuje s osn , bylo řečeno , že jeho tým je nyní „ spokojený , že ověřil – a sledoval zničení – syrského deklarovaného zásadního vybavení pro výrobu a míšení / plnění “ .
dodal , že „ v současné době nejsou plánovány žádné další kontrolní aktivity “ .
dříve tento týden inspektoři řekli , že dokončili první kolo ověřovacích prací , když navštívili 21 z 23 míst deklarovaných damaškem .
inspektoři řekli , že kvůli obavám o bezpečnost nebyli schopni navštívit dvě místa .
ve čtvrtek úřad opcw uvedl , že tato dvě místa byla podle sýrie „ opuštěna a ... položky programu chemických zbraní , které obsahovala , byly přesunuty do dvou jiných deklarovaných míst , která byla zkontrolována “ .
nebylo okamžitě jasné , zda zařízení v safiře bylo jedním z těch míst , která inspektoři opcw nemohli navštívit .
sýrie odsouhlasila plán úplného zničení svých chemických zbraní , který musí být schválen příští měsíc výkonným výborem úřadu opcw .
„ klaním se odvaze a statečnosti , kterou jste projevili při naplnění této nejnáročnější mise , jakou kdy tato organizace měla , “ řekl ředitel pozorovatelů ahmet uzumcu ve svém komentáři vydaným úřadem opcw .
nyní , ve svém třetím roce , stojí proti sobě v občanské válce především sunnitští muslimští rebelové a asadova vláda se svými bezpečnostními silami , které jsou plné členů sekty alawitů , odnože šíitského islámu .
pokud jde o další vývoj , šéf pozorovatelny ramí abdul rahmán řekl , že ve středu došlo k silnému výbuchu uvnitř zařízení protivzdušné obrany v syrské pobřežní provincii lázikíja .
řekl , že příčina výbuchu nebyla známa .
hněv nad rozsudkem vyneseným nad osnovatelem bombového útoku na bali
přeživší a příbuzní 202 osob zabitých v bombovém útoku na bali v roce 2002 rozezleně reagovali na rozsudek vynesený nad posledním z osnovatelů , kteří byli postaveni před spravedlnost , a řekli , že umar patek měl být popraven .
patek , který téměř 10 let strávil na útěku jako jedna z nejhledanějších osob v jihovýchodní asii , byl včera odsouzen k 20 letům vězení za to , že sestavil výbušná zařízení , která byla použita při bombovém útoku .
za 15 let by mohl být podmínečně propuštěn .
tento 45letý muž byl shledán vinným z hromadné vraždy při útoku na dva noční kluby v populární turistické oblasti kuta , po kterém zůstalo 202 lidí mrtvých , včetně 88 australanů , a mnoho zraněných .
byl také shledán vinným v několika dalších bodech obžaloby souvisejících s terorismem , včetně série bombových útoků na kostely v indonésii na štědrý večer roku 2000 .
obžaloba požadovala doživotí , přestože mohla trvat na tom , aby muž s přezdívkou „ demolition man “ ( bourač ) díky své pověsti odborníka na výrobu výbušnin dostal trest smrti .
toto rozhodnutí znovu oživilo bolestivé vzpomínky june corteenové , matky z perthu , která při ničivém útoku spuštěném patekem a dalšími osnovateli před téměř deseti lety ztratila svá 39letá dvojčata jane a jenny .
se slzami v očích řekla , že patek měl být odsouzen k smrti .
opravdu si myslím , že by měl jít ve stopách těch ostatních .
pro agenturu aap paní corteenová řekla : „ měl by být postaven před popravčí četu . “
každý den musím žít s tím , že neuvidím další vnoučata a své dcery .
klub sari byl srovnán se zemí , když byla 12. října 2002 krátce po 23. hodině odpálena silná nálož umístěná ve venku zaparkované dodávce .
peter hughes byl v baru paddy , kde jen o 20 sekund dříve sebevražedný atentátník odpálil batoh naplněný výbušninami .
v důsledku výbuchu upadl na měsíc do kómatu , a zatímco byl udržován při životě , třikrát lékařům „ zemřel “ .
pan hughes řekl , že pateka by měl potkat stejný osud jako tři ostatní členy teroristické buňky džamá islámíja zodpovědné za masakr – amroziho , muchlase a imáma samudru – , kteří byli popraveni před čtyřmi lety .
tenhle chlapík by měl dostat trest smrti jako nikdo .
držet ho naživu ... žádný důvod , proč ho držet naživu , prostě není .
dostat 20 let za to , že 202 lidí zabil a stovky dalších zranil , zas tak moc není .
patek stál před soudem jako poslední z atentátníků na bali .
zatčení se vyhýbal téměř deset let , ale nakonec byl v lednu 2011 dopaden v pákistánském městu abbottábád , kde o necelé čtyři měsíce později americké síly zabily bývalého vůdce al-káidy usámu bin ládina .
během soudu agent fbi ve svém svědectví prohlásil , že zprávy zpravodajských služeb odhalily , že patek byl v pákistánu , aby se setkal s bin ládinem ve snaze znovu navázat spojení mezi teroristickými skupinami z jihovýchodní asie a al-káidou .
„ nevzdal se dobrovolně , “ řekla paní corteenová .
do dnešní doby nepocítil lítost za to , kolik zármutku způsobil druhým .
verdikt přichází před 10. výročím útoku , které bude později tento rok a ke kterému budou patřit ceremonie na bali a v austrálii .
„ tento rok uvidíme hodně slz , “ řekla paní corteenová .
patek se ještě vůči rozsudku může odvolat .
faa : cestující v letecké dopravě nyní mohou v letadlech používat technologické výdobytky ( ale nesmí volat ze svých mobilních telefonů )
pasažéři leteckých společností budou moci svá elektronická zařízení používat „ od brány k bráně “ – kromě volání ze svých mobilních telefonů – ke čtení , hraní her , sledování filmů a poslechu hudby na základě netrpělivě očekávaných nových pravidel , která ve čtvrtek vydala federální letecká správa ( faa ) .
cestující ale nemají očekávat , že změny nastanou okamžitě .
jak rychle bude změna zavedena se bude podle jednotlivých leteckých společností lišit , řekl správce faa michael huerta na tiskové konferenci .
letecké společnosti budou muset správě faa doložit , nakolik jejich letouny odpovídají novým pravidlům a že aktualizovaly školicí příručky pro palubní posádku a směrnice pro ukládání zařízení , aby byly v souladu s novými pravidly .
faa uvedla , že již od některých leteckých společností obdržela plány , jak rozšířit použití přenosných elektronických zařízeních v letadlech .
mezi společnostmi , které již plány předaly , jsou delta a jetblue .
„ v závislosti na stavu takového plánu můžeme zlepšit rozšířené použití elektronických zařízení velice rychle , “ uvedla faa ve svém prohlášení .
v současnosti se od cestujících požaduje , aby vypnuli své chytré telefony , tablety a další zařízení , jakmile se zavřou dveře letadla .
nemohou je zapnout , dokud letadlo nedosáhne výšky 3 kilometrů a kapitán nevydá povolení .
od cestujících se očekává , že svá zařízení vypnou znovu tehdy , když se letadlo klesá , aby přistálo , a nezapnou je , dokud letadlo není na zemi .
podle nových pravidel mohou letecké společnosti , jejichž letadla jsou správně chráněna vůči elektronickému rušení , dovolit svým pasažérům používat svá zařízení během vzletu , přistání a pojíždění , uvedla faa .
od většiny nových dopravních letadel a dalších letadel , která byla upravena tak , aby cestující mohli používat wifi u vyšší nadmořské výšky , se očekává , že tato kritéria splní .
laura gladingová , prezidentka asociace profesionálních stevardů , změny přivítala .
„ jakmile budou nová pravidla bezpečně zavedena – a my na tom s dopravními společnostmi budeme úzce spolupracovat – , bude to úspěch , “ řekla ve svém prohlášení gladingová .
už nás upřímně řečeno unavuje , že vypadáme jako „ hlídači “ .
avšak surfování na internetu , zasílání e-mailů a sms či stahování dat bude i nadále pod 3 kilometry nadmořské výšky zakázáno , řekla agentura .
cestujícím bude oznámeno , aby své chytré telefony , tablety a další zařízení přepnuli do leteckého režimu .
takže stále ještě žádná words with friends , online hra typu scrabble , kterou hrál herec alec baldwin na svém chytrém telefonu v roce 2011 , když byl , jak je dobře známo , vyhozen z letadla společnosti american airlines , protože odmítl vypnout své zařízení , když bylo letadlo zaparkováno u brány .
a těžší zařízení jako notebooky budou muset být nadále uložena kvůli obavám , že by někoho mohly zranit , pokud by poletovaly po kabině .
hovory z mobilních telefonů budou na palubě i nadále zakázány .
pravidla pro používání mobilních telefonů neurčuje faa , ale americký federální výbor pro telekomunikace .
faa může u některých elektronických zařízeních během vzletu a přistání zrušit zákaz .
minulý měsíc mark rosenker ze státního výboru pro bezpečnost v dopravě , odborník na národní bezpečnost v dopravě při cbs news , řekl , že mobilní telefony se i nadále považují za riziko .
„ mobilní telefony jsou opravdu problémem , nejen proto , že mohou potenciálně vytvořit rušení s navigačními přístroji , ale z údajů fcc také víme , že ve vzduchu mohou způsobit rušení vysílacích věží , “ řekl rosenker .
oborový poradní výbor vytvořený správou faa proto , aby prozkoumal tento problém , minulý měsíc navrhl , aby vláda dovolila širší používání elektronických zařízení .
na faa byl v posledních letech vyvíjen nátlak , aby zmírnila omezení na jejich používání .
kritici , jako je senátorka claire mccaskillová , demokratka z missouri , tvrdí , že neexistuje žádný právoplatný bezpečnostní důvod pro tento zákaz .
omezení se také stále obtížněji prosazují , protože používání takových zařízení je všudypřítomné .
některé studie naznačují , že až třetina cestujících zapomíná i na povinnost vypnout svá zařízení nebo ji ignoruje .
faa začala omezovat používání elektronických zařízení cestujícími v roce 1966 v reakci na rušení navigačního a komunikačního vybavení , když cestující začali s sebou nosit fm rádia , technický výdobytek tehdejší doby .
nové letecké společnosti jsou mnohem více odkázané na elektrické systémy než letadla předchozích generací , ale jsou také zkonstruována , a schválena správou faa , aby byla odolná vůči elektronickému rušení .
letecké společnosti již po několik let nabízely cestujícím používání wi-fi v cestovních nadmořských výškách .
plány upravené pro systémy wi-fi jsou také odolnější vůči rušení .
velká většina leteckých společností by se v rámci nových pravidel měla uzpůsobit pro větší používání elektronických zařízení , řekla huertová .
současná elektronická zařízení obecně vyzařují mnohem méně intenzivní rádiové vysílání , než tomu bylo u zařízeních předchozích generací .
například elektronické čtečky vydávají při obracení stránky pouze minimální vysílání .
ale vysílání je silnější , když zařízení stahují nebo odesílají data .
mezi těmi , kdo tlačí na to , aby se uvolnila omezení pro používání těchto zařízení cestujícími , je amazon.com.
v roce 2011 zástupci této společnosti naložili dopravní letadlo svými elektronickými čtečkami kindle a provedli zkušební let , ale žádný problém se neobjevil .
členové poradního výboru faa vyjádřili smíšené pocity , pokud jde o to , zda tato zařízení představují nějaká rizika .
douglas kidd z národní asociace pasažérů leteckých společností řekl , že je přesvědčen , že rušení z těchto zařízení je skutečné , a to i tehdy , pokud je riziko minimální .
jiní členové výboru prohlásili , že existují pouze útržkovité zprávy od pilotů , které mají podpořit fakt , že taková zařízení mohou způsobit rušení leteckých systémů , a většina z těchto zpráv je velmi stará .
výbor však doporučil , aby faa pilotům dovolila nařídit pasažérům vypnout zařízení během létání podle přístrojů za nízké viditelnosti .
skupina cestovního průmyslu přivítala tyto změny a jde podle ní o rozumný postup pro cestující veřejnost , která technologie využívá v hojné míře .
„ jsme potěšeni , že faa uznala , že příjemný cestovní zážitek není v rozporu s bezpečností , “ řekl roger dow , výkonný ředitel americké cestovní asociace .
pták byl letecky dopraven z vrtné plošiny v severním moři a vypuštěn zpět do přírody
pták byl dopraven na pobřeží poté , co byl nalezen vyčerpaný na ropné plošině v černém moři , a vypuštěn zpět do volné přírody .
jeden chřástal byl minulý měsíc vrtulníkem převezen do aberdeenu poté , co jej předtím ošetřovala skotská společnost spca v záchranném středisku , dokud se neuzdravil .
provozní centra colin seddon řekl : „ tento chřástal pravděpodobně migroval ze severní evropy , když jej nad severním mořem zachytil silný vítr . “
podle všeho mu došly síly a útočiště našel na ropné plošině .
pan seddon dodal : „ nebyl schopen znovu vzlétnout , takže nás kontaktovali se žádostí o pomoc . “
v době , kdy byl chřástal vypuštěn , byl v dobré kondici a zdráv .
je evropská elita připravená na obchod s británií ?
kampaň business for britain ( obchod pro británii ) byla spuštěná v dubnu s příslibem spojit podniky a definovat , jaké změny ve vztahu s eu chtějí vidět britští podnikatelé a společnosti vytvářející pracovní místa .
za tímto účelem jsme zadali největší a nejkomplexnější průzkum , při kterém jsme se předních britských podnikatelů ptali na jejich názory ohledně británie , obchodu a eu .
yougov se dotazoval 1 000 vedoucích podnikatelů reprezentujících britské podniky nejrůznějších velikostí a z různých sektorů a regionů .
výsledky průzkumu budou pro mnohé překvapením .
zjistili jsme , že drtivá většina podniků se nyní snaží vyvážet mimo evropu a soustředí se na země , které modernizují a rostou , zatímco státy eu stagnují .
chtějí vidět , jak vláda upřednostňuje nové obchodní vazby se zeměmi , jako je čína , indie a brazílie , než aby zabředly do dlouhého a namáhavého procesu reformování tajemných evropských institucí .
když jsme se zeptali na jejich názory na konkrétní politické oblasti – od monopolních regulací po zákony o výrobcích – , většina podnikatelů vyjádřila názor , že kontrola těchto klíčových kompetencí by se měla vrátit westminsteru .
panovala obecná nespokojenost s jednotným trhem a podnikatelé říkali , že náklady bruselských regulací nyní převažují výhody toho , být součástí evropské obchodní oblasti – souhlas vyjádřilo dokonce 40 procent velkých podniků , tedy tradičně nejvíce proevropské společnosti .
a nakonec náš průzkum vedoucích podniků odhalil to nejvýmluvnější poznání , a sice že jednoznačná většina chce , aby británie usilovala o změnu smlouvy a vztahu s eu , který by měl být založen na obchodu , ne politice .
ze zjištění , s nímž se ztotožnily podniky různých velikostí a hlavní podnikatelské skupiny , vyplývá , že podnikatelský sektor tlačí na „ smysluplnou změnu “ , která přenese vliv zpátky na británii .
v sázce je hodně – dosažení změny smlouvy a lepší dohody pro británii může znamenat zisk až 16 % při hlasování v referendu pro setrvání v eu .
předseda vlády by neměl váhat : tento průzkum ukazuje , že britský obchod podporuje jeho plán novelizace podmínek britského členství v eu .
také to ukazuje , že podnikatelský sektor očekává , že tato novelizace bude znamenat výrazný posun od současného vyvážení sil zpět směrem k británii .
lepší dohoda pro británii je možná a vzhledem k tomu , jak se eurozóna vydává na cestu za užší ekonomickou a fiskální unií , i stále nutnější .
prioritou musí být pracovní místa a růst v británii , a jak ukazují výsledky našeho průzkumu , pro podnikání to znamená opětovné zaměření se na obchod a zásadní změnu v regulačním přístupu bruselu .
john kerry přiznal : špehování zašlo příliš daleko !
spojené státy zašly ve špehování občas &quot; příliš daleko &quot; , připustil podle agentury afp šéf americké diplomacie john kerry během videokonference mezi washingtonem a londýnem .
sběr informací ale podle ministra posloužil k odvracení teroristických útoků .
&quot; první přiznání z washingtonu &quot; podle afp zaznělo uprostřed prudké polemiky na obou březích atlantiku kvůli skandálním odhalením o hromadném sledování dat americkou národní bezpečnostní agenturou ( nsa ) , jehož terčem se stali i američtí spojenci .
&quot; v některých případech , připouštím , stejně jako učinil prezident ( barack obama ) , některé z těchto akcí zašly příliš daleko a ujišťujeme , že se to v budoucnu nestane , &quot; řekl kerry .
v rozhovoru ale především obhajoval dosavadní praxi .
sběr informací je podle něj nezbytný pro boj proti terorismu a zabránění atentátům , jako byly útoky z 11. září 2001 v usa , atentáty v madridu v březnu 2004 či v londýně v červenci 2005 .
&quot; zabránili jsme tomu , aby letadla padala , budovy explodovaly a lidé byli vražděni , protože jsme byli schopni být včas informováni o úkladech , &quot; zdůraznil kerry .
nicméně znovu připustil , že sběr informací &quot; v některých případech zašel nepřiměřeně daleko &quot; .
aféra kolem americké rozvědky , která údajně sledovala stamiliony telefonických hovorů , v evropě propukla tento měsíc .
mimo jiné se ukázalo , že američané sledovali i mobilní telefon německé kancléřky angely merkelové .
evropští lídři neskrývali rozhořčení a někteří z nich vyzvali evropskou unii , aby se pokusila se spojenými státy dosáhnout dohody , která by sledování zapovídala či významně omezovala .
alexei miller ze společnosti gazprom říká , že potrubí v bulharsku zahajuje novou plynovou éru
zahájení stavby plynovodu south stream v bulharsku znamená spuštění jednoho z největšího evropských energetických projektů , řekl ředitel gazpromu .
„ dnes jsme svědky mezníku : začala stavba na bulharské části plynovodu south stream , největším a nejdůležitějším projektu v evropě , “ uvedl prezident gazpromu alexei miller ve svém prohlášení .
tento projekt je klíčovým prvkem energetické bezpečnosti celého evropského kontinentu .
potrubí south stream by mělo přidat různorodost k trasám ruského exportu přes evropu .
smluvní spor mezi společností gazprom a jejími partnery na ukrajině , které přivádí většinu ruského plynu do evropy , přidává na rizikovosti konvenčních tras , říkají úředníci .
miller říká , že přímé spojení do bulharska , člena evropské unie , znamená , že geopolitická rizika spojená s tranzitními zeměmi jsou „ provždy “ odstraněna .
jakmile celý projekt zahájí v roce 2015 svůj provoz , bulharští spotřebitelé dostanou plyn z plynovodu south stream za zlevněnou cenu .
společnost gazprom říká , že stavba má v dalších zemích ve směru toku začít koncem tohoto roku .
plynovod je navržen na roční kapacitu 2,2 bilionu krychlových stop zemního plynu .
hizballáh vyslal do sýrii tisíce bojovníků .
čeká je rozhodující bitva .
libanonské hnutí hizballáh rozmístilo 15 000 svých bojovníků severně od damašku v přípravě na rozhodující bitvu o hornatou oblast kalamún .
podle stále se upřesňujících zpráv izrael při středečních náletech na dvě místa v západní sýrii zničil rakety určené právě hizballáhu .
tato libanonská šíitská organizace bojuje v sýrii na straně tamní armády .
jejím programem je také boj proti izraeli , který se do syrského konfliktu nevměšuje , ale jasně řekl , že zabrání přesunu výzbroje k rukám hizballáhu do libanonu .
zprávy o středečních izraelských náletech na sklady zbraní v západní sýrii se teprve upřesňují .
izrael útok nekomentoval , ale potvrdily ho americké zdroje .
dle syrské webové stránky dampress.com zasáhly rakety vypálené z oblasti středozemního moře syrskou raketovou základnu snúbar džabla jižně od latákíje .
zpravodajská stanice al-arabíja tvrdí , že zasaženy byly dva sklady , v nichž byly rakety připraveny k převozu do libanonu .
dle jejích zdrojů šlo o rakety ruské výroby sa-8 .
izrael zprávu odmítl komentovat , ale vojenský analytik ron ben jišaj řekl , že sýrie se nepřetržitě snaží zásobovat hizballáh raketami a syrské letectvo učí členy ozbrojené sekce hizballáhu s raketami zacházet .
sa-8 jsou zastaralé rakety , které má syrská armáda od 80. let .
jsou umístěny na pohyblivém podvozku .
ačkoli jsou poměrně primitivní , díky mobilitě a malým rozměrům je možné je snadno ukrýt .
jsou vybaveny radarem , který se ale po vypálení střely vypne , takže je těžké je zaměřit .
latákíja leží v západní sýrii , v oblasti obývané vládnoucími alávity .
jde o dobře střeženou oblast a hizballáh se v minulosti podílel právě na bojích v západní sýrii .
tvrdí , že pomáhá chránit syrskou šíitskou komunitu , k níž alávité patří .
teď je údajně 15 000 jeho bojovníků připraveno pomoci dobýt armádě zpět kalamún .
spolu s hizballáhem tam posiluje své jednotky také syrská armáda .
kalamún leží mezi damaškem a třetím největším městem země homsem .
bitva má být dle zdroje al-arabíji odvetou za nedávný útok opozice na velitelství syrské šíitské brigády abú fadla abbáse v šíitské části damašku .
hizballáh pomohl letos syrské armádě vybojovat zpět město kusajr u libanonské hranice .
mnoho povstalců z kusajru odešlo právě do kalamúnu .
ještě nedávno se zdálo , že většina občanů v české republice si přálo předčasné volby .
jako důvody byly uváděny korupce , rozhazování peněz za předražené nákupy a státní zakázky , zvyšování daní a v neposlední řadě vládní skandály .
podle výsledků voleb lze vyvodit , že většině občanů tento stav vyhovoval .
že jim to vlastně nevadilo a se stavem který tu byl ( rozkrádání a zadlužování tohoto státu ) , byly vlastně spokojeni .
jinak si nedovedu vysvětlit , že se 3 413 497 voličů nedostavilo k volbám , 596 357 voličů volilo top 09 384 174 voličů volilo ods celkem tedy 4 394 028 vlastně podpořilo původní vládní koalici , což představuje 52,16 % všech právoplatných voličů .
což je nadpoloviční většina .
když k výše uvedeným stranám přičtu 1 016 829 voličů čssd , potom se starým pořádkem ( protože všechny uvedené strany se podílely na &quot; rozkrádání &quot; a zadlužování tohoto státu ) , pak s tímto stavem vlastně souhlasilo 64,23 % právoplatných voličů .
tímto vlastně většina voličů dala najevo , že nejsou pro potrestání viníků rozkradení a předlužení tohoto státu .
nebo si snad myslíte že se členové čssd , kteří se na tom podíleli zasadí o patřičné zákony ?
je nám vůbec pomoci ?
federální letecká správa zmírňuje omezení týkající se používání elektronických výdobytků v letadlech – ačkoli textování přes mobilní telefon bude i nadále zakázáno .
vojenská letadla zaútočila na ruské rakety v přístavním městě lázikíja , oznámil jeden z činitelů .
je to očividně pokračování izraelské kampaně , která chce zabránit rozmnožování zbraní na blízkém východě .
federální odvolací soud zablokoval rozhodnutí soudkyně , že kontroverzní strategie policejního oddělení v ny diskriminuje menšiny .
téměř 100 afrických přistěhovalců , kteří doufali , že se dostanou do alžírska , zemřelo žízní poté , co se jejich dva nákladní vozy rozbily uprostřed sahary .
odborníci tvrdí , že smrt 14 dospělých a sedmi dětí v důsledku násilností není nic jiného než náhoda , a neznamená to , že by násilí v americe rostlo .
místo aby byli investoři z odstávky americké vlády nervózní , nadále se soustředí na to , co je pravděpodobně důležitější – federální rezervní systém .
žena z kalifornie plánuje bránit se předvolaní k soudu , které může být první svého druhu , a říká , že je navigace pomocí brýlí připojených k internetu jednodušší .
policie tvrdí , že má video , na kterém má být starosta rob ford , jak kouří crack ( kokain ) .
i nejbližší spojenci si nechávají věci pro sebe – a všemi možnými prostředky se snaží zjistit , co ta druhá strana tají .
vatikán chce vědět , jak katolické farnosti po celém světě přistupují k citlivým otázkám , jako je antikoncepce , rozvod a homosexuální páry .
královská komise se dozvěděla , že před žalobami proti jonathanu lordovi byli obviněni dva zaměstnanci křesťanského sdružení mladých mužů ( ymca )
královská komise pro sexuální zneužívání dětí se dozvěděla , že předtím , než byla vznesena obvinění proti dětskému vychovateli jonathanovi lordovi z města caringbah v roce 2011 , dva zaměstnanci křesťanského sdružení mladých mužů ( ymca ) v novém jižním walesu byli obžalování ze sexuálního zneužívání dětí .
ale před komisí zaznělo , že ve svém úvodním prohlášení pro komisi toto sdružení uvedlo , že ve své organizaci nikdy neřešili případ sexuálního zneužití dítěte .
výkonný ředitel phillip hare byl dotázán na případ , kdy byl jeden ze zaměstnanců sdružení ymca obviněn z přestupků týkajících se dětské pornografie , a na další , kdy tělocvikář v caringbah ze sdružení ymca byl v roce 1991 odsouzen za sexuální obtěžování dětí , které měl ve své péči .
pan hare řekl gaili furnessové , poradkyni komise , že věděl o prvním případu , ale o druhém ne .
připustil , že úvodní prohlášení sdružení ymca bylo také nepřesné , když uvádělo , že v organizaci ymca se prováděly externí audity , které ocenily tuto organizaci jako předního zastánce práv dětí .
důkazy předložené komisí hovoří o tom , že organizace ymca byla upozorněna na to , že v auditu ministerstva školství a společnosti ze srpna tohoto roku obdržela druhé nejnižší ze čtyř možných hodnocení .
pan hare , který začal se sdružením ymca pracovat , když mu bylo 21 , přiznal , že vedení od něho samotného směrem dolů selhalo , když pana lorda přijalo , aniž by se ujistilo , zda si je personál vědom povinnosti oznamovat porušení pravidel bezpečnosti dětí .
dříve tento rok byl lord odsouzen za sexuální obtěžovaní 12 chlapců , kterého se dopustil během dvou let , kdy pracoval ve sdružení ymca .
byl uvězněn na minimálně šest let .
pan hare ale odmítl tvrzení , že sdružení ymca mělo kulturní problém , který personálu bránil nahlásit narušení bezpečnosti dětí panem lordem .
členové personálu podali důkazy , že byli svědky takových porušení , včetně toho , že lord byl s dětmi o samotě , soukromě je hlídal , nechával je sedat u sebe na klíně , říkával jim , že je má rád , a nechával je hrát si s jeho mobilním telefonem .
danielle ockwellová , která byla lordovou podřízenou a požádala o výcvik bezpečnosti dětí , protože jí dělalo starosti jeho chování , dosvědčila , že jacqui barnat , vedoucí pro služby dětem ve sdružení ymca ve městě caringbah , který byl lordovým nadřízeným , byl „ velmi zastrašující a často bylo těžké s ním o něčem hovořit “ .
generální ředitel řekl , že nepřijímá důkazy personálu , že se cítili nesví , kdyby měli kontaktovat své nadřízené a skutky ohlásit .
místo toho řekl , že jejich přátelství s lordem zatemnilo jejich úsudek , a proto problém nenahlásili .
pan hare řekl , že radě sdružení ymca v novém jižním walesu sdělil svůj názor , že ponaučení z „ případu jonathana lorda “ pro organizaci spočívá v tom , že personál „ nepodal žádnou zprávu “ , a rada s ním v tom souhlasila .
pan hare řekl , že rozhodnutí nechat personál podepsat dohody o zachování mlčenlivosti krátce poté , co se objevila obvinění , učinil generální manažer pro služby dětem v organizaci ymca liamem whitleym .
řekl , že cílem bylo vyhnout se narušení důkazů , ale bylo „ přehnaně horlivé “ a špatně provedené .
odborník na sexuální zneužívání dětí profesor stephen smallbone z griffithovy univerzity řekl komisi , že ymca v novém jižním walesu nebyla v letech 2009 až 2011 organizací , která by pro děti byla bezpečná .
řekl , že se tam projevily vážné problémy v náboru , prověřování , zapracování , školení a vedení personálu .
slyšení bylo odročeno na 20. prosince .
tony blair řekl , že by využil šanci vrátit se na post ministerského předsedy , ale přiznal , že návrat je nepravděpodobný .
v nočním rozhovoru u příležitosti pátého výročí jeho odchodu z úřadu 59letý politik vyjádřil své názory na různé oblasti domácí politiky .
od června roku 2007 , kdy po deseti letech ve vedoucí pozici odstoupil , se pan blair většinou vyhýbal rozhovorům o britské politice a své komentáře omezoval na zahraniční záležitosti a svou roli vyslance bízkovýchodního mírového kvarteta .
když byl dotázán , zda by se vrátil na post ministerského předsedy , jeho odpověď londýnské noviny evening standard ocitovaly takto : „ ano , jistě , ale k tomu asi těžko dojde , že , takže ... “
zatímco se v cardiffu shromažďovaly zástupy expertů na předvádění koní , aby bojovaly o cenu kůň roku , všem bylo jasné , že soutěž nebude lehká .
nikdo ale nebyl připraven na tříletého fentona kirklanda .
ačkoli ještě nechodí do školy a teprve před pár měsíci udělal první krůčky , tento chlapeček a jeho zvířecí mazlíček , shetlandský poník toffee , hladce proklusali tři kola , aby nakonec získali hlavní cenu a nechali za sebou 30 vlekoucích se dospělých soupeřů .
tato nerozlučná dvojice – se stejnou výškou – byla na každoroční soutěži provozované jezdeckým centrem sunnybank ve vesnici rudry nedaleko cardiffu pochválena za vzhled , chování a styl .
postavil se proti pánům a dámám v elegantních kloboucích , naklopil svůj baret do veselého úhlu a nechal svého dvouletého toffeeho promenádovat po okruhu .
fenton byl porotci pochválen za své přirozené schopnosti koně ovládat , které daleko převyšují jeho věk .
a toffee získal nejvyšší známky za vhled a osobnost .
fenton toffeeho dostal v březnu ke svým třetím narozeninám a od té doby s tímto shetlandským poníkem denně cvičí .
jeho matka donna ( 30 ) řekla : „ fenton a toffee skvěle spolupracují . “
nedělali si velké naděje , ale nakonec odešli se zlatým pohárem a kyticí .
bylo to teprve podruhé , co s toffeem soutěžil , a když zvítězil , byli jsme nadšení .
všichni ho považovali za fenomenálního a úplně cizí lidé se s ním chtěli vyfotit .
chlapec z vesnice nantyglo nedaleko ebbw vale v jižním walesu jde ve stopách své tety sharon howellsové , která předvádí koně více než 10 let .
paní howellsová říká : „ byla tam vzrušující atmosféra a všichni povzbuzovali a tleskali . “
běžel po písku po celé délce arény a přestože působil tak drobně , podal skvělý výkon .
fenton je posedlý zvířaty – miluje koně , traktory a farmu a dostal na starosti dvě kuřata .
vzhledem k tomu , jak začal , bude zase brzy na soutěži kůň roku a jsem si jistá , že si povede dobře .
mluvčí každoroční soutěže předvádění koní řekl : „ fentonovi jsou pouze tři , ale už ví , jak ovládat poníka . “
tvoří spolu skvělý tým .
porotci vyzvedli fentona a toffeeho za jejich vynikající projev a za způsob , jakým se předvedli na soutěžním okruhu .
vždy sledují , jak dobrá je týmová práce mezi poníkem a tím , kdo ho vede – a fenton s toffeem byli na oválu nejlepší .
jsem si jistý , že fentonovi pomohlo i rozkošné oblečení , opravdu tam s ním zapadl .
příliš zvídavé noviny mají být prošetřeny
čínské noviny , které na titulní straně žádaly o propuštění reportéra obviněného z pomluvy , budou důkladně prošetřeny , řekl správce pro tisk .
noviny new express se sídlem v guangzhou učinily vzácnou veřejnou žádost o propuštění novináře chen yongzhoua .
pan chen však později v televizi přiznal , že bral úplatky , aby si vymyslel příběhy o společnosti částečně vlastněné státem .
správce řekl , že noviny new express nyní provedou „ plnou nápravu “ .
nařízení k „ nápravě “ přišlo ze státní správy pro tisk a publikace , rozhlas , film a televizi v provincii kuang-tung .
předběžné vyšetřování ukázalo , že v období od září 2012 do srpna 2013 noviny new express z yangchengské skupiny evening news vydaly několik nepravdivých zpráv o uvedené společnosti zoomlion .
„ redakční vedení novin new express bylo neuspořádané , “ řekl ve svém prohlášení správce .
řekl , že se musel rozhodnout „ uložit chen yongzhouovi administrativní trest v podobě zrušení novinářské licence “ .
dále také „ nařídil yangchengské skupině evening news , aby provedla celkovou nápravu listu new express , a doporučil , aby vyšetřili příslušné zodpovědné osoby v new express a okamžitě změnili vedení listu new express “ .
pan chen napsal pro new express několik článků , které se týkaly finančních nesrovnalostí ve společnosti se stavebním vybavením zvané zoomlion .
poté , co byl zadržen , jeho noviny vydaly na titulní straně dvě žádosti o jeho propuštění a tvrdily , že stojí za jeho novinářskou prací .
pan chen se pak ale objevil ve státní televizi a přiznal se k tomu , že za úplatu vydal nepravdivé příběhy .
„ v tomto případě jsem způsobil škodu společnosti zoomlion a také celému mediálnímu odvětví a jeho schopnosti získat si důvěru veřejnosti , “ řekl na státní zpravodajské stanici cctv .
udělal jsem to hlavně proto , že jsem bažil po penězích a slávě .
uvědomuji si , že jsem jednal špatně .
po omluvě pana chena vydal list new express na titulní straně omluvu , ve které uvedl , že selhal , když neprovedl dostatečnou kontrolu jeho zpráv .
v nedávné době učinilo v televizi přiznání několik ostře sledovaných podezřelých .
odborníci říkají , že přiznání jsou stále pravidelně vynucována , a to bez ohledu na změnu zákona z letošního roku , která zakazuje úřadům nutit kohokoliv k tomu , aby sám sebe obvinil .
byl nalezen tunel pro pašování drog mezi usa a mexikem s vlastní železnicí
podařilo se objevit jeden z nejdůmyslnějších tunelů pro pašování drog mezi usa a mexikem , doplněný o vlastní osvětlení , ventilaci a elektrickou železnici .
americké úřady popsaly tunel o rozměrech zhruba jeden krát jeden metr jako jednu z nejdůmyslnějších tajných chodeb , které kdy objevily .
tunel , který se klikatí do délky téměř šesti fotbalových hřišť , spojuje skladiště nedaleko tijuany v mexiku a v san diegu v usa .
tato oblast je plná neurčitých skladišť , kde tak lze snadno skrýt nákladní vozy předtím , než se naloží drogami .
úřady uvedly , že tunel byl uzavřen předtím , než v něm mohly být nepozorovaně dopraveny drogy .
spolu s objevením tunelu úřady také podle soudních záznamů zadržely osm a půl tun marihuany a asi 150 kilogramů kokainu .
tři muži , kteří podle úřadů pracovali jako řidiči , byly obžalováni z držení marihuany a kokainu s cílem je distribuovat .
v případě odsouzení čelí trestům odnětí svobody od 10 let až po doživotí .
ve městě nogales v arizoně pašeráci pronikají do rozsáhlých odvodňovacích kanálů .
tunel je osmou největší chodbou objevenou v san diegu od roku 2006 .
některé z největších tunelů byly objeveny v říjnu po sklizni marihuany v centrálním mexiku , která před drogové kartely staví problém , jak co nejrychleji svůj produkt dostat ke spotřebitelům .
v roce 2010 úřady našly chodbu v délce asi 650 metrů vybavenou kolejemi , které vedly z kuchyně jednoho domu v tijuaně do dvou skladišť v san diegu .
economia a centrum propojují management .
nabídnou například společnou inzerci
nový integrovaný newsroom společnosti economia v pražském karlíně .
společnost economia udělala další krok pro transformaci holdingu centrum do svého mediálního domu .
od pátku má economia i centrum společný top management .
&quot; sjednocení organizační struktury i personální unie jsou zásadní pro integraci obou vydavatelství do společného mediálního domu , &quot; komentuje provedené změny místopředseda představenstva economie a pověřený generální ředitel kamil čermák .
čermáka , který bude stát v čele jednotného managementu , doplní výkonný ředitel centrum holdings andreas demuth .
novým společným ředitelem obchodu byl jmenován pavel vopařil , kterému je podřízena i inzertní ředitelka obou společností zuzana tylčerová .
novým šéfem informačních technologií se stal štěpán burda .
společným ředitelem redakcí je vladimír piskáček , v jehož týmu je i ředitel pro transformaci jakub unger .
nově zřízenou funkcí ředitelky marketingu byla pověřena adéla pittsová .
samostatný útvar korporátní komunikace nově řídí věra lhotská .
společným finančním ředitelem je karel žalud , řízení lidských zdrojů pro obě vydavatelství vede petra slabá .
&quot; nová organizační struktura nám mimo jiné umožní přicházet na trh se společnou nabídkou inzertních produktů , lépe propojovat tvorbu obsahu všech vydávaných titulů a v neposlední řadě dále významně zefektivnit obchodní řízení společnosti , &quot; dodal čermák .
společnost economia , kterou vlastní finančník zdeněk bakala , uzavřela smlouvu o koupi společnosti centrum holdings a jejích českých dceřiných společností na konci letošního dubna .
portfolio centrum holdings tvoří servery aktuálně.cz , žena.cz , webové portály , rozsáhlá e-mailová základna pod značkami centrum.cz a atlas.cz a smb agentura najisto či portfolio dalších bezmála dvou desítek menších webů .
společnost economia je vydavatelem hospodářských novin , zpravodajského serveru ihned.cz , týdeníků respekt a ekonom a množství tištěných i internetových b2b titulů .
mezi českými vydavateli je dlouhodobě nejúspěšnější v prodeji digitálních verzí svých hlavních titulů .
letos v červnu se vydavatelství přestěhovalo do nově vybudovaných moderních prostor v pražském karlíně .
cme zacílí na televizní byznys .
propustí téměř čtvrtinu lidí .
mediální skupina cme bude propouštět .
do konce roku chce zeštíhlet o tisíc lidí .
osekat hodlá všechny vedlejší činnosti a zaměřit se chce jen na svůj hlavní byznys , televizní vysílání .
skupina , která vlastní v česku televizi nova a působí také na slovensku , v bulharsku , rumunsku , chorvatsku a slovinsku , zaměstnává celkem zhruba 4 500 lidí .
o práci tak přijde téměř čtvrtina lidí .
mediální skupina provozuje televize v čr , na slovensku , v bulharsku , rumunsku , chorvatsku a slovinsku .
součástí cme je společnost cet 21 , která drží licence pro vysílání televizních stanic nova , nova cinema , nova sport , fanda , smíchov , telka a české verze hudební stanice mtv .
jak moc se úspory dotknou česka , kde skupina zaměstnává zhruba 650 lidí , a co to bude znamenat pro tuzemskou televizní jedničku tv nova , zatím jasné není .
&quot; to je předčasné a my to opravdu komentovat nemůžeme , &quot; uvedl ředitel komunikace novy josef koukolíček .
podle informací mf dnes se výrazné propouštění česku určitě nevyhne , ale zdaleka největší dopad by to mělo mít na personální stavy poboček cme v rumunsku a dalších zemích .
oba noví šéfové novy christoph mainusch a michael del nin , kteří nastoupili po dlouholetém řediteli adrianovi sarbuovi , během středečního konferenčního hovoru s analytiky hovořili o tom , že chtějí omezit všechny aktivity , které bezprostředně nesouvisí s televizním byznysem .
je tedy dosti pravděpodobné , že výrazně omezí zejména náklady na výrobu vlastních pořadů , filmařskou a produkční činnost .
v průmyslovém areálu čkd v praze shořela v noci chladicí věž
v průmyslovém areálu čkd v praze hořel velkokapacitní zásobník , podle hasičů zřejmě chladicí věž .
&quot; k požáru vyjížděli hasiči už ve čtvrtek před jedenáctou hodinou večer , dnes ráno ještě oheň dohašovali , &quot; oznámila mluvčí pražských hasičů pavlína adamcová .
množství škodlivin ve vzduchu v okolí podle měření nepřesáhlo povolené limity .
výše škod a příčiny požáru jsou zatím neznámé .
do areálu v kolbenově ulici postupně dorazilo zhruba pět desítek hasičů .
&quot; jedná se o požár velkokapacitního zásobníku , pravděpodobně chladicí věže , &quot; sdělila adamcová .
&quot; v areálu se nenachází funkční hydrantová síť , hasíme tedy pomocí dopravního vedení od cisteren , &quot; doplnila .
podle serveru tn.cz zkomplikovala hašení špatně fungující síť hydrantů , hasiči proto museli vodu dopravit odjinud .
velitel zásahu hasičů vyhlásil druhý stupeň požárního poplachu .
stupně jsou celkem čtyři , při nejvážnějších situacích se vyhlašuje čtvrtý .
na místo vyrazili i chemici , aby ověřili míru nebezpečných látek , které se mohly při požáru dostat do vzduchu .
&quot; nenaměřili ale v ovzduší množství škodlivin , které by přesahovalo hygienické normy , &quot; uvedla mluvčí hasičů .
britská policie doručila assangeovi oznámení o vydání
britská policie dnes doručila oznámení o vydání zakladateli wikileaks julianu assangeovi , který našel útočiště na ekvádorském velvyslanectví v londýně , kde požádal o azyl .
scotland yard prohlásil , že 40letému australanovi doručil „ oznámení o vydání “ s tím , že ho žádá , aby se dostavil na policejní stanici a že pokud tak neučiní , může mu hrozit zatčení .
assange v rámci britského zákona vyčerpal své možnosti , když nejvyšší soud tento měsíc zrušil jeho odvolání proti vydání , a čelí tak vydání do švédska kvůli obviněním ze sexuálních zločinů .
protože se obával , že by ho stockholm vydal do usa , vyhledal 19. června útočiště na ekvádorském velvyslanectví v londýně , kde tuto jihoamerickou zemi požádal o azyl .
scotland yard „ doručil oznámení o vydání 40letému muži , kterým žádá , aby se dostavil na policejní stanici v den a hodinu , které mu byly určeny “ , řekl mluvčí .
assange nadále porušuje podmínky kauce .
velvyslanectví odmítlo doručení oznámení o vydání komentovat .
assange se bojí , že bude ze švédska vydán do spojených států , kde může čelit obvinění ze špionáže , protože na webové stránce wikileaks zveřejnil 250 000 amerických diplomatických dokumentů .
řidič dostal pokutu 1 000 liber za to , že jel přes 200 km / h s horkým nápojem mezi nohama
motorista dostal pokutu 1 000 liber za to , že jel až 210 km / h s horkým nápojem umístěným mezi nohama .
andrew howie ( 35 ) z města tiptree v essexu byl 27. května spatřen ve svém mercedesu benz na silnici a120 v braintree .
když ho policie zastavila , zjistila , že má mezi stehny kelímek s nápojem .
u policejního soudu v colchesteru howie se přiznal k obvinění , že řídil neopatrně a nepozorně .
na jeho účet přibylo sedm bodů , následkem čehož obdržel šestiměsíční zákaz řízení .
howiemu také bylo nařízeno proplatit náklady ve výši 90 liber a přirážku pro obviněného 100 liber .
v důsledku daně na vlastníky zahraničních nemovitostí praská londýnská bublina
ministerstvo financí předběžně vyčíslilo daň z výnosu finančního majetku , ale čeká na konečné rozhodnutí pana osborna , který v rozpočtu z roku 2012 představil poplatek 7 % za převod nemovitostí pro budovy v ceně nad 2 miliony liber a roční poplatky pro kupce , kteří vlastní nemovitosti v rámci společnosti , nikoli jako jednotlivci .
výnos z poplatku za převod nemovitosti v bytovém fondu v okresech westminster a kensington a chelsea , který v daňovém roce 2012 / 13 dosáhl 708 milionů liber , již překračuje celkový součet pro severní irsko , wales , skotsko , severovýchod , severozápad a yorkshire a humber dohromady .
pan cook řekl : „ vzhledem k nárůstu v převodu nemovitosti u domovů vysoké hodnoty a představení související legislativy , která má zabránit vyhýbání se daním , je velmi obtížné argumentovat , že majetek vysoké hodnoty je málo zdaněný bez ohledu na efekt zastaralého systému daně z hlavy . “
dodal , že „ tento krok mohl u některých zahraničních investorů způsobit , že se nemovitosti v londýně zdráhají kupovat , případně že se stávající vlastníci zdráhají prodávat “ .
přední nemovitosti – horních 5 % až 10 % bytového trhu podle ceny – v bohatém pásu , který sahá od fulhamu po wimbledon , zaznamenaly za minulý rok nárůst o rekordních 11,8 % .
ceny ve středu londýna nadále vykazují rok od roku stálý růst 5,6 % , ale byly zastíněny vzkvétajícím „ domácím trhem “ , na kterém podle průzkumu realitní kanceláře savills zažívaly jihozápad , sever ( 7,4 % ) a východ ( 6,5 % ) přírůstek .
vědci více osvětlili , jak pohyby ocasu souvisí s náladou psa
dřívější výzkumy ukázaly , že radostní psi vrtí ocasem více doprava ( z pohledu psa ) , zatímco nervózní psi mávají ocasem převážně doleva .
nyní však vědci říkají , že ostatní psi dokáží tyto jemné rozdíly v pohybu ocasu zaznamenat a reagovat na ně .
profesor georgio vallortigara , neurobiolog z univerzity v trentu řekl : „ u lidí je dobře známo , že levá a pravá strana mozku mají různou vazbu na podněty , které vzbuzují pozitivní nebo negativní emoce . “
to samé jsme se snažili vypozorovat u jiných druhů .
dodal , že stejně jako je tomu u lidí , i u psů je pravá strana mozku zodpovědná za levoruké pohyby a naopak a že tyto dvě hemisféry hrají odlišnou úlohu v emocích .
ve snaze získat další informace o tom , jak psi reagují na nesouměrné vrtění ocasu jiných psů , výzkumníci monitorovali zvířata , která sledovala filmy o jiných psech .
měřili tepovou frekvenci těchto zvířat a analyzovali jejich chování .
zřejmě nebude dlouho trvat , než pochopíme , proč jde jejich ocas někdy na jednu stranu , a jindy na druhou .
profesor vallortigara řekl : „ promítli jsme psům filmy o psech – ať už v přirozené verzi , nebo v podobě siluety – , abychom se zbavili jakýchkoli matoucích podnětů , a dokázali jsme rovněž upravit pohyb ocasu a znázornit jej více vpravo nebo vlevo . “
když zvířata viděla jinak nevýrazného psa hýbat ocasem doprava ( z pohledu psa vrtějícího ocasem ) , zůstala naprosto v klidu .
když ale zaznamenala natáčení ocasu převážně doleva ( znovu z pohledu psa vrtějícího ocasem ) , jejich tepová frekvence se zvýšila a zvířata působila nejistě .
profesor vallortigara řekl , že si nemyslí , že by psi prostřednictvím těchto pohybů navzájem vědomě komunikovali .
spíše se domnívá , že se psi ze zkušenosti naučili , na které pohyby si musí a na které nemusí dávat pozor .
řekl : „ pokud se několikrát setkáte se psy a pohyb jejich ocasu jedním směrem je opakovaně spojen se spíše přátelským chováním a pohyb doprava plodí méně přátelské chování , budete reagovat na základě této zkušenosti . “
výzkumníci říkají , že zjištění mohou majitelům psů , veterinářům a cvičitelům pomoct lépe porozumět emocím jejich zvířat .
odborník na chování psů john bradshaw , vysokoškolský učitel zvěrolékařství na univerzitě v bristolu , řekl , že to nebyla první studie , která zkoumala , zda je levá a pravá strana pro psy důležitá .
minulý rok tým z univerzity lincoln zjistil , že psi odvracejí svou hlavu nalevo , když pozorují agresivního psa , a napravo , když se dívají na veselého psa .
a v jiném odborném pojednání od univerzity victoria v kanadě řekl : „ se psím robotem se psi s větší pravděpodobností seznamovali tehdy , když vrtěl ocasem doleva než doprava , kdy se spíše stávali nejistými – přesně naopak oproti italské studii . “
rozdíl může být podle něj dán tím , že si psi v těchto různých studiích zvířata ve filmech nebo psí roboty nevykládali zcela jako psy .
vysvětlil , že by mohla pomoct studie o tom , jak psi reagují na skutečné psy .
„ přestože v případě mnoha různých savců existují pádné doklady , že obě strany mozku jsou používány pro různé účely , mnoho podrobností je stále ještě třeba objasnit – a psi nejsou výjimkou , “ uvedl .
ale vzhledem k tomu , jak jednoduché je zaznamenat jejich chování , zřejmě nebude dlouho trvat , než pochopíme , proč jde jejich ocas někdy na jednu stranu a jindy na druhou .
arctic monkeys kvůli nemoci alexe turnera posunuli koncert v glasgow
rocková skupina arctic monkeys posunula koncert v glasgow poté , co byl hlavnímu zpěvákovi diagnostikován zánět hrtanu .
sheffieldská skupina měla vystoupit v pátek v městském komplexu hydro .
nemoc hlavního zpěváka alexa turnera ji ale přinutila vystoupení přesunout .
oznámení skupiny přišlo poté , co byla podobně přinucena odložit čtvrteční vystoupení v lg aréně v birminghamu .
v prohlášení na svých oficiálních webových stránkách skupina arctic monkeys říká : „ po rozhodnutí odložit dnešní vystoupení v lg aréně v birminghamu a na základě lékařského doporučení musí skupina arctic monkeys odložit i vystoupení v komplexu hydro v glasgow plánované na pátek 1. listopadu . “
„ alexi turnerovi byl diagnostikován zánět hrtanu a bohužel nebude moci vystoupit . “
vystoupení v lg aréně v birminghamu se tak uskuteční 20. listopadu a vystoupení v komplexu hydro v glasgow 21. listopadu .
všechny lístky na tato vystoupení zůstávají v platnosti .
rádi bychom se všem , kdo si zakoupili lístky , omluvili za nepříjemnosti , které jim to způsobilo .
pokud potřebujete další informace , kontaktujte prosím zákaznické služby u pokladny , kde jste si své lístky koupili .
papež františek jmenuje v únoru první kardinály
vatikán ve čtvrtek oznámil , že papež františek 22. února poprvé jmenuje nové kardinály katolické církve .
kardinálové mají v duchovenstvu katolické církve nejvyšší pozici hned po papeži a jsou těmi , kdo papeže volí , takže františek ustanoví svou první skupinu mužů , kteří nakonec pomohou vybrat jeho nástupce .
nyní je 201 kardinálů .
jakmile však kardinál dosáhne věku 80 let , již se nemůže účastnit volby papeže – skupina se tak zmenšuje na 120 volících kardinálů .
v prohlášení oznamujícím tuto zprávu páter federico lombardi , mluvčí vatikánu , řekl , že před slavnostním povýšením nových kardinálů se bude konat shromáždění současných kardinálů známé jako konzistorium .
„ papež františek se rozhodl sdělit své rozhodnutí svolat únorové konzistorium předem , aby se usnadnilo plánování ostatních shromáždění , která vyžadují účast kardinálů z různých částí světa , “ řekl lombardi .
jack valero z listu catholic voices řekl , že počet volících kardinálů do února pravděpodobně klesne .
řekl , že papež obvykle jmenuje tolik kardinálů , kolik je třeba , aby se počet volitelů zvýšil znovu na 120 , a tolik kardinálů přesahujících věk 80 let , kolik chce .
konzistorium příští rok bude významné , protože bude prvním poté , co byl františek v březnu tohoto roku zvolen , řekl valero .
v tuto chvíli se projevuje určitá orientace na evropu evropě a především itálii .
„ bude zajímavé sledovat , zda nový papež nominuje kardinály ze zbytku světa , aby obnovil rovnováhu , “ řekl .
čtyřicet procent římských katolíků je v jižní americe , ale mají jen nepatrný počet kardinálů .
bude se také jednat o první volbu kardinálů od té doby , co františek ustanovil radu kardinálů , skupinu osmi kardinálů z celého světa , kterým dal za úkol najít způsoby , jak reformovat církev .
v minulosti papež rozhodoval vše sám za sebe .
„ nyní františek vybral těchto osm kardinálů , aby mu pomohli , “ řekl valero .
řekl , že je „ docela možné “ , že tyto kardinály papež požádá o radu .
v této situaci jsme ale předtím nebyli – je to naprostá novinka .
valero řekl , že papežové tradičně povyšovali na pozici kardinálů biskupy z velkých míst , ale františek je „ plný překvapení – takže nevíme , koho jmenuje “ .
společnost gm stahuje některé nové lehké nákladní automobily v usa kvůli opravě opěradel sedadel
podle pátečního oznámení od amerického orgánu pro automobilovou bezpečnost společnost general motors stahuje téměř 19 000 svých nových ( 2014 ) lehkých nákladních automobilů chevrolet silverado a gmc sierra , aby opravila závadu s manuálním naklápěním opěradla .
u některých z těchto vozidel může mít mechanismus naklápění předních sedadel závadu .
v důsledku toho , opěradla sedadel nejsou v souladu s federálními normami automobilové bezpečnosti pro opěrky hlavy .
oznámení umístěné na webových stránkách státní správy bezpečnosti dopravy na silnici ( nhtsa ) říká , že „ pokud vůz zezadu dostane náraz , opěrka hlavy nemusí cestující správně ochránit , což zvyšuje riziko úrazu “ .
stažené modely byly vyrobené mezi 1. srpnem a 10. zářím .
společnost gm uvedla dodávku na trh v červnu a pro tuto přední americkou automobilku jde o nejdůležitější uvedení vozidla na trh od restrukturalizace po bankrotu v roce 2009 .
společnost gm informovala majitele dodávky o závadě v první polovině října .
nhtsa nemohla přezkoumat oznámení majitelům kvůli 16denní nefunkčnosti vlády , která v říjnu oslabila růst prodeje automobilů .
prodeje dodávek silverado a sierra , které byly pro modely roku 2014 přepracovány , stouply během prvních 10 měsíců tohoto roku na asi 20 procent , prohlásila v pátek společnost gm .
v říjnu společnost gm prodala ze svých dodávek 42 660 modelů silverado a 16 503 modelů sierra .
akcie na newyorské burze vzrostly v pátek odpoledne o 1,4 procenta na 37,47 usd .
zoufalý výkřik obamova voliče
obamu jsem volil dvakrát – sdílel jsem naději na možnou změnu
říká , že obamovy upřímné snahy zhatily obstrukce republikánské strany
obstrukční politika nemůže omluvit strasti webových stránek obamovy zdravotní péče či útoky bezpilotních letadel
memoáry obamovy kampaně z roku 2008 jsou smutnou připomínkou toho , co se mohlo stát
nathaniel p . morris druhým rokem studuje medicínu na harvardu .
v těchto dnech čtu hrozně smutnou knížku .
o této knize jsem si myslel , že mě během chmurných dní mého druhého ročníku na lékařské fakultě povzbudí a obnoví ve mně špetku naděje .
jmenuje se „ the audacity to win “ ( troufalost k vítězství ) a jedná se o vzpomínky na prezidentskou kampaň baracka obamy v roce 2008 .
když večer dokončím posudky pacientů a jdu do postele , kniha mě vrací do doby , kdy politika inspirovala miliony lidí a projevy vám braly dech .
volby skončily drtivou převahou a televizní zpravodajství nás nutilo se zamýšlet nad historickou hodnotou tohoto okamžiku .
mí spolužáci plakali radostí a moji rodiče si schovávali noviny , které sehnali .
do bílého domu zamířil mladý tým vizionářů a národ byl připraven na změnu .
během uvedení do úřadu v roce 2008 měl obama podporu 82 procent .
a tady knihu zavírám .
přejít do současnosti je drsným probuzením , jako probrat se ze snu .
je těžké připomínat si tyhle optimistické dny – zdají se být vzdálenými vzpomínkami , smutnou připomínkou promarněných příležitostí .
v letech poté , co jsem vhodil svůj první volební lístek , skutečně došlo ke změnám .
nebylo to rozhodně nic z toho , co jsem si představoval .
uznávám , že obama dosáhl řady velký a rozmanitých úspěchů – od zákona o dostupné péči přes odsun našich vojsk z iráku a konec politiky „ na nic se neptat , nic neříkat “ po usmrcení usámy bin ládina .
navíc jsem přesvědčen , že stranické obstrukce zvrátily tolik snah posunout náš národ kupředu : mezi jinými je to imigrační reforma , možnost veřejnosti zvolit si zdravotní péči a uzavření základny v guantánámu .
ale po mnoha situacích , kdy jsem před kolegy a kamarády bránil obamovu administrativu , jsem , pokud jde o vysvětlení , která mohou poskytnout , dospěl na absolutní limit .
ocitl jsem se v místě politické beznaděje .
obstrukce republikánů nemohou vysvětlit souhlas s odposloucháváním zahraničních vůdců ani s nálety bezpilotních letounů , které zabíjejí nevinné děti v zámoří .
nelze jimi vysvětlit to , že národní bezpečnostní agentura sbírá data o soukromém životě američanů , ani to , že pronásleduje ty , kdo nesprávné jednání vlády odhalí .
nelze je činit zodpovědné za popravu anwara al-awlakího , amerického občana , bez řádného soudu ani za omezování veřejných příspěvků a výdajů během prezidentských kampaní .
nelze jimi ospravedlnit zjištění zprávy , která říká , že snahy bílého domu umlčet média jsou „ nejagresivnější ... od nixonovy administrativy “ .
a nejnověji ani nemohou omluvit neschopnost vytvořit více než 3 roky po podepsání zákona o dostupné péči jednoduché webové stránky .
nevím , zda se něco takového dalo čekat .
zda jsem měl v 18 letech tušit , že vládní moc může být v rozporu s politickými kampaněmi , které jí předcházely .
volená funkce očividně nemá předvídatelný průběh a naše veřejné rozhovory bude utvářet opoziční politická strana a nahodilé události , jako je masakr v newtonu .
avšak všechny příklady , které jsem uvedl výše , se do velké míry zdají být výsledkem vlastního rozhodnutí administrativy .
a to mě trápí nejvíce .
obamu jsem volil znovu v roce 2012 , ale ne proto , že jsem byl nadšený z jeho kandidatury .
mitt romney představoval zmatečnou a nevybroušenou alternativu a zdálo se , že nedokáže upevnit svoji politiku ani pozici .
měl jsem pocit , že druhé funkční období pro obamu , osvobozené od tlaku příštích voleb , naplní naděje , o kterých jsme kdysi slyšeli .
přesto je návrat k roku 2008 – s tím , jak podpora obamy tento týden klesla pod 45 % – prostřednictvím této knihy čím dál těžší .
nutí mě vzpomínat na tu řadu slibů , které se vytratily .
tento týden jsem v knize četl kapitolu o tom , jak obama při primárkách v pensylvánii utrpěl drtivou porážku s clintonovou .
na dodatečné schůzce během kampaně řekl svému štábu , že se musí dostat zpátky do tempa a zůstat věrní svému poslání .
„ chci zpátky naše kouzlo , “ řekl .
nesmíme zapomínat na to , kdo jsme .
uplynulo pět let , pane prezidente , a naprosto s vámi souhlasím .
myšlenky vyjádřené v tomto komentáři jsou výlučně názory nathaniela morrise .
clive palmer tvrdí , že předseda vlády tony abbott je ve střetu zájmů kvůli programu rodičovské dovolené
miliardář a poslanec clive palmer říká , že předseda vlády tony abbott je ve střetu zájmů kvůli programu rodičovské dovolené , protože jeho dcery mohou otěhotnět a těžit z toho .
báňský magnát , který vede spor kvůli úhradě daňového výměru z uhlí v hodnotě 6 milionů dolarů , pronesl toto tvrzení , když se snažil smést ze stolu otázku , zda je ve střetu zájmů .
palmerova sjednocená strana může v senátu ovládat až čtyři hlasy , které sehrát zásadní roli při rozhodování , zda se mají vybírat daně z uhlí a těžební činnosti .
ale pan palmer tvrdil , že ve střetu zájmů mohou být pouze ministři , a dodal , že abbottovy dcery byly v pozici , kdy mohly mít z dané politiky osobní užitek .
„ dostal se do velkého střetu zájmů , pokud jde o placenou rodičovskou dovolenou , protože pokud by kterákoliv z jeho dcer otěhotněla , měl by přímý zájem o to , zda by dostala rodičovskou dovolenou , “ řekl pan palmer .
dva měsíce po volbách volební komise po přepočtu hlasů oficiálně prohlásila pana palmera za vítěze v boji o křeslo za okrsek fairfax v oblasti sunshine coast díky zisku 53 hlasů .
pan palmer vyzval k přezkoumání volebních výsledků , aby se proces urychlil .
dcery tonyho abbotta frances a bridget .
mělo by se o těchto volbách rozhodnout dva měsíce po uzavření volebních místností ?
„ musíme mít lepší systém , “ řekl .
proč nemůžeme mít systém , kde můžete přijít , naťukat podrobnosti do počítače , okamžitě hlasovat a mít výsledky v půl sedmé večer ?
pan palmer také kritizoval použití tužek k označení hlasovacích lístků .
jde o to , že výsledky lze vygumovat , pokud se někomu nelíbí ?
v těchto dnech a v této době se zdá používání tužek neuvěřitelné .
volební komise studovala možnosti elektronického hlasování a nedávno vydala spolu s novým zélandem společný příspěvek do diskuse .
pan palmer ( 59 ) řekl , že jeho politický program se vztahuje i na letiště v oblasti sunshine coast a že by svou novou práci bral „ velmi vážně “ .
veřejný úřad je služba veřejnosti .
„ neusilujeme o žádnou odměnu kromě té , že můžeme sloužit společnosti v této kritické době , “ řekl .
myjete si ruce ?
vědci přišli na to , že mytí rukou vám změní i náladu .
experimentu se zúčastnilo 98 osob , rozdělených do tří skupin .
první dvě měly za úkol vyřešit neřešitelnou úlohu .
samozřejmě , obě neuspěly .
ale skupina , která si po nezdaru umyla ruce , působila mnohem optimističtějším dojmem než ta , kde si její účastníci ruce neumyli .
rovněž skupina &quot; s umytýma rukama &quot; si v dalším testu vedla lépe než ta druhá .
přesto docílili ti , kteří si umyli ruce , v dalších testech horší výsledky než ti , kteří je umyté neměli .
výsledky &quot; umytých &quot; byly na úrovni třetí skupiny , jejíž účastníci žádný předcházející neúspěch nezaznamenali .
výsledky testu ukazují podle psychologů na to , že tělesná čistota odstraňuje skutečně negativní pocity po neúspěchu .
zároveň ale klesá motivace , testovaní se musejí v dalších zkouškách mnohem více soustředit .
kdybychom přenesli výsledky výzkumu na čechy , asi nejoptimističtější bychom byli po návratu z wc .
po použití wc si totiž nemyje ruce pouze jedno procento češek a čechů , ale po cestě městskou dopravou už je to pětina .
na hygieně lpí většinou také po práci na zahradě či v dílně , kdy si ruce umyje 85 procent lidí .
pohlazení domácího mazlíčka motivuje k mytí rukou 78,7 procenta lidí .
nedávný průzkum odhalil , že existuje rozdíl ve vnímání čechů a slováků , nakolik je nutné umýt si ruce po podání ruky cizímu člověku .
v této situaci si ruce umyje 28,8 procenta čechů a 40,3 procenta slováků .
průzkum ukázal , že si oba národy myjí ruce zhruba desetkrát denně .
&quot; ačkoliv by to bylo na místě , obávám se , že je realita jiná a lidé se snaží dělat se tak trochu lepší , &quot; komentovala výsledky průzkumu kožní lékařka klaudie komárková .
rbs suspenduje dva obchodníky s cizí měnou
podle dvou osob obeznámených se situací suspenduje skotská královská banka ( rbs ) dva obchodníky ve své divizi s cizí měnou , což je další náznak toho , že globální vyšetřování kontrolními orgány týkající se podezřelých machinací s měnovým trhem je stále častější .
některé z největších světových bank , včetně ubs , barclays , deutsche bank a rbs , potvrdily , že spolupracují s kompetentními orgány na vyšetřováních největšího finančního trhu na světě , kde každý den mění majitele 5,3 bilionů usd .
zmínění dva obchodníci by byli prvními zaměstnanci rbs suspendovanými v rámci rozšiřujícího se vyšetřování , které je odezvou na skandál s manipulací sazby libor ( londýnská mezibankovní úroková míra ) .
banka odmítla suspendování komentovat , ale potvrdila , že tento měsíc obdržela od orgánů žádost o informace .
„ naše neutuchající pátrání v této věci pokračuje a my plně spolupracujeme s fca a našimi dalšími orgány , “ prohlásila banka před dvěma týdny .
minulý měsíc lidé , kteří mají blízko k této události , uvedli , že rbs předala britskému orgánu finančního chování záznamy e-mailů a rychlých zpráv zaslaných z účtů a na účty bývalého obchodníka .
tento obchodník , richard usher , opustil rbs v roce 2010 a předpokládá se , že byl uvolněn ze své současné pozice evropského předsedy obchodování s cizí měnou u jpmorgan .
rohan ramchandani , evropský předseda obchodování za hotové peníze v citi , nastoupil dovolenou tento týden , zatímco matt gardiner , bývalý vedoucí pro obchod s měnami v barclays a ubs , byl tento týden suspendován společností standard chartered .
ani jeden z těchto obchodníků nebyl obviněn ze žádného přestupku .
do skupiny pana ushera pro zasílání rychlých zpráv patřili bankéři z barclays a citigroup , řekli lidé zasvěcení do této události .
banka ubs se tento týden vyjádřila , že poté , co švýcarský kontrolní orgán finma oznámil , že vyšetřoval podezřelé machinace na trhu s cizí měnou v několika švýcarských bankách , učinila kroky proti některým ze svých zaměstnanců .
celosvětově minimálně šest úřadů – evropská komise , finma , švýcarský antimonopolní úřad weko , fca , ministerstvo spravedlnosti v usa a měnový úřad v hong kongu – zkoumá tvrzení , že se tito bankéři spolčili , aby hýbali s měnovým trhem .
lidé obeznámení se situací řekli , že hsbc , citigroup , jpmorgan a credit suisse navíc spustily interní vyšetřování nebo od příslušných orgánů obdržely žádost o informace .
banky se pročesávají roky starými rychlými zprávami a e-maily , aby našly případy nějakých přestupků .
zprávy o vyšetřováních poplašily obchodníky v oblasti , která byla jedním z největších motorů pro vytváření zisku v uzávěrkách investičních bank v minulých letech , ale která byla narušena tím , že malá nestálost měn omezila příležitosti pro spekulanty .
někteří bankéři se snažili závažnost situace snížit , když tvrdili , že s rozsáhlým a vysoce likvidním trhem s cizí měnou je v podstatě nemožné manipulovat , ale vysoce postavení obchodníci říkají , že to nutně nemusí být pravda .
vysoce postavený obchodník řekl , že navzdory značnému objemu denního obchodování s cizí měnou rozkouskování likvidity mezi různými obchodními platformami a bankami zvyšující použití jejich vlastních interních platforem znamená , že „ můžete začít mít vliv na trh při poměrně nízkých cenách . “
zpráva přišla v tentýž den , kdy společnost credit suisse oznámila , že tento týden propustila ze svého oddělení pro obchodování s akciemi obchodníka , který koncem minulého roku způsobil ztrátu téměř 6 milionů usd .
banka okamžitě upozornila příslušné úřady a spolupracuje s jejich kontrolními orgány .
„ jsme přesvědčeni , že tento obchodník jednal sám a že tento problém byl vyřešen , “ uvedla společnost credit suisse .
počet nakažených hiv v praze přesáhl tisícovku
lékaři v praze evidovali už víc než tisícovku lidí s virem hiv .
od počátku sledování v roce 1986 do konce letošního třetího čtvrtletí testy potvrdily nákazu u celkem 1005 osob z metropole .
vyplývá to ze statistik národní referenční laboratoře pro aids státního zdravotního ústavu .
podle ní bylo v celé čr dosud 2 063 nakažených .
u 396 nemoc selhání imunity už propukla .
zemřelo 198 osob .
počet nakažených v česku v posledním desetiletí každoročně narůstá .
v roce 2002 testy potvrdily infekci u 50 lidí , o pět let později jich bylo už 121 .
v roce 2009 vyšetření odhalilo 156 nových nákaz a v roce 2010 pak 180 .
předloni počet poklesl na 153 , loni byl ale naopak rekordní .
podle laboratoře jich bylo 212 .
&quot; o tom , že celkový počet nově diagnostikovaných případů letos přesáhne 200 , již podle mne není pochyb , &quot; míní expert na problematiku aids miroslav hlavatý , který léta vedl pražský dům světla pro pacienty .
od října do konce roku v roce 2011 testy odhalily nákazu u 39 lidí a minulý rok u 47 , uvedl hlavatý .
v září lékaři evidovali 21 nových pacientů a tři pacientky .
od počátku sledování do konce září testy hiv potvrdily u 1710 mužů a 353 žen .
nemoc aids propukla u 161 mužů a 37 žen .
nejvíc infikovaných bylo v praze .
kdo chce skutečně poznat nějaké město , měl by se vypravit na hřbitov .
jeho návštěva odhalí více než procházka načančaným centrem s památkami , kostely a galeriemi , více , než by prozradil bedekr .
mnozí lidé &quot; čtou z hrobů &quot; .
pomalu se toulají hřbitovy a získávají intimní vhled do místní reality .
zjišťují , jací lidé zde žijí , jakých národností , jaké jsou víry , do jak velkých a soudržných rodin patří , v jakém věku zde umírají , jak jsou bohatí , jak důležité pro ně byly jejich tituly a profese .
jakým způsobem vyjadřují své společenské postavení , jaký mají vkus .
a ze stavu hrobů zjistí i to , jak o své mrtvé dbají pozůstalí .
nejvyšší soud podpořil obamův zákon o zdravotní péči
nejvyšší soud v usa rozhodl , že zákon o zdravotní péči podepsaný barackem obamou je v souladu s ústavou , což je zásadní vítězství pro obamovu administrativu .
poměrem hlasu 5 : 4 soud rozhodl , že individuální nařízení zákona o ochraně pacientů a dostupné péči – jež občanům nařizuje , aby si do roku 2014 zakoupili zdravotní pojištění , jinak jim hrozí , že zaplatí pokutu – neodporuje ústavě na základě vládní daňové pravomoci .
předseda soudu john roberts stál na straně čtyř liberálnějších členů soudu , zatímco soudci scalia , thomas , alito a kennedy byli v opozici .
soud také podpořil zbývající části zákona o 2700 stránkách a dále rozhodl , že zákonný požadavek na zdravotní péči , který státům nařizuje rozšířit možnost získání nemocenského pojištění , v opačném případě hrozí pozbytí veškerého financování nemocenského pojištění z federálních zdrojů , není donucovací a v rozporu s ústavou .
žalobu za účelem zablokování tohoto zákona podalo 26 států a národní federace nezávislých podniků .
během primárek v roce 2012 zákon důrazně odmítal každý z hlavních republikánských kandidátů , včetně předpokládaného navrženého kandidáta mitta romneyho .
za slova &quot; mugabe je kulhavý osel &quot; už nehrozí vězení , soud zákon zrušil
až dosud si zimbabwané museli dávat dobrý pozor na to , jak na veřejnosti mluví o devětaosmdesátiletém mugabem , který zemi vládne od počátku 80. let , od konce roku 1987 pak stojí v jejím čele .
podle paragrafu 33 trestního zákona totiž za znevážení prezidentského úřadu hrozila pokuta 100 dolarů až jeden rok odnětí svobody .
&quot; státní zástupci by neměli horlivě obviňovat lidi , kteří komentují prezidenta v hospodách nebo na jiných veřejných místech , &quot; prohlásili zástupci ústavního soudu .
devět soudců se jednomyslně shodlo na tom , že zákon podkopává svobodu vyjadřování .
je pravděpodobné , že se proti rozhodnutí soudu vláda odvolá , informovala britská bbc .
proti zákonu se hlasitě vymezovala řada poškozených zimbabwanů , mezi nimi tendai danga , jejž policie před dvěma lety zatkla za údajnou urážku prezidenta při hádce s policistou v baru .
v květnu skončil ve vězení opoziční aktivista častující na veřejnosti mugabeho nadávkou &quot; kulhavý osel &quot; .
v srpnu poté prokurátor obvinil šestadvacetiletého muže kvůli jeho úmyslu použít plakát s tváří roberta mugabeho jako toaletní papír .
soud také prohlásil za protiústavní zákon omezující svobodu médií .
&quot; stát nemůže trestat lidi , jejichž prohlášení se později ukáže jako nepravdivé , &quot; řekl náměstek ministra spravedlnosti luke malala .
až doteď totiž zimbabwské právo umožňovalo , aby osoba , která zveřejní lživé informace , byla odsouzena ke dvaceti letům žaláře .
&quot; existence zákona umožňujícího kriminalizovat někoho za nepravdivé prohlášení má zmrazující účinek na právo svobodně se vyjadřovat , &quot; dodal malala .
nehledě na to , že mugabe vládne zemi tvrdou rukou už více než 33 let , přijalo v březnu zimbabwe na základě referenda novou ústavu s širšími občanskými svobodami .
drobné krůčky směrem od diktatury jednoho muže země nastoupila v roce 2009 , kdy dohoda mezi mugabem a opozicí vynesla do premiérského křesla morgana tsvangiraje .
zemi nicméně nadále trápí ekonomická krize a až do roku 2008 nejvyšší inflace na světě , která přesáhla 100 000 procent .
v roce 2009 proto vláda zcela zrušila národní měnu .
dnes se v zimbabwe platí pouze měnami jiných států .
zbídačené hospodářství jde na vrub mugabeho neuvážlivé zemědělské reformě .
v roce 2000 přerozdělil půdu bílých farmářů mezi své příznivce a válečné veterány .
většina z nich však s chodem farem neměla žádné zkušenosti .
centrální banky udrží swapové linky natrvalo
dočasné a bilaterální dohody mezi evropskou centrální bankou ( ecb ) , americkým fedem , bank of england a centrálními bankami kanady , švýcarska a japonska se stanou stálým nástrojem , který umožní bankám přístup ke globálním měnám , kdykoli budou potřebovat .
banky to uvedly ve svém společném prohlášení .
&quot; je to velmi rozumný krok , &quot; komentoval rozhodnutí julian callow , hlavní mezinárodní ekonom londýnské banky barclays .
&quot; zatím všechny přechodné nástroje tohoto typu se postupně staly permanentními , takže to není podle mého žádné překvapení , &quot; dodává vojtěch benda , hlavní ekonom bh securities .
centrální bankéři posilují pouta , která začala vznikat v roce 2007 , když se mezinárodní úvěrový trh poprvé zadrhl .
dohody centrálních bank umožnily přístup k eurům , dolarům a dalším měnám komukoli , kdo je potřeboval .
rozhodnutí centrálních bankéřů přichází v době , kdy se americký fed připravuje na ukončení svého programu podpory americké ekonomiky , což by mohlo vyhnat cenu peněz na globálním trhu ještě výše .
swapový kontrakt se standardně používá k překonání nedostatku likvidity jedné měny při současném přebytku likvidity druhé měny .
lze ho chápat jako úložku jedné měny a výpůjčku měny druhé .
ecb startuje třetí pokus o návrat důvěry v evropské banky .
eu se dohodla na bankovním dozoru , ecb bude dohlížet na 150 bank .
jak tipsport ( ne ) maže osobní údaje .
před více než rokem , jsem na stránkách tipsport.cz provedl registraci .
tu jsem ale následně nedokončil , protože na pobočce zrovna seděl někdo , kdo registraci z internetu neuměl dokončit .
a protože se mi nechtělo jezdit na jinou pobočku , registrace propadla , pak jsem se přestěhoval a díky tomu se mi změnila adresa i číslo občanského průkazu .
když jsem chtěl registraci dokončit později , bylo mi řečeno že to nejde , protože mám jiný číslo op , adresu a že to prostě dokončit nejde a že mám požádat o výmaz údajů a provést novou registraci .
to jsem tedy udělal a 24.10.2013 jsem napsal na technickou podporu že žádám o výmaz všech svých osobních údajů z databáze podle platného zákona na ochranu osobních údajů .
na to mi duhý den napsala technická podpora že mám registraci dokončit na pobočce .
tím začal maraton e-mailů na technickou podporu , kde nakonec po 4. urganci 25.10. napsali , že osobní údaje na moji žádost vymazali .
člověk by si tedy řekl , že by mohl provést onu novou registraci a tady začaly opět problémy nejdříve mi to napsalo že moje uživatelské jméno je již obsazeno ( chápu nebylo smazáno - nejedná se o osobní údaj , nakonec ale vyřadili i toto ) .
použil jsem tedy jiné uživatelské jméno a vyskočilo na mě že moje osobní údaje již mají uloženy , abych dokončil registraci na pobočce ( jak mohou mít uloženo něco co tvrdí že vymazali ? ) , kontaktoval jsem tedy opět technickou podporu .
na můj dotaz jak je to možné mi odepsali , že osobní data skutečně vymazali 25.10. a abych poslal e-mail s onou chybou .
to jsem učinil ( včera kolem 15. hodiny ) a na to mi dnes odepsali že jsem se registroval týž den ( 31.10.2013 ) ve 13.22 a že proto to nejde , protože jsem použil stejné jméno a datum narození .
co na tom že technickou podporu kontaktuji již týden a řeším s nimi že to stále nejde .
a co na tom , že pokud by byla pravda co tvrdí ( jakože není ) nemohl by se registrovat nikdo se shodným jménem nebo stejným datem narození pokud již toto je registrováno .
jen mimochodem v těch 13.22 jsem se skutečně registroval , na stejné jméno a datum narození , ale použil jsem smyšlený e-mail a telefonní číslo a světe div se , objevila se mi stránka že mi na e-mail poslali odkaz pro dokončení registrace .
jak je to ale možné , když se nelze registrovat na stejné jméno a datum narození ?
asi proto , že tipsport váže registraci na e-mail a telefonní číslo a data prostě nevyřadil jak tvrdí .
takže jsem opět toto sdělil technické podpoře že prostě lžou ( buď úmyslně a nebo nevědí co píší ) , protože to co píší není pravda .
doložil jsem několik screenů že ten problém s registrací už byl ještě před 31.10. takže &quot; falešná &quot; registrace na tohle jednoduše nemá vliv .
na to mi tipsport odepsal strohou větu - je mi líto , ale tím , že už jste znova registrovaný , nemůžeme prověřit vaše tvrzení .
a komunikaci ukončil .
respektive opakuje dokola stejnou větu , že se registrace váže na jméno a datum narození .
nedokážou ani přijmout fakt , že registrace nebyla dokončena kliknutím na onen odkaz v e-mailu a tak vlastně ani neproběhla .
pokud to tedy shrnu , tipsport nejen , že nevymazal údaje jak tvrdí , ale ještě lže , když tvrdí opak .
o to horší je , že lze lehce dokázat , jak lžou a snaží se , aby to vypadalo , že chyba je na straně zákazníka .
mimochodem po uvedení této záležitosti na mém osobním blogu se daly věci trochu do pohybu a z technické podpory přišel e-mail že záležitost předávají k prověření a budu informován ( po týdnu urgencí a dohadování a upozornění na stejnou chybu ) .
v metru na můstku hraje hudba
dopravní podnik hl. m. ( dpp ) prahy spustil projekt hudba v metru .
prvním vestibulem , kde během provozu metra nepřetržitě hraje reprodukovaná instrumentální hudba , je můstek linky a na výstupu na václavské náměstí .
zkušební provoz potrvá šest měsíců .
michal horáček představil své nové dvojalbum , kapelu a tři zpěváky
textař michal horáček přivezl do sálu kolínského městského společenského domu nejen své úplně nové dvojcd český kalendář , ale především v pořadu mezi námi zpěváky lenku novou , františka segrada a ondru rumla doprovázené vynikajícím orchestrem matěje benka .
po úvodním intru a herecké etudě o zpožděném muzikantovi postupně pozval michal horáček na pódium všechny tři zpěváky , sám přišel se svíčkou v ruce a připomněl tak historku o tom , jak naposledy hráli v kolíně a v divadle a v celém městě vypadl elektrický proud .
&quot; jinak v kolíně vyráběly dva druhy karet , se kterými jsem hodně přicházel do styku , &quot; zavzpomínal .
stejně tak připomněl i rodáka prezidenta zemana .
&quot; možná bychom mohli udělat turné po zákolanech nebo dúbravce u bratislavy , &quot; zavtipkoval o rodištích dalších prezidentů .
několikrát za večer se horáček , který neopustil jeviště a pokud nehovořil , seděl u stolečku se sklenkou vína , dotkl svého nového hudebního počinu .
kalendář udělal i josef mánes , který jej dal na orloj , o ledním hokeji ale tenkrát nic netušil , jak se scházíme na těch náměstích a skandujeme , kdo neskáče , není čech .
tak se jmenuje i jedna písnička z českého kalendáře , ale tu vám tady dnes nezahrajeme , &quot; pobavil .
ondra ruml ale z této desky zazpíval pro něj prý hodně vhodnou spát ve dne , zpívat po nocích a doprovodil se při ní na kytaru .
jinak pokud nezpíval , hrál na perkuse , všechny tři zpěváky pak doprovázela kapela ve složení klávesy , violoncello , kytara a kontrabas .
všichni tři vokalisté si společně zazpívali trošku odrhovačku do stráně srdce usedá , která hned rozproudila hlediště .
&quot; jsem rád , že vás ten song zaujal , což mě v kmochově městě nepřekvapilo , &quot; reagoval poté michal horáček .
po vzpomínce na petra hapku zazněla rozeznávám v podání františka segrada , v originále od richarda müllera odměněná obrovským aplausem , hanu hegerovou zase připomněla skladba táta měl rád lídu baarovou i s horáčkovým vysvětlením o komunistickém zákazu a náhradě baarové americkou herečkou mae westovou .
skladatele michaela kocába zase připomněla skladba sebastián , segrado pak zazpíval nádhernou skladbu praha zhudebněnou jardou svobodou , zásmuckým rodákem a bývalým kolíňákem .
to už byl ale závěr , potlesk ve stoje a přídavek v podobě optimistické skladby žijeme v nádherné době .
na playlistu byl připravený ještě jeden přídavek , ten už si ale fanoušci nevytleskali .
téměř okamžitě po koncertě celá čtveřice zasedla za stůl , aby podepisovala nejen český kalendář , ale i starší cd , michal horáček své knížky a dokonce i obal od legendárního lp a s případnými zájemci se i vyfotila .
berdycha se štěpánkem doplní rosol a hájek
na finále davisova poháru proti srbsku nominoval nehrající kapitán českých tenistů jaroslav navrátil čtveřici tomáš berdych , radek štěpánek , lukáš rosol , jan hájek .
čeští reprezentanti trofej obhajují , ale jedou hrát na hřiště soupeře do bělehradské arény , kde se zápas uskuteční na tvrdém povrchu od 15. do 17. listopadu .
ve finále jsou češi potřetí za posledních pět let .
&quot; víme , že jedeme na horkou půdu , že to bude divoké a musíme se jako vždy soustředit na své výkony . &quot;
&quot; pojedeme tam s jediným cílem - získat tři body a prodat to nejlepší , &quot; řekl štěpánek , strůjce vítězného bodu v loňském finále se španělskem .
tajné války : sýrie , libye a írán .
školení pro obamu , jak se má bombardovat sýrie .
americké komanda v libyi .
top gun v perském zálivu .
izraelci přesně předvedli , jak má vypadat bombardování sýrie .
bez zbytečného humbuku , vyhrožování a milionů prohlášení vyslali letadla , ty zasáhla cíl a vrátila se .
aniž by se nechali ukolébat oficiálním odstraňováním chemických zbraní v sýrii .
celou akci odmítají potvrdit a už se k tomu nevyjadřují .
přesný opak zmatené a velkohubé , činy nepodepřené obamovy syrské politiky .
a nejuspokojivější na celém útoku bylo to , co izraelci bombardovali .
nenechte se zmást médii jejich tvrzeními , že byla bombardována &quot; syrská základna &quot; nebo &quot; dodávky pro hizbaláh &quot; .
nedávno jsem tady psal o tom , že zatímco pomoc usa sekulárním povstalcům v zemi zůstává jen na rétorické rovině , tak rusko vesele dál dodává zbraně sýrie .
a právě čerstvá dodávka ruských raket vyložená v přístavu latákija se stala terčem izraelského náletu .
jasný vzkaz .
a všimněte si , izrael opět bombardoval asadův režim , nikoliv povstalce , ačkoliv by to podle populárních internetových teorií mělo být naopak .
americká vláda vyznamenala 2 členy spaciálních jednotek , pravděpodobně delta force .
netušilo se až dosud , že se vyznamenali během útoku na americký konzulát v bengází .
je známa hrdinská smrt dvou bývalých příslušníku seals , kteří hájili areál cia ve městě , podle mě se jednalo o příslušníky tajného komanda cia , které je tvořena bývalými vojáky .
dlouho se spekulovalo , co dělali seals na konzulátu nebo dokonce v jinde umístěné rezidenci cia .
nyní je to jasnější .
každopádně informace , že cia má v libyi své úřadovny chráněné kulometnými hnízdy ( právě na jednom takovém oba členové seals zahynuli po zásahu minometem ) , je poměrně překvapivá .
ale ještě překvapivější jsou informace o oněch dvou dosud neznámých hrdinech .
ti byli součásti amerického komanda v tripolisu , a jakmile dostali zprávu o útoku v bengází dobrovolně se přihlásili k zásahu a společně s pěti soukromými kontraktory si prostříleli cestu do areálu cia v bengází .
obamovu administrativu blamuje fakt , že během onoho útoku nebylo ono komando nasazeno oficiálně a celé a že se prostě váhalo co dělat .
velitel komanda , tak bez rozkazů zřejmě uvolní tyto dobrovolníky .
každopádně to , že v zemi působí ne jednorázově , ale trvale americké komanda , agenti cia a soukromí kontraktoři je celkem zajímavá informace .
a to vzhledem k tomu , že se až do nedávna oficiálně nic takového nepřiznávalo a i teď se mluví jen o jakési poradenské misi nato v libyi .
je ale dobře , že se usa i když polovičatě snaží potírat terorismus v libyi .
i když k vyřešení celostátní situace by to chtělo pomoc mnohem větší .
posledním místem tajného a permanentního konfliktu , o kterém dnes chci psát je pobřeží íránu .
není to tak dávno , co média téměř opěvovala íránské vzdušné síly za stíhání amerických dronů .
málo je však známo to , jak američané své drony účinně chrání .
samozřejmě pokud se náhodou podaří objevit svůj dron ve vzdušném prostoru , nedá se s tím nic dělat .
pokud je však objeven íránci dron v prostoru mezinárodním , je situace zcela jiná .
a tak se stalo , že íránský letoun f-4 phantom pronásledoval americký dron v mezinárodním prostoru nad mořem , kdy došlo možná k prvnímu ostrému nasazení americké super stíhačky f-22 raptor v historii .
ten podletěl phantoma , aby opticky ověřil jeho výzbroj , aniž by ho phantom zaregistroval na radaru nebo si jej prostě všiml a pak když se najednou objevil u něj a vyzval íránského pilota k návratu domů , ten bez reptání poslechl .
není se co divit , když phantom je letoun americké výroby , který však pamatuje válku ve vietnamu .
s raptorem se nemůže srovnávat .
chceme ukázat , že plzeň stále umí vyhrávat , slibuje rajtoral
je to tak trochu paradox .
zatímco jeho týmu se především výsledkově v poslední době nedaří , obránce či záložník viktorie plzeň františek rajtoral má formu , která mu vynesla po roce návrat do reprezentace .
daří se mu i střelecky , hýří aktivitou , po zákroku na něj byl v utkání v teplicích nařízen pokutový kop .
viktoria sahala v posledních dvou kolech proti slavii a v teplicích po vítězství , ale nakonec z těchto dvou duelů brala jediný bod .
františek rajtoral věří , že jeho tým v utkání s jabloncem nepříjemnou sérii zlomí .
chceme ukázat , že umíme vyhrávat .
&quot; věřím , že jablonec doma porazíme , &quot; slibuje františek rajtoral .
mužstvo se na těžký zápas se severočechy , kteří hrají útočný fotbal , pečlivě připravuje .
všechno směřuje k utkání s jabloncem , trenér nás dobře připravuje , jako vždy čerpáme hodně i z videorozboru hry soupeře .
&quot; věřím , že to v pátek večer bude výborný zápas , &quot; láká český reprezentant fanoušky na tribuny doosan areny .
plzni poslední zápasy nevyšly tak , jak by si přála , ale slovo krize obránce viktorie odmítá .
tak to ve fotbale chodí , někdy máte dobrou formu a někdy zase horší .
ale o krizi bych v žádném případě nemluvil .
&quot; věřím , že v pátek vyhrajeme a zase to bude dobré , &quot; míní obránce západočechů .
mužstvo viktorie bude opět spoléhat na podporu fanoušků .
&quot; hraje se v pátek večer a tím bych chtěl naše fanoušky , kteří jsou skvělí , pozvat . &quot;
&quot; věřím , že se jim odvděčíme výhrou , &quot; dodává rajtoral .
jana péťová : krok zpět .
tak jsem se rozhodla udělat krok zpět , ale když nad tím tak přemýšlím , nejedná se vlastně vůbec o krok , ale o velký skok - skok o několik let zpátky , a to do vzpomínek , do mého dětství .
je to vzpomínka na to , jaké to bylo , nemít žádné starosti a jen přijít ze školy a umýt nádobí , vyluxovat a udělat si úkoly .
i když tyto &quot; povinnosti &quot; , to byla většinou jen teorie , přání rodičů .
praxe byla úplně jiná - přiběhnout ze školy , hodit tašku do kouta a běžet ven .
hrát si s ostatními dětmi míčové hry , skákat panáka .
potom při seriálu helena a její chlapci vyšívat řetízkovým stehem slavnostní ubrus pro babičku k narozeninám .
a až pak po několikátém upozornění umýt konečně to nádobí , vyluxovat , v zimě nanosit dřevo do kachlových kamen a úkoly dělat až po setmění pod lampičkou ( nebo se spoléhat na spolužáka a namísto úkolů psát zamilované verše adresované školní lásce ) .
ráno posnídat domácí jahodovou marmeládu ( z opravdového ovoce , ne takové ty džemy co se prodávají teď , jejichž obsah vedle jahod ani neležel ) a zapít to čajem ze sušených bylinek , které jsme s mámou tak rády sbíraly .
taky vzpomínám na ty kouzelné večery , kdy bylo hrobové ticho v pokojíčku , když jsme si se sestrou nahrávaly písničky z rádia na kazety , které se hlasitě točily ve starém kazeťáku po mámě .
a potom jsme si na tužce ty kazety přetáčely a pouštěly si pořád dokola jednu stejnou písničku , naši oblíbenou a k tomu si připíjely sifonem .
nebo jsme si přes stůl telefonovaly za pomocí plechovek , které byly k sobě svázané provázkem - a když už jsme u toho telefonování , abysme se lépe slyšely , bylo nutné důkladně si čistit uši , tehdejší uchošťour byl sirka + vata .
minimální mzda byla více než třikrát nižší než je teď a mí rodiče z ní dokázali žít tak , že nám nic nechybělo .
nepotřebovaly jsme žádné ty iphony , ipady ba dokonce ani mobily a notebooky nebo značkové oblečení .
oblečení se dědilo z generace na generaci a nejlepší &quot; přírustek &quot; do šatníku bylo batikované tričko domácí výroby za pomocí sava .
z elektroniky nám stačil ke spokojenosti zmíněný mámin kazeťák a maximálně tak walkman , o který jsme se dělily se sestrou a který jsme mimochodem používaly stejně jen ve vlaku na školním výletě .
přišlo nám zajímavější zahrát si s tetou kloboučku hop nebo člověče , nezlob se , anebo jak jsem již uvedla jít &quot; jenom &quot; ven .
když už jsem byla o trochu starší dostali jsme pod stromeček videopřehrávač , jistě na něj rodiče dlouho šetřili , ale bohužel se u nás dlouho neohřál .
moje mladší sestra do něj narvala štrůdl , prý tak krásně papal ty kazety , tak zkusila , jestli spapá i štrůdl .
bohužel spapal , ale bylo to jeho poslední sousto .
no , a tuto příhodu má dodnes , chuděra , na talíři od táty pořád .
říká , že když byla lenka malá , narvala štrůdl do videa a myslela si , že ji přehraje recept a nepřehrál , proto ho dodnes neumí upéct .
vzpomínám , jak jsme spolu dokázali všichni komunikovat , domluvit se bez mobilu , počítače .
společně se sestrou jsme se na prázdninách u babičky domluvily s vnučkou sousedky , kdy se sejdeme zase příští rok v létě u babiček - a tak to bylo , tak to platilo .
sešly jsme se .
slibte si teď s někým , že se za rok uvidíte ? !
taky vzpomínám na zimu , kdy jsme s celou vesnicí běhali venku , stavěli sněhuláky , jezdili na zasněženém kopečku u kostela na pytlech vycpaných senem .
potom jsme společně s celou rodinou povečeřeli a povídali si o uplynulém dni .
samozřejmě jsme se sestrou slýchávaly před každou večeří tu notoricky známou větu : &quot; bež si umýt ruce ! &quot;
ano , to platí i dnes , ale určitě nemáte v koupelně ke kohoutku přivázáné mýdlo v síťce od citrónů .
po večeři , když táta v garáži &quot; pracoval &quot; u piva s jardou z vesnice , lehly jsme si s mámou na podlahu , opřely nohy o kachlová kamna , otevřely dvířka a koukaly na plamínek a poslouchaly praskání dřeva , které se z kamen linulo .
byli jsme si blíž - opravdu - nepočítali jsme , kolik máme přátel na sociální síti , věděli jsme , kolik máme přátel , těch opravdových !
komunikovali jsme spolu - mluvili jsme - nepsali jsme si denně vzkazy přes různé chaty , smsky .
nic takového nebylo , a přesto jsme o sobě věděli daleko víc .
a takto bych mohla pokračovat dlouho .
je krásné vzpomínat , obzvlášť doplním-li tyto vzpomínky tím , že u toho prohlížím alba , kde jsou úhledně nalepené černými rohy vyvolané černobílé fotky .
a kdybych náhodou nevěděla , kolik mi tehdy bylo , zezadu fotky je vždy napsán rok pořízení snímku .
dívám se , že ač nám sestřihy podle hrnce moc neslušely a navíc jsme měly kalhoty po bratránkovi o dvě čísla větší , nikdo se nám dříve nesmál , bylo to tak normální ( nikoliv in ) .
a už se raději zase vrátím o ten krok vpřed - do reality .
do roku 2013 a budu čekat , co moderní doba vymyslí třeba jednou pro moje děti .
co vím jistě je to , že tyto moje vzpomínky jsou teď pro mladou dospívající generaci tak minimálně někde &quot; sto let za opicema &quot; a myslím , že o hodně přicházejí , že tuto &quot; předopičí &quot; dobu taky nezažijí .
já bych jim to přála !
společnosti google , samsung a huawei žalovány kvůli patentům společnosti nortel
skupina , která vlastní tisíce patentů zaniklé společnosti nortel , podala ve čtvrtek žalobu pro porušení patentu proti výrobcům mobilních telefonů včetně firmy google , společnosti , kterou přelicitovala při dražbě v rámci bankrotu firmy nortel .
konzorcium rockstar , které nakoupilo patenty společnosti nortel za 4,5 miliardy usd , zažalovalo u amerického obvodní soudu v texasu společnosti samsung electronics , htc , huawei a další čtyři společnosti za porušení patentu .
společnost rockstar je ve společném vlastnictví firem apple , microsoft , blackberry , ericsson a sony .
google je obviněn z porušení sedmi patentů .
patenty zahrnují technologii , která pomáhá spojit výrazy vyhledávané na internetu s příslušnou reklamou , uvádí žaloba , což je jádro vyhledávacího podnikání společnosti google .
zástupci společností samsung , huawei , htc a rockstar nebyli ihned k zastižení .
samsung , huawei a htc vyrábějí telefony , které fungují na operačním systému firmy google android , který silně konkuruje mobilním produktům společností apple a microsoft .
v roce 2011 google učinil za patenty firmy nortel výchozí cenovou nabídku 900 milionů usd .
google svou nabídku několikrát zvýšil a nakonec nabídl až 4,4 miliardy usd .
poté co byl v boji o patenty nortel poražen společností rockstar , získal google za 12,5 miliard usd společnost motorola mobility , což byl obchod motivovaný částečně skupinou patentů společnosti motorola .
„ navzdory neúspěchu při snaze získat v dražbě patenty , jež jsou předmětem sporu , společnost google patenty porušovala a nadále porušuje , “ uvádí se v žalobě .
společnost rockstar usiluje o zvýšenou náhradu škody od společnosti google , protože podle ní dochází k porušení patentu ze strany google úmyslně , jak tvrdí žaloba .
miloslava cejpková : listopadový úsměv
přišla zvenku , ze 4 stupňů celsia , co na ně ještě nejsme zvyklí .
nejdřív si odložila úsměv , ten , co dávala stále na odiv jako obranu před rádoby přátelským okolím .
tím se jí moc ulevilo , protože to byla maska , kterou se rozhodla na veřejnosti neodkládat .
byl upřímný doma jen ve dnech , kdy babičkovala a měla kolem sebe vnoučata elinku nebo adíka .
a samozřejmě , když jí telefonovali synové .
moc dobře si pamatovala poučku z nekonečných kursů obchodních dovedností .
teď se konečně opravdu hodily .
aby nezarmoutila své nejbližší .
pak letěl do kouta .
jako převlek na maškarním .
listopad , ani jiný měsíc neumí udělat ten zázrak , aby se usmála opravdu , jako tehdy , když byli na výletě s tím , který už tu skoro tři roky není .
egypt uvádí do úřadu prvního svobodně zvoleného prezidenta
muhammad mursí složil inaugurační přísahu , ale jeho triumfální den jen těžko zakončí politické nepokoje v egyptě .
islamista muhammad mursí slíbil „ nový egypt “ , když byl slavnostně uveden do úřadu jako první svobodně zvolený prezident této země , a to po husním mubárakovi , který byl sesazen o 16 měsíců dříve .
při svém uvedení do úřadu před vrchním ústavním soudem se mursí stal také prvním svobodně zvoleným islámským prezidentem v arabském světě a pátou egyptskou hlavou státu od svržení monarchie přibližně před 60 lety .
složil přísahu před 18 soudci oděnými do černých talárů v sídle vybudovaném s výhledem na nil , které připomíná starověký egyptský chrám .
„ usilujeme o lepší zítřky , nový egypt a druhou republiku , “ řekl mursí při slavnostním obřadu vysílaném živě ve státní televizi .
„ egyptský lid dnes položil základ nového života – absolutní svobody , opravdové demokracie a stability , “ řekl mursí , šedesátiletý inženýr vystudovaný v usa a člen muslimského bratrstva , fundamentalistické skupiny , která byla po většinu 84 let od svého vzniku jakožto nezákonná organizace terčem ostrých útoků jednotlivých vlád .
když mursí krátce po 11. hodině místního času přijel v malé koloně automobilů , střežily budovu stovky vojáků a policistů .
pouze několik set podporovatelů se sešlo před budovou soudu , aby oslavilo prezidenta , a na rozdíl od prezidentské okázalosti mubárakova období byla doprava jen krátce zastavena , aby mohla kolona projet obvykle rušnou cestou spojující centrum města s předměstími na jihu .
osobní prestiž mursího , posměšně označovaného jako necharismatická „ rezervní pneumatika “ muslimského bratrstva , prudce narostla od jeho vítězství a jeho pátečním projevu , který měl za cíl prezentovat ho nejen jako kandidáta islamistů , ale také všech těch , kdo chtějí dovést do konce vzpouru vůči autoritářskému mubárakovi .
„ egypt je dnes občanskoprávním , národním , ústavním a moderním státem , “ řekl mursí oděný v modrém společenském obleku s červenou kravatou soudcům v dřevem obložené komoře , kde složil přísahu .
mursí později odcestoval do káhirské univerzity , kde měl přednést inaugurační projev .
zatímco stál v pozoru , dostalo se mu oficiálního uvítání od vojenské kapely , která zahrála národní hymnu .
přítomen byl vojenský velitel polní maršál husajn tantáví .
jeho příchod byl doprovázen skandováním „ armáda a lid jsou jedna ruka “ z úst stovek lidí shromážděných v hlavním přednáškovém sále univerzity .
univerzita v káhiře byla založená v roce 1908 jako centrum sekulárního vzdělávání a později v 70. letech se stala baštou islámských studentských hnutí .
mursí složil v pátek symbolickou přísahu na náměstí tahrír , v místě , kde se zrodila revoluce , která loni ukončila autoritářskou vládu mubáraka , a slavnostně slíbil , že opět uchopí prezidentské pravomoci odebrané jeho úřadu vojenskou radou , která je převzala od vypuzeného vůdce .
ale souhlasem se složením oficiální přísahy před soudem , spíše než před parlamentem , jak je zvykem , se podvolil vůli armády , což naznačuje , že boj o moc bude pokračovat .
mursího projev na náměstí tahrír byl plný dramatických populistických gest .
v ghettech asi budou policejní specialisté , mají zmírnit napětí
v ghettech v česku by v budoucnu měli působit policejní specialisté .
trávili by tu až polovinu svých pochůzek .
dohlíželi by na pořádek a řešili problémy .
díky své znalosti prostředí by měli přispět ke snížení napětí mezi lidmi z chudinských míst a obyvateli z okolí .
ve svém návrhu ke snižování bezpečnostních rizik s tím počítá ministerstvo vnitra .
podle něj by ke zlepšení situace v zemi pomohlo hlavně &quot; urychlené zajištění sociálního bydlení &quot; .
dokument projednala vláda .
podle analýzy bylo v česku před pár lety kolem 300 chudinských domů a čtvrtí .
žilo v nich na 80.000 lidí , a to hlavně romů .
dospělí v ghettech byli bez práce , rodiny byly závislé na dávkách , děti končívaly ve &quot; zvláštních &quot; školách .
bujela lichva .
podle expertů problémových lokalit mezitím o stovku přibylo .
vztahy mezi jejich obyvateli a ostatními se vyostřují .
na několika místech se konaly protiromské pochody .
k extremistům se přidávali i lidé z okolí .
podle vnitra bývá pro policii náročné v oblastech s ghetty bezpečnost a pořádek udržet .
zásadní podmínkou je prý &quot; důsledné uplatňování rovného přístupu ve vymáhání práva &quot; .
toho ale prý bez podrobné znalosti místa a lidí není možné dosáhnout .
specialista by chodil na pochůzky v ghettu , kde by trávil až polovinu své služby , zbytek by sloužil ve svém obvodu .
v problémové lokalitě by dohlížel na pořádek .
znal by také místní , takže by mohl lépe problémy či přestupky řešit .
&quot; díky navázané důvěře budou specialisté snadněji schopni předcházet celé řadě protiprávního jednání , &quot; uvedlo vnitro .
specialisté v ghettech by dostávali příplatky , a to 500 až 1000 korun měsíčně .
zavádění speciálních policistů do problémových oblastí se má hradit z norských fondů .
rozpočet je asi 600.000 eur ( teď zhruba 15,5 milionu korun ) .
česko platí 15 procent sumy , fondy 85 procent .
přípravy začaly letos , nyní se zpracovává podrobný návrh .
projekt má trvat do roku 2016 .
autoři se inspirovali u sousedů .
tento mechanismus je úspěšně již několik let aplikován na slovensku , kde je problém se sociálně vyloučenými lokalitami nesrovnatelně vyšší než v čr .
&quot; existují tu takzvané romské osady , &quot; uvedli autoři zprávy .
kolik specialistů by mělo v česku být , není zatím jasné .
odpověď má dát analýza , která určí místa , kde by byl zvláštní policista potřeba .
záležet bude také na tom , kolik peněz na tyto příslušníky bude moci policie po skončení projektu každoročně uvolnit .
podle návrhu projektu nejdřív vybraní policisté absolvují stáž na slovensku .
ročně by tímto školením mělo projít pět desítek příslušníků .
z nich vzejdou nejvhodnější kandidáti .
vzniknout by mělo také speciální vzdělávání pro policisty , kteří budou v ghettech působit .
podle autorů by ke zlepšení situace pomohlo hlavně sociální bydlení .
mělo by prý motivovat a vést k integraci .
podle představ vnitra by mělo tři kategorie .
minimální standard by splňovaly ubytovny s přesně stanovenými pravidly , jako je třeba počet osob na místnost .
střední standard by byl v menších bytech .
vyšší standard by měly sociální byty , které by byly srovnatelné s běžným bydlením .
nájemníci by museli plnit integrační plán , který by s nimi sestavili sociální pracovníci .
museli by dodržovat ubytovací řád , starat se o své zdraví , posílat děti do škol , rekvalifikovat se a aktivně si hledat práci .
pokud by se o začlenění snažili , postoupili by do vyššího standardu bydlení .
systém prostupného bydlení by měl podle vnitra fungovat aspoň 30 let , dokud nevyroste další generace &quot; v prointegračně motivovaném prostředí &quot; .
model sociálního bydlení připravují resorty pro místní rozvoj a práce .
navrhnout ho mají do konce roku .
karel drábek : uhlířský vrch - jedna z našich nejmladších sopek .
uhlířský vrch je nápadný kopec 3 km jihovýchodně od bruntálu .
spolu s několika dalšími je dokladem sopečné činnosti v nízkém jeseníku v době ( z geologického hlediska ) nedávné .
poslední erupce zde byly ještě na začátku čtvrtohor .
při pohledu z větší vzdálenosti je na vrcholu uhlířského vrchu nápadný bíle omítnutý barokní poutní kostel panny marie pomocné , vystavěný v letech 1755 - 1765 .
nahradil původní dřevěnou poutní kapli .
hostinec , který stál vedle kostela , se nezachoval .
krátce po dokončení kostela byla vysazena alej ze čtyř řad lip , dlouhá asi 1 km .
křížová cesta na uhlířském vrchu je již třetí verzí , původní zde stála po roce 1916 , druhá , z roku 2001 vydržela jen do roku 2004 .
na patnácti zastaveních jsou dřevěné plastiky , které zhotovil místní umělecký řezbář františek nedomlel .
použil různých druhů dřevin z oblasti nízkého jeseníku .
podobně podstavce z hornin ze zdejší oblasti tvoří zajímavou geologickou exposici .
na každém zastavení je uvedeno i jméno sponzora .
uhlířský vrch je zbytkem mladé sopky .
i když se údaje z radiometrických měření stáří poněkud liší , poslední erupce zde byla asi před 1,5 milionem let .
je tedy mladší než velký roudný ( stáří 3,3 milionu let ) a starší než venušina sopka ( stáří 0,8 milionu let ) .
sopka se zrodila explozí .
při ní vyvrhla značné množství sopečného popela spolu s úlomky hornin z podloží , které vypálením získaly červenohnědou barvu .
v závěru této fáze vytekla na povrch láva - dnes je to vrstva pórovitého čediče až 13 metrů mocná .
druhá erupce vyvrhla červené , hnědočervené a místy až černé tufy .
jejich vrstva je mocná až 50 metrů a její část je přístupná ve stěně lomu .
v tufech jsou nápadné sopečné pumy velké až 1 metr. i druhá erupce byla zakončena výlevem lávy .
na závěr činnosti ze sopky vytekla láva , která dnes tvoří až 50 m mocnou vrstvu struskovitého čediče .
sopky , u kterých se střídá vyvrhování sopečného popela s výtoky lávy jsou nejčastějším typem sopek .
protože jsou vlastně složené z vrstev , dostaly název stratovulkány .
původní sopečný kužel podléhal postupně erozi .
ohrožen byl však až těžbou hornin v lomu na jižní straně .
nejintenzivnější těžba zde probíhala v letech 1953 - 1962 .
tufy se přidávaly do betonu , který byl pak lehčí a měl lepší tepelně izolační vlastnosti .
těžbu se podařilo pod tlakem odborníků i veřejnosti zastavit a tím zachovat toto unikátní místo .
problém je však v pórovitosti a malé soudržnosti hornin , které rychle zvětrávají , rozpadají se a sesouvají po svahu dolů .
lom tak poměrně rychle mizí .
aby byla situace ještě komplikovanější , je teplý , jižně orientovaný svah ideálním místem pro některé vzácné druhy rostlin a živočichů .
náprava je tedy problematická , ale časem bude nutno vybrat a udržovat charakteristický geologický profil .
není to nic nového , podobné profily se udržují na řadě důležitých lokalit .
na uhlířský vrch se dostanete po zelené turistické značce z bruntálu , případně ze slezského kočova .
automobilisté mohou použít neplacené parkoviště na začátku lipové aleje , kde začíná i krátká naučná stezka .
z vily se přestěhovala do paneláku .
ivana vyrůstala a trávila větší část života v činžovní vile se zahradou a bazénem v jedné z nejhezčích pražských vilových čtvrtí na ořechovce .
původní vlastníci domu jej ovšem získali v restituci zpět a nájemníci se museli s malým odstupným odstěhovat .
ivana proto rychle hledala náhradní bydlení pro sebe a svou tehdy už starší maminku .
od známých dostala tip na byt 3 + kk ve starším panelovém domě na opačné straně prahy .
&quot; zprvu to byl šok , ale pohled ze čtvrtého patra na rozsáhlý lesopark a přehradu mě na druhou stranu nadchnul , &quot; vzpomíná ivana na první dojem .
nejdřív jsem si říkala , že to bude provizorium tak na tři roky .
&quot; dnes tu bydlíme víc než třináct let a nejenom kvůli postupné rekonstrukci bych neměnila , &quot; dodává majitelka .
matka s dcerou se tehdy stěhovaly ze stodvacetimetrového bytu do menšího s plochou 62 m2 a takřka veškeré vybavení rozdaly .
akce nebyla jednoduchá , věci byly uskladněné u přátel a postupné zařizování trvalo skoro rok .
nový byt byl v celkem dobré stavu , ale musely proběhnout nezbytné úpravy , například lakování dveří či výměna oken .
předešlý majitel vyboural jádro , ovšem majitelce nejvíce vadila neprakticky řešená a zbytečně velká předsíň , a naopak malá koupelna .
spojením dvou pokojů vznikl multifunkční obytný prostor .
architekti použili pro vymezení jednotlivých zón a členění místnosti sádrokarton , který umožnil nové umístění světel .
prvním zásahem , k němuž se po pár letech odhodlala , bylo odstranění příčky v obývacím pokoji .
tím se bytu sice změnila dispozice na 2 + kk , ale místnost získala na vzdušnosti a otevřel se panoramatický výhled na okolní zeleň .
dalším krokem k částečnému vylepšení standardu byla náhrada podlahy z pvc za laminátovou .
s koupelnou si ivana nevěděla rady .
roky jsem odebírala časopisy o bydlení a hledala inspiraci .
v jednom z nich jsem nedávno objevila zajímavou realizaci .
na doporučení jsem tedy oslovila mladou architektku kamilu douděrovou .
&quot; byl to vlastně do budoucna nejdůležitější krok , &quot; tvrdí ivana .
díky přestavbě koupelny se povedlo zároveň upravit i dispozici předsíně .
architektka spojila prostor wc a koupelny a dvoje dveře s otvíravými křídly nahradila jedněmi posuvnými , čímž ušetřila místo .
koupelna je nadčasová a také dostatečně bezbariérová .
kvalitní obklady imitují pískovec , ve sprše je navíc pohodlné sedátko , u klozetu bidetová sprška .
úspěšná spolupráce s kamilou douděrovou pokračovala dál .
v rámci pořadu jak se staví sen proběhla rychlá , ale zásadní proměna obývacího pokoje , na níž se podílel také architekt martin čeněk .
do prostoru , který vznikl spojením dvou menších místností , jsme museli dostat tři funkce , jídelní , obytnou a spací , aniž bychom si pomáhali klasickými principy optického dělení , kupříkladu polopříčkami či japonskými stěnami .
&quot; to by ve výsledku porušilo otevřenost a jednotnost prostoru , &quot; vysvětluje architektka .
podařilo se originálně oddělit spací a obývací část .
stačilo k sobě obrátit zády dvě pohovky a mezi ně postavit na míru vyrobenou skříňku na peřiny .
jídelní kout vymezují odstíny podlahy a výmalby .
na podlahu v kuchyni a jídelního koutu použila architektka kvalitní marmoleum , posuvné dveře oživila tapetou se vzorem .
kuchyňský kout v případě potřeby zakrývají posuvné panely s tapetou .
nová podlaha z antialergického marmolea má oproti předešlé z laminátu řadu výhod : měkčí nekluzký povrch beze spár a lepší zvukovou izolaci .
systém výklenků a podhledů ze sádrokartonu zvýrazněných barvou je ukázkou , jak lze v paneláku pracovat s prostorem .
barvy jsem nechala na architektech , přála jsem si , aby to bylo radostné .
&quot; oranžovou mám ráda , stejný odstín jsem měla i v předchozím bytě , &quot; říká ivana .
obklad z grafoskla s motivem rozkvetlé magnolie je praktický a vytváří výrazný estetický prvek .
k teplému energickému tónu architekti zvolili bílou , jež podtrhla moderní funkční styl .
v malém bytě se povedlo uložit knihy mimo jiné i do prostoru pod okenní parapety .
vše je na dosah , lampičky jsou komfortně ovládané na dálku .
v předělaném interiéru funguje výborně kontrast nového se starším , například s desítky let starým křišťálovým lustrem i s kvalitními uměleckými předměty , které ivana sbírá celý život .
poslední na řadu přišla kuchyň .
skříňky byly dříve rozmístěny po obou stranách a majitelka si tu připadala trochu jako v tunelu .
architektka ubrala jejich počet a přeskládala rozmístění .
nábytek v jednoduchém designu je vyrobený na zakázku , bílou plochu zjemňuje mírně perleťový povrch .
do malého prostoru se vešly díky nápaditému řešení pračka , sušička i myčka .
vzhled malé kuchyně oživil celoskleněný obklad stěn nad pracovní deskou .
unikátní grafosklo s digitálně tištěným motivem je atraktivní , navíc se výborně udržuje .
ivana si vybrala květy magnolií , které jí připomínají oblíbenou čtvrť , v níž léta bydlela .
nyní se zdá , že je spokojená i tady .
v původní koupelně byla malá vana a umyvadlo , do nové majitelka zvolila neutrální odstín obkladu .
velký sprchový kout má skleněné dveře ronal .
úkolem bylo vytvořit z daného prostředí jasný jednoduchý prostor , v němž funkce a zařízení budou v harmonii .
interiér jsme materiálově a barevně sjednotili a pokusili se o jeho elegantní , útulný , ne příliš přeplněný vzhled .
&quot; další podmínkou zadání bylo bezbariérové řešení s minimem překážek a možností snadného pohybu okolo nábytku a dosažitelnost předmětů denní potřeby , &quot; dodává kamila douděrová .
nejvyšší soud rozhodl : nečase lze stíhat .
nejvyšší soud rozhodl , že bývalého premiéra petra nečase lze stíhat i za případné trestné činy , kterých se mohl dopustit před srpnovým rozpuštěním poslanecké sněmovny .
chránila ho pouze procesní imunita , která se vztahuje na projevy ve sněmovně .
v případě bývalých poslanců ods ivana fuksy , marka šnajdra a petra tluchoře naopak rozhodl , že je nelze trestat za případné trestné činy do doby , než se loni v listopadu vzdali výkonu poslaneckého mandátu , řekl mluvčí nejvyššího soudu petr knötig .
soud tímto rozhodnutím zamítl návrh státního zástupce iva ištvana , který chtěl pokračovat v trestním řízení s poslanci .
ti podle něj přijali úplatek v podobě lukrativních postů ve státních firmách za to , že se vzdají mandátu a nebudou dělat problémy při schvalování zákonů .
naopak lze dále stíhat bývalého premiéra , který jim tyto posty nabídl .
s vítem bártou zadrželi také důstojníka protikorupční policie
bártův obhájce oldřich chudoba , který jej zastupoval i v kauze údajné korupce poslanců vv , se k případu rovněž nechtěl příliš vyjadřovat , ale sdělil : &quot; ano , zastupuji klienta i v této věci , ale vzhledem k ochraně utajovaných skutečností to nemohu dál komentovat . &quot;
podle informací práva případ řeší generální inspekce bezpečnostních sborů ( gibs ) .
server tn.cz uvedl , že bárta si od policie mohl kupovat utajené informace .
podle serveru prvnizpravy.cz mohl případ souviset s kauzou bývalého policejního prezidenta petra lessyho , o jehož jmenování do funkce bárta údajně usiloval .
poslední informace práva ale ukazují , že zadržení víta bárty s petrem lessym nesouvisí .
mluvčí policejního prezidia eva kropáčová odmítla věc komentovat s tím , že případem se zabývá pražské městské zastupitelství .
&quot; tento dotaz nebudeme s ohledem na ochranu utajovaných skutečností nijak komentovat , &quot; řekla v pátek právu mluvčí městského státního zastupitelství v praze štěpánka zenklová .
právě tamní žalobce bártovu věc dozoruje , a z jejích slov tedy nepřímo vyplývá , že spis nebo trestní řízení je vedeno v režimu utajení .
reportérovi novinek se podařilo zastihnout manželku víta bárty kateřinu klasnovou ráno před jejich bydlištěm na pražském klárově .
právě nakládala kufry do auta a odjížděla .
k celé události se odmítla vyjádřit .
v pátek dopoledne se k bártovu zadržení vyjádřil lídr hnutí úsvit tomio okamura .
ten podle svých slov vůbec netuší , o co se v kauze jedná .
&quot; vít bárta byl jedním z mnoha kandidátů mnoha stran na naší kandidátce , a jak jsem opakovaně říkal již před volbami , nebyl ani není člen úsvitu přímé demokracie tomia okamury , &quot; dodal .
vít bárta , který v uplynulých předčasných volbách do sněmovny v plzeňském kraji neúspěšně kandidoval za hnutí úsvit přímé demokracie tomia okamury , je znám svou korupční kauzou uplácení poslanců věcí veřejných .
v dubnu 2012 byl nepravomocně odsouzen na 18 měsíců s odkladem na 30 měsíců .
posléze byl rozsudek změněn a bárta byl zproštěn obžaloby .
prospal : chci smlouvu v nhl .
šťávu , chtíč a nadšení stále mám
pro prospala byla vždycky na prvním místě rodina , proto se jí chce ve svých 38 letech naplno podřídit .
buď dostane práci v zámoří a ještě si prodlouží kariéru , nebo s hokejem definitivně skončí .
&quot; chci plnit roli taťky a manžela . &quot;
&quot; moc se na to těším , &quot; říká hokejista , který stále marně čeká na nabídku .
navzdory tomu , že je to vyhlášený pracant , který nikdy nic neošidí .
navzdory tomu , že na ledě pokaždé nechá srdce a dokáže tím strhnout i spoluhráče .
a také navzdory faktu , že byl v uplynulé sezoně nejproduktivnějším hráčem columbusu .
&quot; ale touha všem ukázat ve mně pořád je , &quot; hlásí odhodlaně .
možná se dočká , údajně o něj stojí new york rangers , jimž se nepovedl vstup do sezony a navíc mají zraněné dvě opory - útočníky ricka nashe a ryana callahana .
jak to vaším příchodem do rangers vypadá ?
jsou to jenom spekulace .
dokud nebudu mít něco na papíře , tak se tím nemá cenu zabývat .
vím , že vyšel článek v deníku new york post , že by mě měli podepsat , ale to je celé .
nikde už nebylo dodané , že se tak opravdu stalo .
bohužel , sám bych rád oznámil , že nějakou smlouvu mám , ale prostě to tak není .
ani se vám z klubu neozvali ?
taková komunikace v nhl probíhá denodenně .
tam jde o to dostat se do situace , kdy ta smlouva opravdu přijde .
kdy se třeba zraní hráč nebo to někomu nejde a mančaft nešlape .
tam je spousta různých faktorů , které se musí sejít dohromady , abych tu smlouvu dostal .
ale v new yorku zrovna podobné okolnosti nastávají , ne ?
zraněný je rick nash s ryanem callahanem a týmu nevyšel vstup do sezony , takže tam určitá šance je , nemyslíte ?
samozřejmě , ta šance je vždycky .
druhá věc ale je , že na to vždycky potřebuješ dvě strany .
já bych dneska vzal spoustu nabídek , ale zatím jsem žádnou nedostal .
taková je bohužel realita , ve které musím žít .
v pátek odlétáte do ameriky , jste v očekávání , že by něco přece jenom mohlo klapnout ?
já mám ta očekávání od 5. července , kdy se v nhl otevřel trh s volnými hráči , a pořád nic .
chystáte se do new yorku , abyste se připomněl ?
to určitě ne , já se chystám do tampy za dětma a za manželkou .
těším se na sluníčko a na to , až se zase uvidíme .
máte nějak naplánovaný svůj program ?
ten je daný tím , že jsem otec a manžel a od toho se všechno odvíjí .
momentálně nejsem žádný hokejista - nemám smlouvu a nehraju zápasy .
takže budu plnit roli taťky a manžela a už se na to moc těším .
už v neděli má vašík dva hokejové zápasy , to je pro mě i celou moji rodinu svátek , když můžeme jít podpořit naše děti v tom , co chtějí dělat .
přemýšlíte , že byste tohle mohl dělat v uvozovkách na plný úvazek ?
jasně , člověk může přemýšlet o spoustě věcí .
i tohle může nastat .
vyzkoušel jsem si to před třemi lety , kdy jsem promeškal 50 zápasů kvůli operaci kolene .
a moc a moc mě to bavilo .
jednou se to dostane do takové fáze , že všechny góly , vítězství a přihrávky ti nenahradí to , co máš doma .
protože rodina a děti , to je smysl života .
ať máš práci , jakou chceš .
já měl práci , která byla to nejkrásnější , co mě kromě rodiny mohlo potkat .
měl jste spoustu nabídek z evropy : máte to tak , že chcete hrát nhl jenom proto , že je to nhl , nebo je to kvůli rodině , že chcete být v americe ?
jelikož jsem hokejista , tak na první místo - kromě rodiny - patří i sportovní úspěch .
nhl je nejlepší soutěž na světě .
a od toho se odvíjí i rodinný život .
moje děti , tedy pardon , naše děti - moje a mé ženy - vyrůstaly ve státech , začaly tam chodit do školy a tak dále .
a my bychom byli hrozně rádi , kdyby v tomhle trendu pokračovaly .
protože co si budeme namlouvat , v americe jsou možnosti úplně někde jinde .
takovou šanci bychom jim měli nabídnout .
plánujete tedy , že zůstanete v americe natrvalo ?
my to budeme praktikovat jako doteď .
to znamená , že v létě budeme v čechách na hluboké a v okolí českých budějovic .
a v zimě zase v tampě nebo tam , kam nás zavedou naše kroky .
to je úplně ideální , být pořád v teple .
já jsem měl v životě obrovské štěstí .
dá se říct , že jsem mu šel naproti , stálo to spoustu sil a odříkání a vzalo mi to spoustu věcí , které jsem promeškal .
ale hokej mi na oplátku nabídl spoustu možností a tohle je jedna z nich .
že si se ženou můžeme vybrat , kde budeme žít .
na světě je spousta lidí , kteří po tomhle prahnou , aby si mohli vybrat , co budou dělat a jak budou žít .
jak dlouho v sobě budete mít ve svém věku vůli dřít , tvrdě trénovat a čekat na nabídku ?
jo , tak to je otázka , na kterou nedokážu odpovědět .
dneska to v sobě ještě mám , tu šťávu , ten chtíč , to nadšení , tu vášeň pro ten sport. tu touhu a motivaci dokázat lidem , že pořád máš na nhl , že jsem pořád lepší než někdo jiný .
ale nedokážu říct , jak dlouho to tam ještě zůstane .
to nejde naplánovat .
takže se dá říct , že tuhle sezonu počkáte , jak se to vyvrbí a pak se rozhodnete , co dál ?
já jsem ve fázi , kdy jdu den ode dne .
nedávno generální ředitel čez oznámil , že rozhodnutí o výstavbě 3. a 4. bloku elektrárny temelín odkládá na konec roku 2014 či 2015 .
zdůvodnil to čekáním na novou státní energetickou koncepci a odsouhlasením contracts of difference vládou .
těmito důvody se současné vedení čez snaží přenést svou zodpovědnost na vládu - tedy za majoritního akcionáře .
kvalifikovaný manažer by ale měl akcionáři dát doporučení , a ne se za něj schovávat .
babiš : vládu jen se sobotkou .
andrej babiš se začíná smiřovat , že jeho hnutí ano nebude mít čas se učit politickému řemeslu v opozici a že bude muset rovnou do vlády , aby vůbec nějaká vznikla .
předseda ano to připustil v rozhovoru pro právo , který vyjde zítra .
obchod a marketing škofinu vede abrahámek
do jeho kompetencí patří oblast produktu a marketingu a posílení spolupráce s obchodními partnery .
ve funkci nahradil luďka šantoru .
abrahámek posledních 14 let své profesní kariéry spojil s automobilovým sektorem .
působil v toyota motor czech , následně ve společnosti fiat čr , kde byl sedm let odpovědný za značku a dealery alfa romeo .
jeho posledním působištěm byla společnost suzuki motor czech , v níž přes pět let zastával pozici manažera automobilové divize .
škofin vznikl v roce 1992 .
policie evakuovala kvůli střelbě část letiště v los angeles
na mezinárodním letišti v los angeles se ráno střílelo .
policie kvůli tomu evakuovala část letiště , údajně se jednalo o terminál tři .
agentura reuters s odvoláním na kalifornská média tvrdí , že muži zákona zastřelili puškou ozbrojeného muže .
los angeles times s odkazem na policii uvedly , že došlo k přestřelce , při které byli zraněni dva až tři příslušníci správy bezpečnosti v dopravě .
kolik lidí bylo celkem zraněno a zda jsou nějaké oběti ale stále není zřejmé .
hasiči mluví o události s větším množstvím zraněných .
cnn : izrael bombardoval vojenskou základnu v sýrii .
cílem měly být ruské rakety pro hizballáh .
izraelské vojenské letouny ve čtvrtek údajně bombardovaly vojenskou základnu blízko syrského přístavu latákíja .
s odvoláním na nejmenovaného činitele americké vlády to oznámila televize cnn .
izraelský tisk o explozi v údajném skladišti raket široce informoval , útok na něj však izraelská vláda nepotvrdila .
mluvčí izraelské armády na dotaz cnn odmítla informaci o náletu komentovat .
&quot; nevyjadřujeme se ke zprávám zahraničních médií , &quot; řekla .
terčem izraelského náletu byly podle amerického vládního zdroje rakety a související vybavení , které by podle názoru izraelců mohly být přepraveny militantnímu libanonskému hnutí hizballáh .
agentura ap s odvoláním na jiného amerického bezpečnostního činitele informovala , že terčem izraelského náletu na cíl na syrském území byly ruské rakety sa-125 .
druhý kanál izraelské televize informoval , že cílem útoku byl údajně vysoce moderní syrský systém protivzdušné obrany .
satelitní snímky oblasti útoku ale podle agentury dpa ukázaly baterii ruských raket typu s-125 něva .
kromě toho prý na nich byla vidět baterie raket sa-3 včetně velitelského střediska s radarem ke sledování raket a jejich cílů .
zaznamenané rakety mají podle zprávy izraelské televize dolet 35 kilometrů a mohly by nést hlavice o váze 70 kilogramů .
izrael letos už nejméně dvakrát údajně bombardoval dodávky raket uvnitř sýrie , uvedly cnn a ap .
izraelská armáda na takové zprávy nikdy nereagovala , opakovaně ale prohlašovala , že zasáhne jakoukoliv dodávku zbraní určenou hizballáhu nebo jiným skupinám označeným za teroristické .
znamená internet konec cestovních agentur ?
flight centre zdá se úspěšně odolává tomuto trendu .
společnost aktualizovala odhad ročního zisku a očekává rekordní zisky od rekreantů v austrálii a velké británii .
cestovní kancelář nyní očekává , že se její roční základní zisk před zdaněním bude pohybovat mezi 325 a 340 miliony usd oproti 305 až 315 milionům usd z předchozí prognózy .
pokud bude zachován současný vývoj , bude to představovat dvanácti až sedmnáctiprocentní nárůst vůči rekordnímu zisku 290,4 milionu usd z roku 2011 / 12 .
generální ředitel graham turner řekl , že společnost flight centre vytvořila osmiprocentní zisk v prvním pololetí a druhé pololetí začala prudkým růstem především v australském a britském cestování mimo služební cesty .
„ k dnešnímu datu je našich 10 zemí ziskových a několik směřuje k rekordnímu ročnímu zisku před úrokováním a zdaněním , “ řekl .
sem patří austrálie a velká británie , což jsou tradičně naši největší tvůrci zisku .
podnikání s rekreačními aktivitami se během druhého pololetí v austrálii vzchopilo , což kompenzuje mírně slabší domácí trh s podnikovým cestováním .
podobně i ve velké británii si společnost flight centre vedla dobře v rekreační oblasti , zatímco podnikoví klienti utráceli méně .
americký obchod se po ztrátě během sezónně slabšího pololetí zotavil a očekává se , že přinese potřetí v řadě celoroční zisk .
akcie společnosti flight centre byly včera o 3 centy vyšší na úrovni 38,20 usd .
aktivisty greenpeace zadržované v rusku přepravili do petrohradu
ekologičtí aktivisté zadržovaní od září v rusku kvůli protestu proti plánované těžbě ropy v arktidě byli přepraveni z murmansku do petrohradu .
informovala o tom dnes agentura afp s odvoláním na mezinárodní ekologickou organizaci greenpeace .
ta zároveň tvrdí , že původní obvinění jejích aktivistů z pirátství zatím nebylo staženo .
&quot; greenpeace international se z diplomatických zdrojů dozvěděla , že třicítka mužů a žen , zadržovaná v rusku po nenásilné akci proti ropné plošině v arktidě , byla přepravena z nápravného zařízení v murmansku do věznice v petrohradu , &quot; oznámila organizace v prohlášení .
důvody přemístění zadržených aktivistů nejsou jasné ; podle agentury dpa šlo o plánovaný přesun .
úřady ekology nejprve obvinily z pirátství , za což jim v případě odsouzení hrozilo až 15 let vězení .
minulý týden ale oznámily , že toto obvinění nahradí mírnějším výtržnictvím , za něž hrozí nižší trest s horní hranicí sedmi let odnětí svobody .
greenpeace ale v dnešním prohlášení upozornilo , že obvinění z pirátství úřady zatím nestáhly , jak slíbily .
to prý znamená , že zadržení jsou teď obviněni ze dvou trestných činů .
mocný výbor pro vyšetřování minulý týden oznámil , že obvinění z pirátství nahradí obviněním z výtržnictví .
když ale třicítka vězněných stanula před výborem tento týden , obvinění z pirátství nebylo staženo .
místo toho proti každému bylo vzneseno obvinění nové , &quot; citovala afp z prohlášení greenpeace .
rusové zadrželi u ropné plošiny společnosti gazprom v polovině září tři desítky členů hnutí greenpeace pocházejících z 18 zemí .
ekologové byli na lodi arctic sunrise , která plula pod nizozemskou vlajkou .
od té doby jsou všichni drženi ve vazbě , proti které sice podali odvolání , ale soud je všechny zamítl .
na podmínky věznění si ekologové stěžují .
výkonný ředitel greenpeace kumi naidoo podle afp dnes uvedl , že přesun do petrohradu usnadní setkání zadržovaných s rodinami i s konzulárními pracovníky .
nejsou však žádné záruky , že podmínky v novém vězení budou lepší než v murmansku .
&quot; ve skutečnosti mohou být horší , &quot; upozornil .
o pomoc poprosila nizozemského krále willema-alexandra jedna ze zadržovaných aktivistek faiza oulahsenová .
v ručně psaném dopise , který dnes zveřejnil list algemeen dagblad , monarchu vyzvala , aby o jejich situaci promluvil při plánované schůzce s ruským prezidentem vladimirem putinem .
tvrdí v něm , že málikí má velký podíl na obnově sektářského násilí v iráku , které je prý zčásti dílem také bojů v sousední sýrii .
školy by se měly více soustředit na matematiku , pravopis a gramatiku
při hodinách anglické literatury bude nutno prostudovat alespoň jednu shakespearovu hru , novelu z 19. století , romantickou poezii a současnou britskou beletrii od roku 1914 dále .
zkouška bude zahrnovat také „ skrytý text “ , aby se motivovalo k hlubšímu čtení ;
kombinované kurzy anglické literatury a jazyka budou zrušeny .
od roku 2015 se bude od studentů vyžadovat , aby měli maturitní zkoušku z jazyka , a budou vybízeni , aby si vybrali anglickou literaturu jako volitelný předmět .
ministerstvo školství by mělo zítra vydat nové osnovy pro angličtinu a matematiku – první předměty , které mají projít radikální změnou .
u dalších zásadních předmětů se změny čekají příští rok .
v samostatném kroku úřad ofqual , který dohlíží na maturitní zkoušky , odhalí změny ve struktuře maturitní zkoušky , a to spolu s novým systémem známkování a menším objemem projektů pro studenty .
ve svém projevu v létě ministr školství michael gove řekl , že panuje „ široký konsenzus , pokud jde o to , zda potřebujeme reformovat náš zkouškový systém , abychom znovu získali důvěru společnosti “ , a že je třeba trvat na tom , aby maturitní zkouška byla „ náročnější , ambicióznější a přísnější “ .
studie ukazuje , že anglické školy věnují méně času matematice – 116 hodin ročně nebo tři hodiny týdně – než většina ostatních zemí .
pro srovnání školy v austrálii věnují matematice průměrně 143 hodin ročně a v singapuru asi 138 .
přestože nebude žádný oficiální požadavek věnovat více času matematice , koaliční zdroje uvedly , že obsáhlá maturitní zkouška z matematiky – spolu s větším důrazem na tento předmět ve výsledkových žebříčcích – pravděpodobně povzbudí školy , aby poskytly vyučování navíc .
učební plán se bude více soustředit na „ problémy ze skutečného světa “ , včetně finanční matematiky .
ostravský primátor kajnar : rakovinou v čssd nejsem já
před volbami se naplno rozhořel dlouho doutnající spor mezi dvěma křídly bojujícími o vliv uvnitř ostravské čssd .
vše vyvrcholilo tím , když se primátor ostravy petr kajnar obrátil na soud kvůli nedemokratickému sestavování kandidátek .
aktéři kauzy se k tomu přesto nechtěli příliš vyjadřovat , aby stranu před volbami nepoškodili ještě více .
teď už jsou ale hlasy voličů sečteny .
vedení ostravské čssd tak hned v pondělí večer vyzvalo primátora ostravy , aby vystoupil ze strany , a bude zřejmě tlačit i na to , aby přišel o svou funkci .
petr kajnar chce ale bojovat dál .
o co ve sporech jde a kdo je na čí straně , popsal v exkluzivním rozhovoru pro deník .
jak vnímáte výsledek voleb ?
čssd určitě počítala s mnohem lepším výsledkem .
poškodilo ji u nás to , že se před volbami řešily v médiích spory uvnitř strany ?
dovedu si představit , že by sociální demokracie mohla mít lepší volební výsledek .
ale na druhé straně to odpovídá stavu , v jakém čssd nyní je .
je to strana , která má své vnitřní problémy , je vnitřně nemocná a lidé to vnímají , že v ní není všechno v pořádku .
ve volbách to dali jasně najevo .
jaké jsou ty vnitřní nemoci čssd ?
úpadkem už nějakou dobu podle mě prochází ods a podobné věci se teď bohužel odehrávají v sociální demokracii .
je to tak , že lobbisté , vlivní lidé , kteří dříve očekávali , že své prebendy najdou u ods , se přesunuli k lidem v čssd a mají na ně vliv .
ono to pak souvisí s tím , že po kancelářích ostravského magistrátu chodí policie a sbírá počítače .
ukazuje to , že čssd není složená jen z lidí , kteří by chtěli dobro všech ostatních , ale mnozí z nich myslí především na dobro svoje .
čssd je rozdělená na dva nesmiřitelné tábory i v praze , jak je vidět i v aktuálním boji o moc mezi haškovci a sobotkovci .
i to už se ale připravovalo dlouho .
to , k čemu došlo před volbami v ostravě , byla jen předzvěst toho , co se děje nyní v praze .
haškovo křídlo si postupně obsazovalo pozice , aby pak po volbách mohlo vyvolat situaci , jež oslabí sobotkovo křídlo .
člověk je v politice v situaci , kdy občas musí přistupovat na kompromisy .
každý má ale nějakou vnitřní hranici , kdy už ty kompromisy dělat nejdou , a to je i můj případ .
původně jsem nechtěl kandidovat do sněmovny , ale když jsem vnímal celou tu věc uvnitř strany , tak jsem se dohodl s lubošem zaorálkem , že se pokusím dostat se na krajskou kandidátku , abych jako primátor ostravy posílil právě sobotkovo křídlo .
haškovo křídlo tomu ale dalo stop .
proč stojíte na straně bohuslava sobotky , a ne michala haška ?
slávek sobotka je podle mě člověk , který vždycky mluví především o programu čssd a do jisté míry i o vizích pro stranu a pro tuto zemi .
přiznám se , že z druhé strany jsem nic takového neslyšel .
michal hašek jen bojuje o moc .
nechápu , jak může předsednictvo , které je nižší orgán než ústřední výkonný výbor , začít jen tak odvolávat předsedu strany .
to je boj o moc bez ohledu na vše a proti stanovám strany .
podle mě tím , co nyní michal hašek předvedl v praze , ukončil svou politickou kariéru .
jak jste vnímal to , že vás ostravské vedení čssd na kandidátku neschválilo .
politické strany jsou založeny na soutěži , kdo se jak z jejich členů umístí .
ta soutěž by měla být z větší části založena na programových vizích a na schopnostech těch lidí ty vize naplňovat .
samozřejmě se však do této soutěže hlásí i lidé , kteří moc schopností ani vize nemají , ale politická strana je pro ně výtah k penězům , které by jinde nedostali .
problém je , když se tito lidé začnou dostávat do popředí díky tomu , že bez skrupulí porušují pravidla , porušují stanovy strany .
svými praktikami dělají z politických stran mafie a podle mě tak porušují i zákony české republiky .
upozornit na tento problém je pro mě důležitější než to , abych bral ohled na to , jestli má nějaký kajnar nějakou politickou budoucnost .
je důležité , aby strany začaly respektovat stanovy .
proto jste tedy podal ještě před volbami návrh k soudu na předběžné opatření proti podobě kandidátky čssd v moravskoslezském kraji ?
současný okresní výkonný výbor čssd v ostravě si svou moc upevňuje tím , že organizace , které mu nevyhovují , dokáže zrušit , účelově zakládá nové organizace , postupně vyhazuje nepohodlné členy strany .
příkladem je třeba i to , že chtěli vyloučit richarda bednaříka z klubu zastupitelů , on ale proti tomu podal žalobu a oni pak usnesení o jeho vyloučení raději zrušili .
to ukazuje , že domáhat se dodržování stanov strany přes soudy je sice tou poslední možností , ale v okamžiku , kdy ty ostatní způsoby a kontrolní orgány uvnitř čssd přestaly fungovat , je to jediná možnost .
snahou vedení ostravské čssd v čele s poslancem adamem rykalou je odvolat vás z pozice primátora .
je veřejným tajemstvím , že na tento post má zálusk starosta poruby lumír palyza .
je to tak , adam rykala a lumír palyza se snaží dělat vše proto , aby mě mohli odvolat .
slibují lidem pozice , získávají hlasy a za ty hlasy pak upevňují svou moc ve straně .
když se vrátím do minulosti , tak vše , co se třeba odehrálo kolem fotbalového klubu baník ostrava a koupě stadionu bazaly , byla pro ně jen záminka k tomu , aby na mě mohli zaútočit .
bylo to uměle zinscenováno , aby mě mohli označit za člověka , který dává peníze tam , kam nepatří .
přitom město koupilo majetek , který má pro něj strategicky velkou hodnotu .
jak to tedy vidíte dál se svým setrváním ve funkci primátora ?
okresní výbor už mě a ještě další lidi v pondělí vyzval , abychom zvážili své setrvání v čssd .
já si ale myslím , že je to tak , jako když zloděj křičí : chyťte zloděje !
když se podíváme na výsledky mé práce za posledních jedenáct let , tak nevidím nikoho v ostravské sociální demokracii , kdo by inicioval a prosadil , někdy i proti členům strany , vznik tolika rozvojových věcí , jako třeba průmyslových zón či rozšíření vědecko-technologického parku .
přesto všechno se stávám nepohodlným .
nečtu to jinak , než že překážím ostatním , aby se prodrali na místa , po kterých touží .
budete proti těmto snahám ještě nějak bojovat ?
protože pokud má tahle republika dobře fungovat , tak musí dobře fungovat i politické strany .
těžko můžu věřit tomu , že jakákoliv strana bude umět efektivně řídit stát , když neumí řídit ani samu sebe .
neuvažuji tedy , že bych nyní odešel z čssd , protože si myslím , že ten , kdo způsobuje rakovinu téhle strany , nejsem já , ale tihle lidé , kteří se mě snaží vyštvat .
olomouc otevře v historickém centru veřejné kluziště
organizátor olomouckých vánočních trhů a zimního bruslení pavel spálený uvedl , že přípravné práce na kluzišti byly zahájeny 26. října a od středy je v provozu agregát na výrobu ledu .
ledová vrstva je už silná sedm centimetrů a do pátečního rána bude plocha připravena pro první návštěvníky .
kluziště má plochu 375 metrů čtverečních , pódium zabralo 358 metrů čtverečních .
bruslaři i kolemjdoucí budou mít k dispozici také dva stánky s punčem .
&quot; rozšířili jsme podlahovou plochu , zvětšili prostor před stánky a téměř celá plocha podia je zastřešena tak , aby se bruslaři mohli pohodlně přezouvat , &quot; popsal spálený .
ulice olomouce už připomínají blížící se vánoce .
loni bylo kluziště kvůli opravě dolního náměstí instalováno přímo před hlavním vchodem radnice na horním náměstí .
oprava dolního náměstí byla na sklonku léta dokončena , takže ledová plocha se mohla vrátit zpět na své původní místo .
poprvé si mohli lidé zabruslit přímo před radnicí v roce 2009 , kdy bylo kluziště v provozu od ledna do března .
ledová plocha se poté stala nedílnou součástí vánočních trhů ve městě .
vánoční trhy , jejichž součástí je bohatý kulturní program , budou na horním náměstí zahájeny měsíc před štědrým dnem .
pamela anderson si nechala „ oškubat “ ty ikonické blonďaté kadeře a nasadila nový , dramaticky rošťácký sestřih .
pameliny blonďaté vlasy jsou slavné díky její roli v sexy televizní show pobřežní hlídka .
pamela anderson je nejnovější celebritou , která své fanoušky šokovala novým účesem .
ex-kočka z pobřežní hlídky se zbavila svých dlouhých blonďatých vlasů a nasadila platinový rošťácký sestřih .
tato 46letá herečka odhalila svou poslední změnu vzhledu , když si ve středu vyšla v la a umístila na svou twitterovou stránku fotku .
je to poprvé po 20 letech , co má tato blonďatá kráska krátké vlasy , a nám se tato zdrženlivá změna líbí .
co si myslíte o pammyiných vlasech ?
podělte se s námi o svůj názor v komentářích níže .
brutální vraždu seniora na zlínsku bude znovu řešit krajský soud
krajský soud zprostil obžaloby pětadvacetiletého slováka a dvaadvacetiletého čecha pro nedostatek důkazů .
muži vinu odmítli .
hrozí jim 15 až 20 let vězení nebo i výjimečný trest .
mluvčí petr angyalossy potvrdil , že vrchní soud rozhodnutí krajského zrušil a věc mu opět vrátil k projednání .
důvody , které k tomu soudce vedly , odmítl komentovat s tím , že rozhodnutí ještě nebylo stranám doručeno .
podle obžaloby mladíci přepadli sedmasedmdesátiletého muže v jeho domě .
senior zemřel trýznivou smrtí .
podle obžaloby jej muži škrtili , bili a kopali po celém těle a také mu kovovým předmětem , zřejmě plynovou pistolí , zasadili asi tři desítky ran do hlavy .
muž utrpěl závažná zranění , například zlomeniny lebeční kosti , otok mozku či krvácení do mozku , kterým na místě podlehl .
mladíci si z domu údajně odnesli asi 3000 korun a šperky v hodnotě asi 14 tisíc korun .
podle krajského soudu byly jediným , navíc jen nepřímým důkazem proti obžalovaným pachové stopy , které znalec vyhodnotil jako ne zcela zjištěné ve smyslu zákonných pokynů .
pachové stopy z místa činu i na dalších věcech se sice ve více než deseti případech shodovaly s obžalovanými , nicméně policie s nimi zpočátku nakládala jako s věcnými a ne pachovými stopami .
navíc se zjistila jistá pochybení při nakládání s nimi .
podle senátu nebyla vina obžalovaných bez pochybností prokázána .
soud však uznal , že policie měla velmi ztížené podmínky .
mrtvého seniora s rozbitou hlavou našli příbuzní , kteří si mysleli , že zřejmě upadl a zranil se sám .
na násilné úmrtí neupozornila ani přivolaná lékařka záchranné služby .
kriminalisty tak až po několika dnech kontaktovali olomoučtí lékaři , kteří při pitvě objevili znaky násilné smrti .
policie již nemohla pracovat se všemi stopami z místa činu , které příbuzní uklidili .
na místě se nenašla žádná dna obžalovaných .
mladý slovák žil na uherskohradišťsku .
nyní si odpykává trest 8,5 roku , který mu loni potvrdil pravomocně olomoucký vrchní soud .
muž byl podle něj hlavou organizované skupiny šesti mladíků , která má na svědomí loupežná přepadení zlatnictví .
loupeže se staly v říjnu a listopadu 2011 , krátce po vraždě seniora ve slopném .
mladší z obviněných z vraždy seniora bydlí v uherském hradišti .
soud ho v srpnu po 11 měsících propustil z vazby .
znojmo začíná s rekonstrukcí stadiónu
na začátku listopadu začne ve znojmě rekonstrukce fotbalového stadiónu .
ve čtvrtek si stadión přebírali stavbaři , kteří provedou rekonstrukci trávníku .
rekonstrukce městského stadiónu ve znojmě je rozdělena do čtyř etap tak , aby vyhovovala normám pro první fotbalovou ligu .
žijící legenda wayne shorter uzavře přístí týden struny podzimu
saxofonový velikán a legenda jazzové scény wayne shorter udělá příští středu tečku za 18. ročníkem festivalu struny podzimu .
shorter vystoupí 6. listopadu ve velkém sále lucerny společně se svým kvartetem ve složení danilo perez , john patitucci a brian blade .
ve druhé půlce večera se k shorterovi přidá se spontánní jazzovou improvizací pkf - prague philharmonia pod vedením martina kumžáka .
v shorterových úpravách pro symfonický orchestr zazní skladba pegasus z novinkového alba without a net , stejně jako jeho starší skladby lotus a prometheus unbound .
ačkoliv letos v srpnu oslavil osmdesáté narozeniny , je shorter stále plný sil , což dokazuje i to , že pražský koncert na strunách podzimu odstartuje jeho světové turné .
wayne shorter vstoupil do světa hudby před více než šedesáti lety .
výčet interpretů , s nimiž spolupracoval , sahá od milese davise přes herbieho hancocka , joni mitchell až po carlose santanu .
na své hudební cestě se potkal i s českým hudebníkem miroslavem vitoušem a vídeňským rodákem joem zawinulem , se kterými v legendárních weather report po více než jednu dekádu udávali směr nového stylu fusion .
posledních třináct let vystupuje zejména s wayne shorter quartet .
jakousi afterparty po festivalu bude ještě klubová noc spotlight , která se uskuteční 9. listopadu v klubu roxy / nod .
vedle charismatické zpěvačky andrey triany se tuzemskému publiku představí manchesterské trio go go penguin se svým jazzem ovlivněným elektronikou a mladý jazzový talent ian mikyska , který přiveze elektro-jazzovou formaci profound bass inspirovanou tanečními styly .
damkové prý zakazuje uefa zveřejňovat tresty pro rozhodčí .
dagmar damková , předsedkyně komise rozhodčích fotbalové asociace čr , přestala zveřejňovat tresty pro sudí .
zakazují jí to pravidla uefa , což uvedla v rozhovoru pro deník právo .
v opačném případě by prý hrozil fačr postih .
damková rovněž odmítla , že by ve své funkci stranila fotbalistům plzně , odkud pochází .
tyto spekulace jsou opravdu nesmyslné .
je pravda , že žiji v plzni , ale ostatní členové komise jsou odjinud , například i z prahy .
takže v případě hlasování mohu prohrát 1 : 6 , &quot; prohlásila damková v reakci na kritiku , která se rozbouřila poté , co plzeň v poslední době zahrávala dvakrát tolik penalt než ostatní ligové týmy .
ačkoli tedy v posledních měsících přestala fačr zveřejňovat tresty pro rozhodčí , damková ujišťuje , že sudí za své chyby pykají .
&quot; věřte mi , že pokud komise zjistí , že rozhodčí udělal chybu , omezí mu delegaci , ať to bylo v jakémkoliv utkání , &quot; prohlásila damková .
důvodem , proč se tresty nezveřejňují , je podle damkové zákaz od evropské fotbalové unie .
&quot; uefa zveřejňování takových informací zakazuje a porušení tvrdě trestá . &quot;
&quot; u nás jsme hodně podezíraví a za každou chybou něco hledáme . &quot;
&quot; omezení jsme zveřejňovali , ale dostala jsem dvě velmi důrazná varování , že pokud s tím nepřestaneme , přijdou tvrdé sankce , &quot; řekla damková .
ostatní země zákaz respektují .
&quot; my jsme byli opravdu výjimkou , &quot; dodala .
pokud by se zveřejňováním informací pokračovala , mohla by prý komise přijít o peníze od uefa na výchovu a rozvoj rozhodčích .
&quot; a ty jsou pro nás velice důležité . &quot;
&quot; bez nich bychom nemohli program na výchovu rozhodčích naplňovat , &quot; dodala damková .
zadržení bárty souvisí s janouškem a bémem : stojí za únikem odposlechů ?
předsedu věcí veřejných víta bártu ve čtvrtek zatkla policie .
spolu s ním byl zadržen i vedoucí odboru analytiky a informatiky protikorupční policie jan petržílek .
zadržení souvisí s odposlechy lobbisty romana janouška a bývalého primátora pavla béma ( ods ) .
informaci o odposleších , se kterou přišel server novinky.cz , potvrdil české tiskové kanceláři důvěryhodný zdroj .
odposlechnuté telefonické hovory janouška a béma , které loni v březnu zveřejnil deník mladá fronta dnes a v nichž se oba muži vzájemně oslovují &quot; mazánku &quot; a &quot; kolibříku &quot; , ukazují janouškův vliv na kroky města pod bémovým vedením .
deník tehdy uvedl , že je v roce 2007 pořídila bezpečnostní informační služba ( bis ) , z níž o dva roky později unikly do bezpečnostní agentury abl .
tu tehdy vlastnil bárta .
server novinky.cz upozornil , že zadržený kriminalista petržílek pracoval před svým nástupem k protikorupční policii právě pro bis .
k protikorupčnímu útvaru , který se následně odposlechy zabýval , petržílek přešel ve stejné době , kdy byly zveřejněny .
&quot; s ohledem na zákon o ochraně utajovaných informací nemůžu vůbec nic potvrdit ani vůbec nic říkat , &quot; uvedl žalobce michal muravský z městského státního zastupitelství v praze .
odmítl potvrdit i to , že kauzu dozoruje .
případ nechce ze stejného důvodu komentovat ani inspekce .
na nový občanský zákoník se připravuje šest firem z deseti
na blížící se účinnost nového občanského zákoníku a zákona o obchodních korporacích od 1. ledna 2014 se intenzivně připravuje šest firem z deseti .
jen osm procent z dotazovaných zástupců firem uvedlo , že záležitosti spojené s oběma klíčovými kodexy v jejich společnosti vůbec neřešili .
vyplývá to z průzkumu advokátní kanceláře ambruz &amp; dark deloitte legal , která zjišťovala názory 108 českých firem .
v souvislosti s blížícím se termínem účinnosti obou klíčových kodexů si teprve teď na poslední chvíli řada manažerů začíná uvědomovat , jaký mohou mít výrazný vliv na podnikání jejich společností .
největší změny v soukromém právu za posledních 50 let se totiž dle našeho názoru dotknou všech občanů a firem v čr .
kvůli lavírování politiků žil podnikatelský sektor dlouho v nejistotě , jestli k revolučním změnám nakonec dojde , či nikoliv .
&quot; nyní už jim však zbývá pouze několik týdnů , aby přechod na nové právo proběhl pro jejich firmy bez komplikací , &quot; komentoval výsledky partner ambruz &amp; dark deloitte legal jan spáčil .
z 61 procent společností intenzivně se zabývajících novými zákoníky uvedlo 26 procent , že jejich firmy už přijaly všechna nezbytná opatření , aby byly včas připraveny .
dále 35 procent společností z tohoto počtu se chystá k přijetí nezbytných opatření v nejbližší době .
proti tomu každá pátá firma se rekodifikacemi dosud nezabývala , přesto má konkrétní představu , jak se na ně připravit .
celkem 11 procent nemá názor a problematiku nedokáže posoudit .
jen osm procent společností přiznává , že záležitosti spojené s rekodifikacemi dosud neřešily .
nejdůležitějším právním tématem souvisejícím s novým občanským zákoníkem je pro největší počet dotazovaných společností uzavírání nových smluv ( 21 procent ) , následuje řešení obchodních podmínek ( 16 procent ) a dále změny v katastru nemovitostí a v odpovědnosti za škodu ( po deseti procentech ) .
u smluv se odehraje jedna z nejvýznamnějších novinek celé rekodifikace , a to sjednocení úpravy smluv pouze v rámci nového občanského zákoníku .
současná paralelní úprava v občanském i obchodním zákoníku zanikne , v důsledku čehož by se smluvní právo mělo stát pro občany i podnikatele přehlednější .
&quot; v případě podnikatelů nová úprava nabídne mnoho novinek s důrazem na větší volnost uspořádání vztahů , &quot; upozornil advokát ambruz &amp; dark deloitte legal lukáš poddaný .
v souvislosti se zákonem o obchodních korporacích považuje za nejpodstatnější téma téměř čtvrtina společností problematiku zvýšení odpovědnosti statutárních orgánů .
dále následují témata týkající se změn ve svolávání a průběhu valné hromady ( 15 procent ) a zastupování společnosti ( 14 procent ) .
nová právní úprava znamená zpřísnění povinností a možných dopadů pro statutární orgány , zejména v situaci , když společnosti hrozí úpadek nebo se do něj dostane .
&quot; v praxi to znamená , že pokud členové představenstev a jednatelé firem nebudou jednat s péčí řádného hospodáře a neodvrátí hrozící úpadek společnosti , mohou přijít o prospěch získaný za výkon funkce až za poslední dva roky , &quot; doplnil spáčil .
pierre rainero : snažím se , aby se styl cartieru vyvíjel jako živý jazyk
mým úkolem je zachovat tradici a zároveň vést naši značku k moderním věcem , aby nezůstala zaprášenou relikvií , objasňuje v rozhovoru pro hn svou pozici pierre rainero , ředitel stylu ve společnosti cartier .
tento francouzský luxusní dům vznikl už v roce 1847 .
putuje skrz bahno , řeku a džungli a poskytuje lékařskou péči zdarma
dr. georges bwelle poskytuje zdarma lékařskou péči na vesnicích v kamerunu .
bwelle a jeho tým ošetří téměř každý víkend stovky pacientů
v zemích západní afriky není příliš mnoho lékařů ; jen jeden na 5 000 obyvatel .
hlasujte zde nebo prostřednictvím svého mobilního telefonu .
dr. georges bwelle je jeden z 10 hlavních kandidátů na cenu cnn hrdinové roku 2013 .
v soutěži o cenu cnn hrdinové roku 2013 můžete hlasovat pro něj či pro kteréhokoliv jiného z deseti hlavních kandidátů .
výherce získá 250 000 dolarů , aby mohl pokračovat ve své mimořádné práci .
celých 21 let georges bwelle sledoval svého otce , jak znovu a znovu upadá do bezvědomí a jezdí do nemocnic , které nebyly vybaveny tak , aby mu pomohly .
jamef bwelle byl v roce 1981 nedaleko hlavního města kamerunu yaounde zraněn při autonehodě .
nejdříve se léčil pouze se zlomenou rukou , ale následně se u něj vyvinula infekce , která se rozšířila do mozku , a tam vytvořila hematom , jenž mu působil problémy celý život .
„ v kamerunu nebyli žádní neurochirurgové , “ říká georges bwelle .
museli bychom ho vzít mimo kamerun , kdybychom na to měli peníze .
místo toho bwelle strávil roky tím , že svého otce dopravoval do přeplněných klinik a nemocnic , kde dostal takovou léčbu , která prostě byla k dispozici .
„ není to jednoduché , “ říká bwelle .
můžete odejít z domu v pět ráno , spěchat do nemocnice , abyste tam byl první , ale první nejste .
je tam mnoho pacientů .
někteří lidé umírají jen proto , že musí čekat .
od roku 2002 , kdy bwelleho otec zemřel , se situace příliš nezměnila .
podle světové zdravotnické organizace je v kamerunu pouze jeden lékař na 5 000 obyvatel .
jen pro srovnání , poměr ve spojených státech je jeden lékař na 413 obyvatel .
a i kdyby lékaře kamerunci mohli navštívit , mnozí by si to nemohli dovolit .
dva z pěti lidí v této zemi žijí pod hranicí chudoby a téměř tři čtvrtiny výdajů na zdravotní péči v této zemi jsou soukromé .
„ jediný problém , který mají , je chudoba , “ říká bwelle .
s kvůli chudobě si nemohou užívat života .
když bwelle viděl svého otce a mnoho ze svých krajanů trpět , rozhodl se s tím něco udělat .
dr. georges bwelle a jeho tým dobrovolníků vykonal minulý rok zdarma 700 operací .
sám se stal lékařem cévním chirurgem v centrální nemocnici v yaounde .
a založil neziskovou organizaci ascovime , jejíž členové o víkendu navštěvují venkovské oblasti , kde poskytují lékařskou péči zdarma .
od roku 2008 se svou skupinou dobrovolníků pomohl téměř 32 000 lidí .
téměř každý pátek se on a až 30 lidí napěchuje do dodávek , připevní na střechy lékařské potřeby a cestují drsným terénem do vesnic , které potřebují pomoc .
ne vždy je doprovází štěstí .
nejednou musí vozidla tlačit skrz řeku a bahno .
ale když dorazí , dostane se jim přivítání jako skutečným hrdinům : hostina , zpěv a tanec a to nejlepší ubytování , které komunita může nabídnout .
v těchto vesnicích je lékařská péče zdarma skutečně důvodem slavit a bwelle – se svým širokým úsměvem a nespoutanou energií – se velice ochotně zapojuje do místního veselí .
další den tým začíná ošetřovat stovky pacientů .
„ na každé výpravě máme 500 pacientů , “ říká bwelle .
přicházejí do vesnice z okruhu 60 kilometrů , a to pěšky .
během každého z těchto víkendů lékaři poskytují různou zdravotnickou pomoc .
mnozí se léčí s malárií , tuberkulózou , podvýživou , cukrovkou , parazitními chorobami a pohlavně přenášenými chorobami .
další mohou dostat berle nebo darované brýle či rodný list zdarma – dokument , který požaduje škola , ale který si mnoho zubožených rodin prostě nemůže dovolit .
večer tým dělá pod lokální narkózou jednoduché operace .
operace se obvykle dělají v budově školy , na radnici nebo doma ; po operaci pacient vstává a jde do zotavovacího místa , aby uvolnil místo dalšímu pacientovi .
za pomocí světla z generátoru , operační místnosti a hygienického vybavení bwelle a jeho dobrovolníci pracují do brzkých ranních hodin .
je to vyčerpávající , ale vesničtí hudebníci obvykle týmu pomáhají , aby neztratil motivaci .
„ abychom zůstali vzhůru a pokračovali v práci , hrají na bubny celou noc , “ říká bwelle .
v neděli tým zamíří zpátky do města , unavený , ale hrdý na svou práci .
tato skupina – sestávající se z kamerunských lékařů a zahraničních studentů medicíny – provedla minulý rok 700 operací zdarma a uvědomuje si , že jejich pomoc může pro místní obyvatele hodně znamenat .
jeden muž řekl , že po operaci kýly bude moci zase pracovat .
„ to naší rodině změní budoucnost , “ řekl muž .
kromě organizování těchto víkendových klinik a práce chirurga v nemocnici bwelle také v noci pracuje pro soukromé zdravotnické kliniky kolem města yaounde .
říká , že právě tato druhá práce financuje asi 60 % jeho neziskových aktivit ; zbytek pokrývají soukromé příspěvky .
„ nejsem si jistá , kdy vlastně spí , “ říká katie o &apos; malleyová , která druhým rokem studuje medicínu na drexelově univerzitě ve philadelphii a pracuje jako dobrovolník pro bwelleovu skupinu .
vždy je buď v nemocnici , nebo se snaží získat peníze pro organizaci , aby tyto kampaně mohl dělat .
pro studenty medicíny a ošetřovatelských služeb , jako je o &apos; malleyová , kteří přišli ze spojených států nebo evropy , aby se k bwelleovi připojili na jeho misi , je to skvělá praxe , kterou by doma nezískali .
„ doktoru bwellemu jsme důkladně umývali ruce a odstraňovali krvavé skvrny nebo jsme mu drželi nástroje , “ říká o &apos; malleyová .
to jako student medicíny v druhém ročníku v americe nikdy nezažijete .
studenti dobrovolníci si obvykle zaplatí cestu do kamerunu sami a často dorazí s darovanými lékařskými potřebami .
jakmile ale dorazí do yaounde , stravu , dopravu a studium jim poskytuje bwelle .
„ bezpochyby je to hrdina , “ říká o &apos; malleyová .
této organizaci dává svůj život a jeho touha pomoct obyvatelům kamerunu je nekonečná .
pro bwelleho neustálý zápřah není břemenem .
pomáhat druhým žít šťastněji , naplňovat slib , který dal svému otci , je něco , co mu přináší velkou radost .
„ jsem tak šťastný , když dělám tuhle práci , “ říká bwelle .
a myslím na svého otce .
doufám , že vidí , co dělám .
rozesmát lidi , zmírnit jejich bolest – to je důvod , proč to dělám .
podívejte se na webové stránky ascovime a najdete tam , jak můžete pomoct .
ministr holcát obnovil funkci hlavní sestry pro čr
hlavní sestra pro čr by měla zastupovat zájmy zdravotních sester , jejichž počet v česku přesahuje 100 tisíc .
&quot; považuji za podstatné , aby tato funkce byla jasně definována a formalizována , aby měly zdravotní sestry svého zástupce v rámci struktury úřadu - představitele , k němuž se mohou v případě potřeby vždy obrátit , &quot; vysvětlil martin holcát , ministr zdravotnictví .
vážím si práce sester a myslím si , že si obor ošetřovatelství zaslouží , aby mu byla věnována patřičná pozornost i ze strany ministerstva .
při výkonu tohoto povolání je třeba nejen vysoká odborná profesionalita , ale také lidský přístup a osobní přesvědčení .
&quot; ráda a se vší zodpovědností se budu snažit o prosazování těch kroků , které mohou pozici zdravotních sester vylepšit . &quot;
&quot; máme v našem zdravotnictví výborné a šikovné sestry , ale chtěla bych apelovat i na ty kolegy , kteří nám svým přístupem k pacientům příliš nepomáhají , aby své povolávání vykonávali se vší empatií a pomohli nám v očích veřejnosti obraz sester zlepšovat , &quot; říká alena šmídová .
nově jmenovaná hlavní sestra pro čr alena šmídová u příležitosti svého uvedení do funkce také uvedla , že se chce zabývat nejrůznějšími aspekty pracovní pozice zdravotní sestry a hodlá mj. spolupracovat s profesními sdruženími , odbornými společnostmi , vzdělavateli , dalšími nelékařskými povoláními a lékaři .
&quot; zásadně nechci oddělovat povolání lékařů a sester , ale naopak je vidím stát vedle sebe , přičemž každý má své kompetence a společně s dalšími zdravotnickými pracovníky tvoří sehraný pracovní tým , který poskytuje zdravotní služby ku prospěchu pacienta . &quot;
&quot; sama se setkávám s řadou problémů , které se při výkonu povolání sester vyskytují , tyto nesnáze vnímám a hodlám se podílet na jejich řešení . &quot;
patří mezi ně například zajištění zjednodušení ošetřovatelské a zdravotnické dokumentace .
&quot; z vlastní zkušenosti vím , že některé administrativní úkony sestry zbytečně zatěžují a ubírají jim čas , který by mohly a měly věnovat raději pacientům , &quot; uvádí alena šmídová .
k dalším oblastem , na něž se hodlá zaměřit , patří zlepšení pracovních podmínek , hledání cest k lepší vzájemné spolupráci v týmu a s managementy poskytovatelů zdravotních služeb , úprava kompetencí a také pracovněprávní otázky , jako je dodržování zákoníku práce či nepřetěžování sester jejich nedostatečným počtem v daném čase a místě .
často slýcháme anonymní stesky , které ale z obavy z možného postihu nejsou dokumentovány na konkrétním případu , kde by k porušování pravidel mohlo docházet .
&quot; kde není žalobce , není ani soudce , a tak by funkce hlavní sestry čr mohla v tomto případě sloužit jako záruka zachování anonymity takové stížnosti a konkrétní případ nechat příslušnými orgány prověřit , &quot; uzavírá alena šmídová .
mgr. alena šmídová vystudovala střední zdravotnickou školu v oboru zdravotní sestra ( absolvovala v roce 1978 ) a filosofickou fakultu univerzity karlovy v praze ve studijním programu ošetřovatelství - pedagogika ( absolvovala v roce 1992 ) .
od roku 2010 působí jako vedoucí oddělení ošetřovatelství a dalších nelékařských oborů a uznávání kvalifikací na odboru vzdělávání a vědy mzčr .
v průběhu své profesionální kariéry pracovala jako sestra u lůžka na interním oddělení , dále působila jako učitelka na střední zdravotnické škole , kde byla i 8 let statutární zástupkyní ředitelky .
od roku 2004 do roku 2009 působila jako hlavní sestra vězeňské služby čr .
publikovala několik odborných učebnic ošetřovatelství a článků do odborných časopisů , věnovala se přednáškové činnosti v oblasti ošetřovatelství .
není členkou žádné politické strany .
abych se nezalknul nenávistí
spisovatel václav kahuda se po dvanácti letech vrátil k psaní .
po dlouhých letech , kdy četl , žil , ale nepsal , vydává václav kahuda ( 1965 ) nový román vítr , tma , přítomnost .
že nepůjde o útlý svazek , napovídá počet stran srovnatelný s jeho nejznámějším dílem houština ( petrov , 2001 ) .
pro salon kahudu vyzpovídal jiný výrazný český spisovatel současnosti - emil hakl .
co se kde pohnulo , že jsi po dvanácti letech mlčení napsal román ?
udělal jsem to - abych se nezalknul nenávistí .
vidět okolo sebe pořád nové a nové klony té lidské pošetilé malichernosti , mladé organismy postižené slepým sobeckým snažením .
o nás starších ani nemluvím , ksichty zruinované bezmocnou žádostivostí , vekslácké duše a opačně přepólovaní ideologové , kteří se snaží s výrazem malé prodejné děvky prodat svůj &quot; produkt &quot; .
na začátku tisíciletí jsem si koupil malou digitální kameru a natáčel své jurodivé přátele , podivíny a skryté útvary .
už mě to přešlo .
někdy cítím , jak mi z života na téhle planetě hoří mozek .
nejraději chodím na procházky a pak si večer u lampičky čtu knihy .
mluvíš o pocitu zmaru , nenávisti .
byl někde v minulosti nějaký zlom , který tě ovlivnil , nebo taky jen stárneš , jako my všichni ?
zlom nastal kdysi dávno , zhruba v deseti letech .
tehdy to nemělo jméno .
no , a po tom jsem žil .
tam někde uvnitř je ale pořád překvapený tichý chlapec .
vidím další osamocené cvikýře , každého ve svém tornádu úzkosti .
zachránilo mě psaní knih .
účastním se toho obrovitého , tisíce let trvajícího pohybu systému života na této planetě - toho rození neuchopitelné budoucnosti .
té nesmírné , dech beroucí komplexity života , kdy každý kámen je přímým dědicem naší přítomnosti .
jsme hráči smutné a krásné hry , kdy cestou pokus-omyl vzniká další a další generace bytostí , která v biliónech interakcí za sekundu vytváří nějakou nadlidskou , artificiální inteligenci .
dvanáct let je relativně dlouhá doba .
vnímáš své psaní jako průběžný proces , nebo jsi začal úplně od nuly ?
samomluva , nebo lépe řečeno dialog , který vedou pravá a levá polovina mozku , občas vypluje na hladinu a zformuje se v knihu .
jako jsou období míru protkána tiše spícími metastázami válek , které se možná jednoho dne probudí - tak má kniha je dvanáct let mlčení oblečených do slov.
cítil jsem , jak mi němá lavina života roste v mozku , a pokud nic neudělám , tak mě jednoho dne tiše zavalí .
je to soubor otázek , které zformuloval mozek a pokládá je vrstvám , které jsou uloženy v temnotě &quot; pod hladinou vědomí &quot; .
neokortex , šedá kůra mozková , se ptá starších evolučních útvarů , jde k pradávným letokruhům mozkového stromu .
hovoří k srstnatým šelmám , ptá se hadů , hledá odpověď v letu ptáků , zvedá svůj zrak k mrakům na obloze .
ano , mravní zákon ve mně a hvězdné nebe nade mnou .
nakonec se mozek ptá světa .
relativně často se vyjadřuješ k egu metaforicky - dokázal bys ho definovat biologicky ?
mozek uchovává ve svých miliardách spojů a elektrochemických vazbách veškeré vzpomínky , zkušenosti a zážitky , které dotyčný člověk prožil .
tenhle les logicky a emocionálně vystavených a větvících se stromů informací , registrů paměti , používá mozek ve svém rozpoznávacím , kognitivním , procesu , jsa vystaven neustále proměnlivé přítomnosti , v neutuchající snaze se snaží pojmenovat a rozumět svému okolí a dekódovat důležitá sdělení .
někdy nastanou poruchy z přetížení .
analogicky - jako by ti &quot; spadlo &quot; pc , z programu řečového emulátoru a překladače z cizích jazyků by ses zamotal nejprve v operačním prostředí , například windows , a po několika neúspěšných restartech skončil u temně zeleně poblikávající obrazovky biosu , v základním systému , který řídí funkce a spolupráci na motherboardu , mezi procesorem a operační pamětí atd.
pro toho , kdo dosud nepochopil , o čem je řeč - mluvím o psychospirituální krizi .
zmiňuješ se o ní často - proč tě zrovna tenhle typ regresu pravidelně zajímá ?
protože to je jáma .
v doposavad funkčních mechanismech našeho myšlení , cítění a chování - se objeví průrva .
zde je dobré ocitovat nietzscheho : &quot; tak dlouho hleděl do propasti , až se propast podívala do něho . &quot;
ryzí pocit - že je člověk ztracen , pokud zmizí všechna naděje , psychicky &quot; umře &quot; a nastupuje nová kvalita .
a proč mě to zajímá osobně ?
odpovím podobenstvím .
kdysi jeden spadl do tůně a topil se , běžely dny , měsíce a léta , on se pořád topil a přitom četl , a ty knihy ho naučily plavat - tedy žít .
stal se &quot; potápěčem &quot; .
snad někomu pomůže nějaká mnou napsaná věta , jako kdysi pomohly hrabalovy texty mně .
do jaké míry myslíš na čtenáře , na konkrétního člověka , který tvůj text bude číst ?
ten , o němž nelze povědět nic smysluplného , jedni to nazývají vědomím , další super egem , podle mne to ale nejlépe charakterizoval arthur rimbaud v dopise příteli :
&quot; já je někdo jiný - tenhle čtenář se podílí přímo na procesu formulace slov a vět . &quot;
od raného mládí četl knihy starých českých pohádek , plavil se v ponorce kapitána nema , běhal po stínadlech v temných uličkách .
stejně nakonec , za tím vším větvením autorů a jejich poselství , zní : &quot; slunce jasná světů jiných karla hynka máchy &quot; .
a když je kniha venku ?
záleží ti na čtenářově názoru ?
na zpětném odrazu , který se k tobě přes lidi , co knihu přečtou , dostane ?
samozřejmě mi záleží na názoru lidí , kteří vezmou tři sta korun a jsou ochotni přečíst pět set stran textu .
a ještě mě pak , třeba po letech , na ulici náhodně kontaktují a poděkují mi , že jsem jim svou knihou pomohl v nějakém jejich těžkém životním rozhodnutí .
knihy jsou ve skutečnosti &quot; životy &quot; nebo lépe řečeno &quot; světy &quot; .
jsou zakódované do znaků písmen , nesou zkušenost , historii regionů toho kterého jazyka .
kdykoliv je můžeme probudit k životu , když necháme jejich věty proudit do mozku .
je to vlastně , svým způsobem , něco zakázaně božského - probouzet další a další životní příběhy , malé vesmíry a dočasné planety .
je to skutečnost , jejíž dna je uložena do čar - podle starých démonologických knih se dopouštíme čarodějnictví .
po vydání knihy tě - jak to bývá - čeká řetěz autorských čtení .
pamatuju si , že jsi kdysi četl rád .
vrhneš se do toho opět s radostí , nebo to cítíš po letech jinak ?
dnes už raději jen tak vyprávím .
a co jsem při tom zjistil ?
všude žijí dobří inteligentní lidé .
jejich základní znak - jsou nenápadní , příliš na sebe neupozorňují , mají přátelské vyzařovaní , necítíš se s nimi osamělý .
dám příklad - v městečku červený kostelec žil byl ( a doufám , že ještě žije ) jeden kudrnatý knihkupec ( jmenuje se příhodně červenka ) , veselý kumpán a dobrý dívčí býk .
při jedné pijatyce mi představil jednotlivé články řetězce čtenářů mé knihy houština .
hleděl jsem jim do očí a pak mi byl ukázán rozdrbaný , očtený exemplář mé knihy .
v rozpacích jsem odložil právě rozečtenou jitrnici a krátce mužsky zaplakal .
mlčky jsme tam všichni stáli , kymáceli se a opilecky s dojetím slzeli .
pak to ten mladý blonďatý míšenec nevydržel a s řevem vyskočil po hlavě z okna do sněhové závěje .
bylo to v přízemí .
vyběhli jsme do noční krajiny a jatí šťastnou vzteklinou citlivců , bolavou duší krajánků a steskem zapadlých vlastenců - vyli a hýkali jak vlkodlaci až do rána .
každá tvoje kniha je formálně i obsahově jiná než ty předešlé .
platí to také o textu vítr , tma , přítomnost ?
je to vyprávění .
je to pohádka o jedné zemi za devatero řekami a devatero horami .
ivan bunin ve své novele suchodol vkládá do úst lidovému léčiteli slova jedné staré ruské báje : na moři , na oceánu , na ostrově bujanu .
leží psice , na ní šedá truhlice .
hrůza , děs , tajemství .
nikdy se to nestalo , ale všichni to odněkud známe .
možná jsme kdysi dávno byli ďáblové v pekle a losovali - jakou roli na této zemi budeme hrát .
hodláš dál psát , nebo to necháš opět na volném přílivu inspirace ?
odpovědi jsou věčné - otokar březina .
psaní je podivuhodný způsob dialogu .
cosi obrovského a nepojmenovatelného , podobného pohybu kontinentů na planetě , ovlivňuje naše chtění z takové hloubky a v takové šíři , že zcela přesahuje náš obzor - a tak s naprostou samozřejmostí konáme přesně v intencích svého naprogramovaného zadání .
jsme odměňováni přílivem dopaminu , směsí endorfinů a dalších látek .
jsme biologické stroje .
chceme se pářit , umíráme při obraně a získávání nových osobních teritorií .
občas se stane porucha a vyzáříme soucit .
jedině tehdy máme právo nazývat se lidmi .
to je odpověď na tvou otázku - biologický robot je už plný různých poruch , stojí na pobřeží oceánu nevědomí a do děravé plachty udělané ze špinavého kapesníku chytá přílivy vlahého větru .
musím psát , abych mohl být člověkem .
obama ustupuje od zdravotní péče
po vlně kritiky prezident obama včera ustoupil od svého často opakovaného a ambiciózního slibu , že „ pokud se vám váš zdravotní program líbí , můžete si ho nechat “ .
s odvoláním na stovky tisíc oznámení o výpovědích od poskytovatelů republikáni v posledních dnech obviňovali prezidenta z klamání americké veřejnosti .
včera obama od svého původního slibu ucuknul .
„ velká většina lidí , kteří mají fungující zdravotní pojištění , si je mohou ponechat , “ řekl ve svém projevu v bostonu .
s ohledem na to , co nazval „ rozruchem v médiích “ o výpovědích , obama vyzval američany , kteří tato oznámení obdrželi , k vyhledávání nových pojistek na trhu .
většina lidí bude schopna mít lepší , komplexnější program zdravotní péče za stejnou cenu nebo dokonce levněji , než se předpokládalo .
„ dostanete lepší nabídku , “ řekl .
jeho administrativa tvrdí , že by nemělo být překvapením , že 5 procent obyvatelstva , které si zakoupily pojištění samo za sebe , může být přinuceno program změnit , protože jejich pojištění nesplňuje nové požadavky dané zákonem o dostupné péči .
„ říkám to těmto američanům na rovinu : zasloužíte si něco lepšího , “ řekla sebeliusová ve své výpovědi před výborem pro energii a obchod ve washingtonu .
sebeliusová , která dohlíží na implementaci zákona o dostupné péči , řekla , že spuštění internetového trhu šlo od října „ bídně “ .
„ jsem zklamaná a naštvaná jako všichni ostatní , “ řekla .
budu se snažit získat zpět vaši důvěru .
podrážděná sebeliusová tuto větu , kterou zachytil zapnutý mikrofon , vyřkla včera směrem k poradci sedícímu za ní na včerejším jednání výboru , které se konalo po bouřlivé výměně názorů s republikánem billy longem , zástupcem z missouri , která se týkala toho , zda se musí i ona sama zapojit do obamova programu péče .
více než tři hodiny během slyšení na sebeliusovou opakovaně dotíral otázkou , proč se „ architekt “ zákona o dostupné péči dobrovolně nevzdal vládou sponzorovaného pojištění , a nezakoupil si program přes healthcare.gov , který nyní vnucuje milionům američanů .
s kterým miliardářem budete příští rok telefonovat ?
kellner , majitel skupiny ppf , chce koupit operátora o2 .
obě firmy jednání potvrdily a podle nejrůznějších zdrojů z agentur i ze zákulisí je prý už ruka v rukávu .
oznámení o transakci by mělo přijít ještě v listopadu , pravděpodobně před začátkem aukce frekvencí pro sítě lte , tedy před 11. listopadem .
kellnerův konkurent karel komárek vlastní skupinu kkcg .
ta se pod značkou sazka telecommunications pustila do aukce frekvencí pro sítě lte .
a to k všeobecnému překvapení , do té doby se o chuti firmy proniknout do telekomunikací nemluvilo .
jenže sazku teď vede velmi zkušený telekomunikační mazák robert chvátal .
ten začínal jako marketingový šéf radiomobilu ( dnes t-mobile ) , posléze se stal ředitelem slovenského t-mobilu a naposled šéfoval rakouské pobočce stejného operátora .
sazka hraje hned několik karet najednou .
přihlásila se do aukce a teď přiznala , že chce u vodafonu spustit virtuála .
a dává to logiku .
pokud v aukci uspěje , tak si do své sítě bude moci přesunout již existující zákazníky z vlastního virtuálního operátora .
to by se asi za normálních okolností vodafonu nelíbilo , jenže podle informací hospodářských novin to může být součást mnohem užší spolupráce obou firem .
vodafone v současné době trpí dohodou konkurenčních operátorů o2 a t-mobile , kteří budou kompletně sdílet své sítě .
vodafone tak potřebuje partnera .
a tím může být právě sazka .
pokud ta uspěje v tendru na sítě lte ( jako nováček může dražit speciálně určené spektrum ) , tak vodafone se do aukce vůbec pouštět nemusí , respektive mu nebude vadit vydražení jen omezeného spektra ( není dostatek frekvencí pro všechny ) .
vodafone se totiž se sazkou může o sítě podělit .
vodafone pustí sazku do své 2g / 3g sítě ( respektive nově budovanou síť lte na frekvenci 900 mhz ) , čímž umožní firmě rychlý start sítě .
sazka mezi tím začne budovat nákladnou síť lte , kterou bude moci využívat i vodafone .
spokojeny mohou být obě firmy .
uspořené peníze by pak vodafone mohl utratit za nějakého poskytovatele pevného internetu či kabelové televize .
a kellner ?
ten by koupí českého a slovenského o2 ( slovenská pobočka je dcerou české ) získal okamžitě plnohodnotného operátora se stále slušnými zisky a širokou nabídkou služeb .
ale na druhou stranu je to velký moloch , který bude čekat restrukturalizace .
v aukci by sítě lte získal kellner už za o2 a velmi pravděpodobně v součinnosti s t-mobilem .
obě firmy již totiž deklarovaly , že sítě budou sdílet .
aukce by tak mohla konečně skončit úspěchem , ale dost pravděpodobně nikoliv s vysokými částkami , na které se těší státní rozpočet .
a od příštího roku by si tak zákazníci v česku mohli vybrat mezi voláním s vodafonem , t-mobilem , kellnerem nebo komárkem .
aneb dva titáni českého byznysu proti globálním obrům .
obejde se česká televize někdy bez podpisových akcí ?
do éry prezidenta zemana vkročila legendární scénou s popelníčkem , a tak není těžké naslouchat stížnosti , jež shromažďuje doklady protěžování hradní družiny .
v minulosti tradovaný vliv takového ivana langera nebo jaroslava tvrdíka nikdo takto nezdokumentoval , natož aby se pod to podepsal .
pravda , vedení se zastali redaktoři .
popsané případy ovšem nedávají odpověď na otázku , odkud se taková příchylnost některých novinářů k zemanovcům bere - zda jde o reakci na přímou objednávku , anebo , abychom nepoužili vulgarismus , typický projev nemístné empatické vstřícnosti .
a když už předpokládáme všeobecnou prohnilost , nelze si odpustit otázku , zda o změnu poměrů v televizi neusilují jiné , neméně bezskrupulózní mocenské zájmy , jež zatím nedostaly příležitost .
pravdu mají ti , kdo říkají , že ve vyspělých zemích k okatým pokusům o intervenci politiků do vysílání nedochází .
pravda je ovšem také to , že to neznamená , že by tam stížnosti na veřejnoprávní média neexistovaly .
stěžovatelé nezpochybňují jejich nezávislost .
kritizují naopak hlavně to , co považují za tendenčnost , jež je jim vlastní , jež je plodem jejich subkultury .
možná jsme prostě do tohoto civilizačního stadia ještě nedospěli a tato situace u nás není .
možná se ale také v zemi , jež si o sobě myslí , že je nejzkorumpovanější na světě , černobílé příběhy o zlých politicích a dobrých novinářích tráví pohodlněji než komplikovanější popisy nepřehledné situace , v níž na sebe naráží chování mnoha nedokonalých lidských bytostí .
jan jandourek : prokletí této země : prezidenti na pokraji sil
je skoro pravidlem , že v klíčových okamžicích země nebyla hlava státu v takové formě , aby mohla splnit své státnické povinnosti .
kdyby byl t . masaryk fyzicky a mentálně o pět let mladší , dožil by se konce svého prezidentského období a události kolem mnichova by se odehrály trochu jinak .
válku bychom nejspíš nevyhráli , ale po symbolickém odporu by mohlo letectvo uletět za hranice , těžké zbraně se daly zničit a vláda mohla prchnout do londýna hned a nebojovat tam pracně o svou legitimitu .
a hlavně by z té kapitulace neměl národ kocovinu dodnes .
beneš státník nebyl a za mnichova byl ještě v kondici , ale za války už to s ním začalo jít z kopce a v únoru 48 se zachoval podle toho .
být na tom o něco lépe , mohl odejít potřetí do exilu a podlomit legitimitu komunistů a jejich puče .
o háchovi škoda mluvit .
zvolili ho s tím , že &quot; pan president se nedostane do situace , že by rozhodoval &quot; .
jenže musel , i když velké rozhodování to s nožem na krku u hitlera v kancléřství asi nebylo .
śéf rozvědky františek moravec do posledních dní v březnu 1939 říkal , co všechno by se mělo udělat , aby okupace , o které věděl na den přesně , neproběhla němcům tak hladce a s takovým ziskem .
senilní prezident a zbabělá vláda neudělali nic , jednak mu nevěřili , jednak se báli .
lidská troska gottwald nechal popravovat své letité spolusoudruhy , jak mu moskva nakázala .
ludvík svoboda se definitivně znemožnil podílem na normalizaci a museli ho , již zcela senilního , sesadit .
že byl husák bezmocný a nemocný depresivní stařec dění v listopadu 89 usnadnilo , ale to je ten jediný klad .
havel měl štěstí , že ho poslední roky nepotkaly v úřadě , byl ušetřen nejhoršího .
klaus je sice stále svěží tenisový důchodce , ale mnohé jeho počiny dávají tušit , že myšlenkové procesy už nejsou , co bývaly .
no a teď tady máme tohle .
hlava státu a vrchní velitel ozbrojených sil vypadá , jak vypadá a to ještě nevíme všechno .
naštěstí teď nehrozí vnější ohrožení republiky .
nebo ono možná hrozí , jen není tak vidět .
pak je otázka , jestli výjimečně není ( z historického hlediska ) dobře , že prezident není zcela při síle .
normální stav to ale není .
nemohli bychom zvolit v téhle zemi prezidentem už zase jednou někoho přijatelně myslícího a přijatelně zdravého ?
vzdálené planety , černobílé filmy či trocha fantazírování o mimozemském životě na zemi nejsou témata , která by americký jazzový saxofonista wayne shorter nadhazoval ledabyle .
v pojetí jeho kvarteta , které 6. listopadu ve velkém sále pražské lucerny završí letošní ročník festivalu struny podzimu , totiž všechno souvisí se vším .
partiturou kvarteta jazzového saxofonisty wayne shortera jsou momentální pocity muzikantů .
podle jeho zadání mají o dvě generace mladší kolegové hrát to , co právě zažívají .
k hudbě přistupují jako ke zcela improvizované komorní záležitosti a přemýšlet mají nikoliv o harmonii či rytmu , nýbrž ve filmových obrazech .
tento princip ovšem čerstvě osmdesátiletý shorter - mimořádný skladatel , nositel devíti grammy , někdejší spoluhráč milese davise a dnes patrně největší žijící jazzový saxofonista - nerad vysvětluje .
o hudbě příliš nemluví , přestože jeho celkový pohled na život s hudbou úzce souvisí .
ve svých osmdesáti letech jsem došel k názoru , že nejlepší je nechat se životem překvapovat .
&quot; příliš mnoho lidí si všechno plánuje a pak jsou zklamaní , když se věci vyvinou jinak , &quot; tvrdí shorter .
jak hmyzáci z thajska zvedli tržby pařížského baru
možná se nad hmyzem ošklíbáte a přitom netušíte , že ho zhruba půl kilogramu ročně sníte naprosto dobrovolně .
například rozemletý v mouce .
pokud ho konzumujete vědomě , pak jste jednoznačně trendy : je to ekologické , výživné a o jedinečný zážitek máte také postaráno .
nabídku hmyzu zařadil jako první v paříži na jídelní lístek svého podniku na začátku října elie daviron , kuchař a majitel baru le festin nu .
bar , pro jehož název byla inspirací kniha williama burroughse nahý oběd , byste našli v módním 18. obvodu nedaleko montmartru hojně navštěvovaného turisty .
s čerstvým avokádem , pečenými červenými paprikami , zázvorem a křepelčím vajíčkem tu hosté nově mohou zakousnout nejen různé larvy , kobylky nebo vodní brouky , ochutnat se tu dají i štíři .
pečlivě a speciálně zabalené dodávky ( aby se hmyzu nepoškodila křídla , nezkřivily nohy nebo nepoškodily oči ) davironovi posílají až z thajska .
evropa se teprve učí jíst hmyz , jinde je to běžné .
majitel pařížského baru s průkopnickým menu uvádí hned několik důvodů , proč konzumovat právě hmyz .
prvním z nich je ekologický přínos , protože produkce hmyzu je pro naši planetu mnohem méně nákladná ( co se financí , prostoru i spotřeby vody týká ) než u tradičního masa .
&quot; navíc je hmyz vynikajícím zdrojem bílkovin a omega 3 mastných kyselin , &quot; řekl daviron pro stanici reuters .
zároveň mladý kuchař nezapře svoji profesi , prostě si klade za cíl nabídnout svým zákazníkům jedinečný kulinářský zážitek .
podle něj dělá správnou restauraci potěšení , pocit hříchu a atmosféra prostředí .
&quot; nezachraňuji svět , jen zprostředkovávám novou zkušenost , &quot; vysvětil .
zdaleka ne každého by asi nadchla představa , jak konzumuje brouka odzdobeného pestem , ale reakce zákazníků pařížského baru na servírovaný hmyz jsou podle majitele velmi pozitivní .
dokonce i skeptici prý nakonec ochutnají , i když začínají těmi nejmenšími sousty a až nakonec si vyberou škorpiona .
ceny těchto degustačních talířků se pohybují od pěti do devíti eur .
prezident svazu podnikatelů ve stavebnictví v čr václav matyáš : nová zelená úsporám by měla pokračovat
české stavebnictví se od roku 2008 potýká s kontinuálním poklesem objemu zakázek a nezájmem státu řešit problematiku investiční výstavby .
vyhlášení programu nová zelená úsporám bylo pozitivním signálem pro naše stavebnictví , a to především pro malé a střední firmy v jednotlivých regionech .
je velkou příležitostí nejen pro občany , kteří po realizaci opatření uspoří značné částky za vytápění , ale i šancí pro stavební firmy a výrobce stavebních hmot .
každá investovaná miliarda přinese státu více než 2700 nově vytvořených pracovních míst .
z hlediska fiskální politiky státu jsou významné pákové a multiplikační efekty , jde také o jedno z nejvýznamnějších prorůstových opatření .
svaz podnikatelů ve stavebnictví v čr proto zásadně nesouhlasí s usnesením vlády a žádá o realizaci takových kroků , které by umožnily další pokračování programu , aby mohly být v jeho rámci vyhlášeny další výzvy .
právo , 1. listopadu 2013
pes shrnul koberec , prezident zakopl a skončil o berlích
prezident miloš zeman ve čtvrtek opustil motolskou nemocnici v praze , kde strávil noc na lůžku , a odjel na zámek v lánech .
v jakém zdravotním stavu je ?
v bezprecedentním přiznání john kerry řekl , že americká špionáž „ zašla příliš daleko “
john kerry naznačil zjemnění obranného postoje usa ohledně svých sledovacích programů a v bezprecedentním přiznání řekl , že v některých případech špionáž „ zašla příliš daleko “ .
ministr zahraničí také přiznal , že je spolu s barackem obamou odpovědný za to , že s ohledem na štvavá odhalení o špionážní činnosti nsa , která se objevila díky informátorovi edwardu snowdenovi , jednali jako na „ autopilota “ .
zveřejněné informace vyvolaly diplomatickou bouři mezi americkou vládou a jejími spojenci .
pan kerry prostřednictvím video-spojení na otevřené vládní konferenci v londýně řekl : „ není pochyb o tom , že prezident a já i ostatní ve vládě jsme se skutečně dozvěděli o některých věcech , které se ze setrvačnosti děly , protože tu ta možnost byla , s odkazem na druhou světovou válku , obtížné období studené války a pak samozřejmě 11. září . “
stal se tedy prvním vysoce postaveným členem americké vlády , který přiznal , že americká špionáž překročila hranici , ale zdůraznil , že nebyla porušena ničí práva .
řekl : „ v některých případech to zašlo příliš daleko . “
a prezident je rozhodnutý pokusit se to lidem vysvětlit a vyjasnit a již nyní provádí důkladné přezkoumání , aby nikdo neměl pocit , že došlo ke zneužití .
ujišťuji vás , že v tomto procesu nedochází ke zneužívání práv nevinných osob .
pan kerry však trval na tom , že organizace nsa usiluje o dobro a že její sledovací operace zachránily mnoho životů .
dodal : „ potýkáme se s novým světem , ve kterém jsou lidé ochotni sami sebe odpálit . “
ve světe existuje radikální extremismus , který je pevně odhodlaný vraždit a vyhazovat lidi do povětří a napadat vlády .
a co kdybyste byli schopní to zachytit a zastavit předtím , než se to stane ?
ve skutečnosti jsme zabránili tomu , aby nespadla letadla , nevybuchly budovy a nebyli popraveni lidé , protože se už umíme dozvídat o těchto plánech dopředu .
předsedající senátního podvýboru pro evropské záležitosti ve čtvrtek řekl , že američtí zákonodárci se chystají do evropy , aby reagovali na obavy ze zahraničí , které se týkají údajné americké špionáže , a přesvědčili evropany , že je třeba i nadále spojovat své síly v boji proti terorismu .
senátor chris murphy z connecticutu řekl , že tento týden mluvil se členy evropského parlamentu a dalšími osobami a že mu dělají starosti jejich výhrůžky , že zastaví účast v protiteroristických organizacích , protože jsou rozčarováni sledováním národní bezpečnostní agentury ( nsa ) .
pro národně-bezpečnostní zájmy usa je skutečně důležité , aby s námi evropa zůstala na jedné lodi , a to s ohledem na společné úsilí v boji proti terorismu , řekl v rozhovoru z washingtonu murphy , člen demokratické strany a předsedající senátního podvýboru zahraničních vztahů pro evropské záležitosti .
a já mířím do evropy , abych dal jasně najevo , že musíme pokračovat ve spolupráci v boji s terorismem nehledě na jejich vztek nad programy nsa .
zprávy v médiích , že nsa sbírala miliony telefonních záznamů v evropě , narušily vztahy s některými americkými spojenci , přestože šéf agentury tento týden řekl , že byly nepřesné a odrážely nepochopení metadat , která spojenci nato sbírali a sdíleli se spojenými státy ,
další odhalení citovala dokumenty prozrazené snowdenem , že nsa sledovala mobilní telefon německé kancléřky angely merkelové a dalších až 34 světových vůdců .
ředitel národního zpravodajství james clapper špionáž spojenců obhajoval jako nutnou a řekl , že se jedná z obou stran o běžnou záležitost .
uprostřed vřavy murphy řekl , že jeho kancelář plánuje parlamentní cestu , která by se měla uskutečnit tento rok , a doufá , že v delegaci se objeví členové obou stran a komor .
v příštích dnech mají být zveřejněna jména ostatních zákonodárců , kteří se hodlají zapojit .
řekl , že na programu se stále ještě pracuje .
přestože murphy řekl , že cílem cesty je pomoci napravit vztahy , dodal , že budou připravena i „ dobře míněná výchovná opatření “ .
řekl , že evropští vůdci musí být ke svým vlastním lidem poctiví , pokud jde o špionážní programy , které po léta sami využívají .
„ zatímco my upravujeme své programy sledování , abychom lépe chránili práva evropanů , musí si také oni uvědomit fakt , že nejsme jediní , kdo tady provádí špionáž , “ řekl murphy .
mezitím pan kerry míří podle plánu tento víkend na střední východ a do polska , aby reagoval na nevraživost , již vyvolala americká strategie v sýrii , egyptě a íránu a také americká sledovací činnost .
australanka se odvolala proti pobytu v thajském vězení
jednadvacetiletá žena ze sydney , která byla odsouzena k patnáctidennímu vězení na ostrově phuket , když nepravdivě tvrdila , že byla napadena řidičem taxi , se proti verdiktu odvolala a byla propuštěna na kauci .
stevie rochelle bamfordová byla původně 15. června obviněna zemským soudem na ostrově phuket z křivého obvinění , když thajské policii řekla , že řidič taxi spolu se dvěma dalšími muži , kteří ji prý zadržovali , ji napadli v ranních hodinách v neděli 10. června .
avšak záznam z průmyslové televize později odhalil , že se poté , co se rozešla se svým australským přítelem , vrátila bezpečně do svého hotelu .
policie z ostrova phuket vedla rozhovory s bamfordovou dva dny , než se doznala k tomu , že si příhodu vymyslela .
před soudním procesem byla držena v místní policejní cele .
bamfordová byla odsouzena k 15 dnům vězení v nápravném zařízení s nízkou ostrahou na periférii v phuketu , místo aby byla umístěna do vězení pro dospělé ženy .
je dcerou bývalého australského ligového hráče petera tunkse , který v případu své dcery požádal o pomoc ministerstvo zahraničních věcí v canbeře .
tunks řekl sydneyskému listu sunday telegraph , že celá rodina měla „ extrémní obavy “ o osud své dcery a chtěla ji zpět v austrálii .
„ evidentně to je náročné období , ale doufáme , že se k nám co nejdříve v bezpečí vrátí , “ řekl tunks .
bamfordová se proti rozsudku odvolala a byla propuštěna na kauci 50 000 bahtů .
zprávy z austrálie uvádí , že mezitím trávila dovolenou v rekreační oblasti krabi na jihu thajska .
právní zdroje v thajsku tvrdí , že bamfordovou zastupoval místní právník v phuketu , ale dostalo se jí prý varování , že odvolání může vést k soudnímu řízení , které její trest zvýší a vyústí v umístění do vězení pro dospělé .
avšak po nedávném zavraždění australské zaměstnankyně cestovní kanceláře michelle smithové v phuketu se také thajsko může snažit pro turisty napravit pošramocený obrázek , což právě možná stálo za osvobozujícím verdiktem .
jágr vtipkoval : gól z brejku ?
v obraném pásmu získal puk a už ho nikdo nechytil .
únik navíc proměnil po rychlé forhendové kličce .
jaromír jágr takhle skóroval proti tampě v noci na středu , ve čtvrtek večer pak 119. vítězný gól v nhl okomentoval na sociální síti facebook .
&quot; po zhlédnutí tohoto videa se mému agentovi petru svobodovi ozval ředitel českých drah a otázal se ho , jestli bych neměl zájem udělat reklamu na jejich nejmodernější vlak pendolino ! &quot; napsal na úvod s nadsázkou jágr .
prý jsme si typově hodně podobní .
asi budu muset skončit s nočními tréninky , abych ještě víc nezrychlil .
&quot; bojím se totiž , že by se poté mohl ozvat ministr obrany a chtěl by udělat reklamu na tryskáče ! &quot; dodal se smajlíky .
new jersey si navíc připsalo druhé vítězství v řadě .
&quot; a hlavně , všimli jste si - léčba marií rottrovou zabírá , &quot; uzavřel jágr .
místo povolební svíčkové povolební guláš
říjnové volby spíše než vítěze přinesly kupu poražených .
nejsou to jen strany , které se do poslanecké sněmovny ani nedostaly ( např. spoz ) , ale také předchozí vládní strany ( ods , top 09 ) a nakonec i čssd kvůli svému vnitřnímu rozkolu .
politici nám místo sváteční svíčkové naservírovali o víkendu povolební guláš .
skokanem voleb se stalo hnutí andreje babiše , které voličům slibovalo změnit dosavadní politický styl vládnutí .
roztříštěnost volebního výsledku a rozkol ve vítězné straně nahrává politické ( z ) vůli pana prezidenta miloše zemana bez ohledu na přání voličů , kteří stranu , kterou prezident zeman veřejně podporoval , ani nezvolili do poslanecké sněmovny .
prezident sice kvůli nepříjemné události ztratil strategický náskok před ostatními politiky , ale zbývá mu ještě několik způsobů , jak jej získat zpět - například výběrem budoucího premiéra .
zatímco čssd se šance na získání premiérského křesla v mých očích vzdalují , podnikateli andreju babišovi naopak přibližují .
povolební vývoj je sice zatím na míle vzdálen brzkému a hladkému vytvoření stabilní vlády , ale v porovnání s předvolebním scénářem levicové vlády čssd podporované komunisty , je toto vývoj pro podnikání v čr a tedy i ekonomiku přece jen lepší zprávou .
vzhledem k hlasitému odporu ano dát se dohromady s ods či top 09 , je stále nejpravděpodobnější variantou koalice čssd , ano a kdu-čsl ( celkem 111 poslanců ) .
vzhledem k rozkolu v čssd , která se tím pádem stala nečitelným a slabým parterem ve vyjednávání , může být výsledek koaličních jednání dost skličující pro čssd .
minoritní vláda čssd složená s &quot; nezemanovců &quot; na hradě nejspíš neprojde .
navíc jakákoliv vláda , na které se čssd bude podílet , bude ohrožena neuspokojenými ambicemi mnohých sociálních demokratů , které mohou vést dříve nebo později k dalšímu rozkolu ve straně .
ptám se tedy sama sebe : &quot; nespějeme samospádem k dalším předčasným volbám ? &quot;
další volby by už byly spíše referendem o síle voličského mandátu hnutí ano .
plány čssd na zavádění sektorových daní , výraznější zvyšování daní z příjmů či budování státní banky padly doufejme pod stůl .
strany čssd , ano , kdu-čsl a úsvit se naopak shodnou například na podpoře podnikání , střídmé fiskální politice ( vládní deficit pod 3 % hdp ) , na podpoře zaměstnanosti znevýhodněných osob , snížení nižší sazby dph u vybraného zboží .
třecí plochy se nejvíce vyskytují v pohledu na sociální politiku a velikost státu .
ano má teď ale navrch , takže program zatím nejpravděpodobnější koalice ano , čssd , kdu-čsl by se nakláněl spíše doprava .
což z mého pohledu je nakonec lepší výsledek než levicový program s daní na vše , co se v ekonomice ještě hýbe .
